<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Calendario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
  <div id="calendario">
    <h2 id="mes-anio"></h2>

    <div class="navegacion">
      <label for="select-mes">Mes:</label>
      <select id="select-mes"></select>

      <label for="select-año">Año:</label>
      <select id="select-año"></select>
    </div>

    <div class="dias-semana">
      <div>Domingo</div>
      <div>Lunes</div>
      <div>Martes</div>
      <div>Miércoles</div>
      <div>Jueves</div>
      <div>Viernes</div>
      <div>Sábado</div>
    </div>


    <div id="calendario-mes"></div>
    <div id="descripcion" class="descripcion"></div>
    <div id="chartContainer" class="chart">
      <canvas id="asistenciaChart"></canvas>
    </div>
  </div>
  <script>
    /* DECLARACIONES DE VARIABLES*/
    let mes = new Date().getMonth();
    let año = new Date().getFullYear();
    const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

    const iconos = {
      'pago': 'img/pago.png',
      'matricula': 'img/matricula.png',
      'feriado': 'img/feriado.png',
      'curso': 'img/cursos.png',
      'atrasos': 'img/atrasado.png',
      'movimiento': 'img/money.png',
      'movimientored': 'img/moneyred.png',
      'diplomas': 'img/diploma.png',
      'asistencia': 'img/asistencia.png',
      'contenido': 'img/contenido.png',
      'incidencias': 'img/incidencia.png',
      'horasrecuperadas': 'img/horas_recuperadas.png',
      'pagos_profesores': 'img/pagos_profesores.png',
      'inasistencias': 'img/inasistencias.png',
      'gestiones': 'img/gestiones.png'
    };
    const estados = {
      1: 'Solicitud Creada',
      2: 'Impreso',
      3: 'Enviado a notaria',
      4: 'Disponible para retiro',
      5: 'Entregado'
    };
    const tipo_clase = {
      1: 'Teorico',
      2: 'Práctico'
    };

    /* CARGA DE CALENDARIO*/
    function cargarCalendario(mes, año) {
      $.get('consultas.php?action=obtenerEventos', function (data) {
        const eventos = Array.isArray(data) ? data : [];
        const diasEnMes = new Date(año, mes + 1, 0).getDate();
        const primerDiaMes = new Date(año, mes, 1).getDay();

        $('#calendario-mes').empty();
        $('#mes-anio').text(`${obtenerNombreMes(mes)} ${año}`);
        $('#descripcion').hide().text('');

        for (let i = 0; i < primerDiaMes; i++) {
          $('#calendario-mes').append('<div class="dia vacio"></div>');
        }

        for (let dia = 1; dia <= diasEnMes; dia++) {
          const fecha = `${año}-${(mes + 1).toString().padStart(2, '0')}-${dia.toString().padStart(2, '0')}`;
          const diaDiv = $(`<div class='dia' data-fecha='${fecha}'>${dia}</div>`);
          $('#calendario-mes').append(diaDiv);

          const eventosDelDia = eventos.filter(evento => {
            if (evento.fecha && typeof evento.fecha === 'string') {
              const fechaEvento = evento.fecha.split('/').reverse().join('-');
              return fechaEvento === fecha;
            }
            return false;
          });

          diaDiv.data('eventos', eventosDelDia);

          const contenedorIconos = $('<div class="contenedor-iconos"></div>');
          diaDiv.append(contenedorIconos);

          const tiposUnicos = new Set();

          eventosDelDia.forEach(evento => {
            let iconoUrl = iconos[evento.tipo];


            if (evento.tipo === 'movimiento') {
              const totalIngresos = parseFloat(evento.total_ingresos) || 0;
              const totalEgresos = parseFloat(evento.total_egresos) || 0;
              if (totalEgresos > totalIngresos) {
                iconoUrl = iconos['movimientored'];
              }
            }


            if (iconoUrl && !tiposUnicos.has(evento.tipo)) {
              tiposUnicos.add(evento.tipo);
              const iconoPersonalizado = $(`
            <span class="icono" data-tipo="${evento.tipo}" data-evento='${JSON.stringify(evento)}'>
              <img src="${iconoUrl}" alt="${evento.tipo}" />
            </span>
          `);
              contenedorIconos.append(iconoPersonalizado);
            }
          });
        }
      })
        .fail(function (xhr, status, error) {
          console.error('Error en la solicitud AJAX:', status, error);
          $('#descripcion').text('Error al cargar los eventos.').show();
        });
    }

    /* OBTENCION DE NOMBRES DE LOS MESES*/

    function obtenerNombreMes(mes) {
      const nombresMes = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
      ];
      return nombresMes[mes];
    }



    /* OBTENER DATOS DE % DE ASISTENCIA Y MOSTRAR GRAFICO */
    function mostrarGraficoAsistencia(porcentaje_asistencia, porcentaje_no_asistencia) {
      const ctx = document.getElementById('asistenciaChart').getContext('2d');

      if (window.chartInstance) {
        window.chartInstance.destroy();
      }

      window.chartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
          labels: ['Asistencias', 'No Asistencias'],
          datasets: [{
            data: [porcentaje_asistencia, porcentaje_no_asistencia],
            backgroundColor: ['#4CAF50', '#F44336']
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top'
            },
            tooltip: {
              callbacks: {
                label: function (tooltipItem) {
                  return tooltipItem.label + ': ' + tooltipItem.raw + '%';
                }
              }
            }
          }
        }
      });
    }

    $(document).ready(function () {
      cargarCalendario(mes, año);

      for (let i = 0; i < 12; i++) {
        $('#select-mes').append(`<option value="${i}">${obtenerNombreMes(i)}</option>`);
      }
      $('#select-mes').val(mes);

      const anioActual = new Date().getFullYear();
      for (let i = anioActual - 6; i <= anioActual + 2; i++) {
        $('#select-año').append(`<option value="${i}">${i}</option>`);
      }
      $('#select-año').val(año);

      $('#select-mes').change(function () {
        mes = parseInt($(this).val());
        cargarCalendario(mes, año);
      });

      $('#select-año').change(function () {
        año = parseInt($(this).val());
        cargarCalendario(mes, año);
      });


      /* EVENTO PARA EL CALENDARIO*/

      $(document).on('click', '.dia', function (event) {
        event.stopPropagation();

        const eventosDelDia = $(this).data('eventos') || [];
        let mensaje = '';
        let totalMatriculas = 0;
        let totalPagos = 0;
        let totalIngresos = 0;
        let totalEgresos = 0;
        let eventoAsistencia = null;
        let totalMontos = 0;
        let fechaPago = '';
        const enlacesGenerados = {};
        const iconos = {
          'info': 'img/info.png',
        };

        function getInfoIcon() {
          return `<img src="${iconos['info']}" alt="Info Icon" class="Info-icon">`;
        }

        if (window.chartInstance) {
          window.chartInstance.destroy();
        }

        if (eventosDelDia.length > 0) {
          eventosDelDia.forEach(evento => {
            if (evento.tipo === 'matricula') {
              totalMatriculas += parseFloat(evento.total) || 0;
            } else if (evento.tipo === 'pago') {
              totalPagos += parseFloat(evento.total_pago) || 0;
            } else if (evento.tipo === 'movimiento') {
              totalIngresos += parseFloat(evento.total_ingresos) || 0;
              totalEgresos += parseFloat(evento.total_egresos) || 0;
            } else if (evento.tipo === 'asistencia') {
              eventoAsistencia = evento;
              mensaje += `
               <hr> 
                    ${getInfoIcon()}
                    <strong>Fecha:</strong> ${evento.fecha}<br>
                    <div>${getInfoIcon()}
                    <strong>Porcentaje de Asistencia:</strong> ${evento.porcentaje_asistencia}%<br>
                    ${getInfoIcon()}
                   <strong>Porcentaje de No Asistencia:</strong> ${evento.porcentaje_no_asistencia}%
                    </div>`;

            } else if (evento.tipo === 'incidencias') {
              mensaje += `
              <hr>
                    ${getInfoIcon()}
                   <strong>Fecha:</strong> ${evento.fecha}<br>
                    <div>
                    ${getInfoIcon()}
                    <strong>Hora:</strong> ${evento.hora}<br>
                    ${getInfoIcon()}
                   <strong>Descripción:</strong> ${evento.descripcion}
                  `;
              if (!enlacesGenerados['incidencias']) {
                mensaje +=
                  `
                                  ${getInfoIcon()}
                                <a href="../crud_incidencias/index.php" class="link">Gestión de Incidencias</a>`;
                enlacesGenerados['incidencias'] = true;
              }


            } else if (evento.tipo === 'gestiones') {
              mensaje += `
              <hr>
                    ${getInfoIcon()}
                   <strong>Fecha:</strong> ${evento.fecha}<br>
                    <div>
                    ${getInfoIcon()}
                    <strong>Cantidad de Gestiones:</strong> ${evento.cantidad_gestiones}
                  `;
              if (!enlacesGenerados['gestiones']) {
                mensaje +=
                  `
                                 <br> ${getInfoIcon()}
                                <a href="../crud_gestiones/index.php" class="link">Gestión de Gestiones</a>`;
                enlacesGenerados['gestiones'] = true;
              }


            } else if (evento.tipo === 'horasrecuperadas') {
              mensaje += `
                <hr>
                    ${getInfoIcon()}
                    <strong>Nombre Curso:</strong> ${evento.nombrescurso}<br>
                    ${getInfoIcon()}
                   <strong>Fecha de Recuperación:</strong> ${evento.fecha}<br>
                    ${getInfoIcon()}
                    <strong>Horas Recuperadas:</strong> ${evento.h_recuperadas}<br>`;
              if (!enlacesGenerados['horasrecuperadas']) {
                mensaje +=
                  `
                               ${getInfoIcon()}
                              <a href="../crud_horas_recuperadas/index.php" class="link">Gestión de Horas Recuperadas</a>`;
                enlacesGenerados['horasrecuperadas'] = true;
              }
            }
            if (evento.tipo === 'pagos_profesores') {

              totalMontos += parseFloat(evento.montos);
              if (!fechaPago) {
                fechaPago = evento.fecha;
              }
              if (!enlacesGenerados['pagos_profesores']) {
                mensaje += `
                <hr>
            ${getInfoIcon()}
            <strong>Fecha de Pago:</strong> ${fechaPago}<br>
            ${getInfoIcon()}
            <strong>Total Monto:</strong>  $${Math.round(totalMontos).toLocaleString('es-CL')}
          <br> ${getInfoIcon()}
            <a href="../crud_pagos_profesores/index.php" class="link">Gestión de Pagos Profesores</a>
        `;
                enlacesGenerados['pagos_profesores'] = true;
              }
            } else if (evento.tipo === 'diplomas') {
              let estadoTexto = evento.estado || evento.estado;
              mensaje += `
            <hr>
                    ${getInfoIcon()}
                    <strong>Fecha:</strong> ${evento.fecha}<br>
                    ${getInfoIcon()}
                    <strong>Estado:</strong> ${estadoTexto}<br>
                    ${getInfoIcon()}
                    <strong>Código Matrícula:</strong> ${evento.codigo_matricula}<br>
                 `;
              if (!enlacesGenerados['diplomas']) {
                mensaje += `
                                ${getInfoIcon()}
                              <a href="../crud_diplomas/index.php" class="link">Gestión de Diplomas</a>`;
                enlacesGenerados['diplomas'] = true;
              }
            } else if (evento.tipo === 'contenido') {
              let tipoClaseTexto = tipo_clase[evento.tipo_clase];
              mensaje += `
           <hr>
                    ${getInfoIcon()}
                    <strong>Contenido de Clase:</strong> ${evento.contenido_de_clase}<br>
                    ${getInfoIcon()}
                    <strong>Tipo de Clase:</strong> ${tipoClaseTexto}<br>
                    ${getInfoIcon()}
                    <strong>Fecha:</strong> ${evento.fecha}<br>
                `;
              if (!enlacesGenerados['contenido']) {
                mensaje += `
                      ${getInfoIcon()}
                      <a href="../crud_contenidos/index.php" class="link">Gestión de Contenidos</a>`;
                enlacesGenerados['contenido'] = true;
              }

            } else if (evento.tipo === 'inasistencias') {

              mensaje += `
           <hr>
                    ${getInfoIcon()}
                    <strong>Fecha:</strong> ${evento.fecha}<br>
                    ${getInfoIcon()}
                    <strong>Nombre del Empleado:</strong> ${evento.nombres}${evento.paterno}${evento.materno}<br>
                    ${getInfoIcon()}
                    <strong>Motivo:</strong> ${evento.motivo}<br>
                `;
              if (!enlacesGenerados['inasistencias']) {
                mensaje += `
                      ${getInfoIcon()}
                      <a href="../crud_inasistencias/index.php" class="link">Gestión de Inasistencias</a>`;
                enlacesGenerados['inasistencias'] = true;
              }
            } else if (evento.tipo === 'feriado') {
              mensaje += `
                    ${getInfoIcon()}
                    <strong>Razón de Suspensión de Clase:</strong> ${evento.descripcion} -
                  `;
              if (!enlacesGenerados['feriado']) {
                mensaje += `
                    ${getInfoIcon()}
                    <a href="../crud_feriados/index.php" class="link">Gestión de Feriados</a>`;
                enlacesGenerados['feriado'] = true;
              }
            } else if (evento.tipo === 'feriado') {
              mensaje += `
           <hr>
                    ${getInfoIcon()}
                    <strong>Empleado:</strong> ${evento.nombres} ${evento.paterno} ${evento.materno}<br>
                    ${getInfoIcon()}
                    <strong>Fecha de Atraso:</strong> ${evento.fecha}<br>
                    ${getInfoIcon()}
                    <strong>Minutos de Atraso:</strong> ${evento.minutos_atraso} Minutos<br>
                   `;
              if (!enlacesGenerados['atrasos']) {
                mensaje += `
                        ${getInfoIcon()}
                         <a href="../crud_atrasos/index.php" class="link">Gestión de Atrasos</a>`;
                enlacesGenerados['atrasos'] = true;
              }
            } else if (evento.tipo === 'curso') {
              const diasClaseArray = (evento.dias_clases || '').split('').map(Number);
              const diasClaseNombres = diasClaseArray.map(dia => diasSemana[dia]).join(', ');
              mensaje += `
             <hr>
                    ${getInfoIcon()}
                    <strong>Curso:</strong> ${evento.descripcion}<br>
                    ${getInfoIcon()}
                    <strong>Días de clase:</strong> ${diasClaseNombres}<br>
                    ${getInfoIcon()}
                    <strong>Horario:</strong> ${evento.hora_desde} - ${evento.hora_hasta}<br>
                    ${getInfoIcon()}
                    <strong>Centro de ingreso:</strong> ${evento.centro_ingreso} <br>
                  `;
              if (!enlacesGenerados['curso']) {
                mensaje += `
              <hr>
                        ${getInfoIcon()}
                        <a href="../crud_cursos/index.php" class="link">Gestión de Cursos</a>>`;
                enlacesGenerados['curso'] = true;
              }
            }

            if (eventoAsistencia) {
              mostrarGraficoAsistencia(eventoAsistencia.porcentaje_asistencia, eventoAsistencia
                .porcentaje_no_asistencia);
            }
          });

          const totalGeneral = totalMatriculas + totalPagos + totalIngresos - totalEgresos;

          if (totalMatriculas > 0) {
            mensaje += `
          <hr>
                ${getInfoIcon()}
                <strong>Total de Matrículas:</strong> $${Math.round(totalMatriculas).toLocaleString('es-CL')}
              <br> ${getInfoIcon()}
                <a href="../crud_matriculas/index.php" class="link">Gestión de Matrículas</a><br>`;

          }

          if (totalPagos > 0) {
            mensaje += `
          <hr>
                ${getInfoIcon()}
                <strong>Total de Pagos:</strong> $${Math.round(totalPagos).toLocaleString('es-CL')}
               ${getInfoIcon()}
               <a href="../crud_pagos/index.php" class="link">Gestión de Pagos</a><br>`;
          }

          if (totalIngresos > 0) {
            mensaje += `
          <hr>
                ${getInfoIcon()}
                <strong>Total de Ingresos:</strong> $${Math.round(totalIngresos).toLocaleString('es-CL')}
             <br>  ${getInfoIcon()}
               <a href="../crud_movimientos/index.php" class="link">Gestión de Ingresos</a><br>`;
          }

          if (totalEgresos > 0) {
            mensaje += `
          <hr>
                ${getInfoIcon()}
                <strong>Total de Egresos:</strong> $${Math.round(totalEgresos).toLocaleString('es-CL')}
                ${getInfoIcon()}
               <a href="../crud_movimientos/index.php" class="link">Gestión de Egresos</a><br>`;
          }

          if (totalGeneral > 0) {
            mensaje +=
              `<hr>
                <strong>${getInfoIcon()}<strong>Total Financiero Diario:</strong> $${Math.round(totalGeneral).toLocaleString('es-CL')} ${getInfoIcon()}</strong>`;
          }

          $('#descripcion').html(mensaje).show();
          `<hr>`;
        } else {
          $('#descripcion').text('No hay eventos para este día.').show();
        }
      });


    });
  </script>



</body>

</html>