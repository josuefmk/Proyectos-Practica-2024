<?php
include('conexion.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

function obtenerEventos()
{
  global $conn;


  $sql_matriculas = "
        SELECT
            'matricula' AS tipo,
            fecha_matricula AS fecha,
            'Matrícula realizada' AS descripcion,
            SUM(valor_matricula) AS total
        FROM tbl_matriculas
        GROUP BY fecha_matricula
    ";


  $sql_cursos = "
        SELECT
            'curso' AS tipo,
            c.fecha_inicio AS fecha,
            ci.nombre AS descripcion,
            c.dias_clases,
            c.hora_desde,
            c.hora_hasta,
            ci.nombre AS centro_ingreso
        FROM
            tbl_cursos c
        JOIN
            tbl_centrosdeingreso ci ON c.id_centronegocio = ci.id_centroingreso
    ";


  $sql_feriados = "
  SELECT 'feriado' AS tipo, fecha, descripcion FROM tbl_feriados";


  $sql_pagos = "
        SELECT
            'pago' AS tipo,
            fecha_pago AS fecha,
            total_pago
        FROM tbl_pagos
        GROUP BY fecha_pago
    ";


  $sql_movimientos = "
        SELECT
            'movimiento' AS tipo,
            fecha_movimiento AS fecha,
            SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE 0 END) AS total_ingresos,
            SUM(CASE WHEN tipo = 'egreso' THEN monto ELSE 0 END) AS total_egresos
        FROM tbl_movimiento
        GROUP BY fecha_movimiento
    ";


  $sql_atrasos = "
   SELECT 'atrasos' AS tipo,fecha_atraso AS fecha, nombres, paterno, materno,minutos_atraso
   FROM tbl_atrasos JOIN tbl_empleados
   where tbl_atrasos.id_empleado=tbl_empleados.id_empleado;
";


  $sql_diplomas = "
  SELECT 'diplomas' AS tipo,fecha2 AS fecha,estado,codigo_matricula FROM tbl_diplomas";

  $sql_control_asistencia = "
 SELECT
 'asistencia' as tipo,
    COUNT(*) AS total,fecha,
    SUM(CASE WHEN asiste = 1 THEN 1 ELSE 0 END) AS asistencia,
    SUM(CASE WHEN asiste = 0 THEN 1 ELSE 0 END) AS no_asistencia
FROM tbl_control_asistencia
GROUP BY fecha";

  $sql_contenido = "
  SELECT 'contenido' as tipo,fecha,contenido_de_clase,tipo_clase FROM tbl_contenidos ";

  $sql_incidencias = "SELECT 'incidencias' as tipo, fecha as fecha,hora,descripcion FROM tbl_incidencias";

  $sql_horas_recuperadas = "SELECT 'horasrecuperadas' as tipo, ci.nombre as nombrescurso, h.fecha_recuperacion as fecha,h.horas_recuperadas as h_recuperadas
          FROM tbl_cursos c
          JOIN tbl_centrosdeingreso ci ON ci.id_centroingreso = c.id_centronegocio
          JOIN tbl_horas_recuperadas h ON c.id_curso = h.id_curso
          GROUP BY ci.id_centroingreso";

  $sql_pagos_profesores = "SELECT 'pagos_profesores' as tipo, montos, fecha_pago as fecha FROM tbl_pagos_profesores ";

  $sql_inasistencias = " SELECT 'inasistencias' as tipo, fecha_inasistencia as fecha, e.nombres,e.paterno,e.materno , motivo FROM tbl_inasistencias i JOIN tbl_empleados  e ON i.id_empleado = e.id_empleado";

  $sql_gestiones = " SELECT
  'gestiones'  as tipo,
    fecha_gestion AS fecha,
    COUNT(id_gestion) AS cantidad_gestiones
FROM
    tbl_gestiones
GROUP BY
    fecha_gestion
ORDER BY
    fecha_gestion;
";

  $resultados = [];
  $queries = [
    $sql_matriculas,
    $sql_cursos,
    $sql_feriados,
    $sql_pagos,
    $sql_movimientos,
    $sql_atrasos,
    $sql_diplomas,
    $sql_control_asistencia,
    $sql_contenido,
    $sql_incidencias,
    $sql_horas_recuperadas,
    $sql_pagos_profesores,
    $sql_inasistencias,
    $sql_gestiones
  ];

  foreach ($queries as $sql) {
    $query = $conn->query($sql);
    if (!$query) {
      echo json_encode(['error' => $conn->error]);
      exit;
    }
    while ($fila = $query->fetch_assoc()) {

      if ($sql === $sql_control_asistencia) {
        $total = $fila['total'];
        $asistencia = $fila['asistencia'];
        $no_asistencia = $fila['no_asistencia'];

        $porcentaje_asistencia = ($total > 0) ? ($asistencia / $total) * 100 : 0;
        $porcentaje_no_asistencia = ($total > 0) ? ($no_asistencia / $total) * 100 : 0;

        $fila['porcentaje_asistencia'] = number_format($porcentaje_asistencia, 2);
        $fila['porcentaje_no_asistencia'] = number_format($porcentaje_no_asistencia, 2);
      }
      $resultados[] = $fila;
    }
  }

  header('Content-Type: application/json');


  $json_result = json_encode($resultados);


  if ($json_result === false) {
    echo json_encode(['error' => json_last_error_msg()]);
    exit;
  }


  echo $json_result;
}


if (isset($_GET['action']) && $_GET['action'] === 'obtenerEventos') {
  obtenerEventos();
}
?>