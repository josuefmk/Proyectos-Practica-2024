<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Cámara IP</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_relator = $conn->real_escape_string($_POST['id_relator']);
    $id_especialidad = $conn->real_escape_string($_POST['id_especialidad']);
    $nombre_relator = $conn->real_escape_string($_POST['nombre_relator']);
    $ip_camara = $conn->real_escape_string($_POST['ip_camara']);
    $mac_camara = $conn->real_escape_string($_POST['mac_camara']);


    $sql = "UPDATE tbl_ipcam SET id_relator='$id_relator', id_especialidad='$id_especialidad',
            nombre_relator='$nombre_relator', ip_camara='$ip_camara', mac_camara='$mac_camara' WHERE id_ipcam=$id";


    if ($conn->query($sql)) {
      echo "<p class='success'>Cámara actualizada correctamente.</p>";
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_ipcam WHERE id_ipcam=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Cámara IP</h1>
    <form method="POST">
      <label for="id_relator">ID Relator:</label>
      <input type="text" id="id_relator" name="id_relator" value="<?php echo htmlspecialchars($row['id_relator']); ?>"
        required>

      <label for="id_especialidad">ID especialidad:</label>
      <input type="text" id="id_especialidad" name="id_especialidad"
        value="<?php echo htmlspecialchars($row['id_especialidad']); ?>" required>

      <label for="nombre_relator">Nombre Relator:</label>
      <input type="text" id="nombre_relator" name="nombre_relator"
        value="<?php echo htmlspecialchars($row['nombre_relator']); ?>" required>

      <label for="ip_camara">IP Cámara:</label>
      <input type="text" id="ip_camara" name="ip_camara" value="<?php echo htmlspecialchars($row['ip_camara']); ?>"
        pattern="^(\d{1,3}\.){3}\d{1,3}$" placeholder="Formato: 255.255.255.255" required>

      <label for="mac_camara">MAC Cámara:</label>
      <input type="text" id="mac_camara" name="mac_camara" value="<?php echo htmlspecialchars($row['mac_camara']); ?>"
        placeholder="Formato: 00:1B:44:11:3A:B7" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>