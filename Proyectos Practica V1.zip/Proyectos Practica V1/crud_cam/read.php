<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_id_ipcam = isset($_GET['search_id_ipcam']) ? $_GET['search_id_ipcam'] : '';
$search_id_relator = isset($_GET['search_id_relator']) ? $_GET['search_id_relator'] : '';
$search_id_especialidad = isset($_GET['search_id_especialidad']) ? $_GET['search_id_especialidad'] : '';
$search_nombre_relator = isset($_GET['search_nombre_relator']) ? $_GET['search_nombre_relator'] : '';

$query = "SELECT id_ipcam, id_relator, id_especialidad, nombre_relator, ip_camara, mac_camara FROM tbl_ipcam WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_id_ipcam)) {
  $query .= " AND id_ipcam = ?";
  $types .= 'i';
  $params[] = $search_id_ipcam;
}
if (!empty($search_id_relator)) {
  $query .= " AND id_relator = ?";
  $types .= 'i';
  $params[] = $search_id_relator;
}
if (!empty($search_id_especialidad)) {
  $query .= " AND id_especialidad = ?";
  $types .= 'i';
  $params[] = $search_id_especialidad;
}
if (!empty($search_nombre_relator)) {
  $query .= " AND nombre_relator LIKE ?";
  $types .= 's';
  $params[] = '%' . $search_nombre_relator . '%';
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>

                <th>ID Relator</th>
                <th>ID Especialidad</th>
                <th>Nombre Relator</th>
                <th>IP Cámara</th>
                <th>MAC Cámara</th>
                <th>Opciones</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_ipcam']}'>

                <td>" . htmlspecialchars($row['id_relator']) . "</td>
                <td>" . htmlspecialchars($row['id_especialidad']) . "</td>
                <td>" . htmlspecialchars($row['nombre_relator']) . "</td>
                <td>" . htmlspecialchars($row['ip_camara']) . "</td>
                <td>" . htmlspecialchars($row['mac_camara']) . "</td>
                 <td>
                    <a href='update.php?id=" . urlencode($row['id_ipcam']) . "' class='btn btn-sm btn-warning'>Editar</a>
                    <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_ipcam'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
                </td>
              </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_ipcam: id
        },
        success: function (response) {

          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('El registro ha sido eliminado exitosamente.');
          } else {
            alert('Error al eliminar el registro: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });


    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');

      window.location.href = 'update.php?id=' + id;
    });
  });
</script>