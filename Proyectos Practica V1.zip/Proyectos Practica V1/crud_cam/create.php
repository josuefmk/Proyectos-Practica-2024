<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_relator = $_POST['id_relator'];
  $id_especialidad = $_POST['id_especialidad'];
  $nombre_relator = $_POST['nombre_relator'];
  $ip_camara = $_POST['ip_camara'];
  $mac_camara = $_POST['mac_camara'];

  if (!filter_var($ip_camara, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    echo "Error: Dirección IP no válida";
    exit;
  }

  if (!preg_match('/^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/', $mac_camara)) {
    echo "Error: Dirección MAC no válida";
    exit;
  }

  $stmt = $conn->prepare("INSERT INTO tbl_ipcam (id_relator, id_especialidad, nombre_relator, ip_camara, mac_camara) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("iisss", $id_relator, $id_especialidad, $nombre_relator, $ip_camara, $mac_camara);

  if ($stmt->execute()) {
    echo "Cámara IP guardada correctamente";
  } else {
    echo "Error al guardar la cámara IP: " . $stmt->error;
  }

  $stmt->close();
}
?>