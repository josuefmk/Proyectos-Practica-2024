<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['id_ipcam'])) {
    $id_ipcam = $_POST['id_ipcam'];

    $stmt = $conn->prepare("DELETE FROM tbl_ipcam WHERE id_ipcam = ?");
    if ($stmt === false) {
      echo "Error en la preparación de la consulta: " . $conn->error;
      exit;
    }
    $stmt->bind_param("i", $id_ipcam);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
      echo "success";
    } else {
      echo "Error al eliminar el registro: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
  } else {
    echo "ID de cámara IP no proporcionado.";
  }
} else {
  echo "Método de solicitud no válido.";
}
?>