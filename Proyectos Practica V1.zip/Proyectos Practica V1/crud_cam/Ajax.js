
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('addForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('create.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.text())
      .then(data => {
        document.getElementById('result').innerHTML = data;
        this.reset();
        loadRecords();
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });

  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('tableContainer').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }


  loadRecords();


  document.getElementById("toggleFormBtn").addEventListener("click", function () {
    const formContainer = document.getElementById("addFormContainer");

    if (formContainer.style.display === "none" || formContainer.style.display === "") {
      formContainer.style.display = "block";
    } else {
      formContainer.style.display = "none";
    }

  })
});
  $(document).ready(function() {
    // Limpiar los filtros de búsqueda
    $('#clearFilterBtn').on('click', function() {
      $('#search_id_ipcam').val('');
      $('#search_id_relator').val('');
      $('#search_id_especialidad').val('');
      $('#search_nombre_relator').val('');
      $('#searchForm').submit();
    });


  });
   document.getElementById('addForm').addEventListener('submit', function(event) {

            event.preventDefault();


            document.getElementById('ipError').style.display = 'none';
            document.getElementById('macError').style.display = 'none';


            const ipCamara = document.getElementById('ip_camara').value;
            const macCamara = document.getElementById('mac_camara').value;


            const ipPattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            const macPattern = /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/;


            if (!ipPattern.test(ipCamara)) {
                document.getElementById('ipError').style.display = 'block';
                return;
            }


            if (!macPattern.test(macCamara)) {
                document.getElementById('macError').style.display = 'block';
                return;
            }


            this.submit();
        });