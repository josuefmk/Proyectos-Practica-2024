<?php
include 'conexion.php';
include('../../erp_elc/qrlib.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$query = "SELECT id_usuario, nombres, apellidos
          FROM tbl_usuarios ";

$types = '';
$params = [];

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Nombre de Usuario</th>
                <th>Código QR</th>
                <th>Gestión de Asistencia</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    $id_usuario = $row['id_usuario'];
    $nombres = htmlspecialchars($row['nombres'] . ' ' . $row['apellidos'], ENT_QUOTES);
    $confirmar_url = "http://192.168.1.23/josue/asistenciaqr/confirmar_asistencia.php?id_usuario=" . $id_usuario;


    $qr_file = 'qr_codes/qr_' . $id_usuario . '.png';
    QRcode::png($confirmar_url, $qr_file);


    if (!empty($nombres)) {
      echo "
            <tr>
                <td>" . $nombres . "</td>
                <td><a href='#' onclick='showQR(\"" . $qr_file . "\")'>Seleccione el QR</a></td>
              <td><a href='../crud_asistenciaqr/index.php?id_usuario=" . $row['id_usuario'] . "' class='curso-link'>Gestionar Asistencia</a></td>

            </tr>";
    } else {
      echo "<tr><td colspan='3'>Nombre de usuario no disponible</td></tr>";
    }
  }
  echo "</table>";
} else {
  echo "No hay nada.";
}

$stmt->close();
$conn->close();
?>