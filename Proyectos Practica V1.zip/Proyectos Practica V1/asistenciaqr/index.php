<?php include 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Asistencia QR</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>


  <div id="searchResult"></div>

  <h2>Lista de Alumnos</h2>
  <div id="result"></div>


  <?php include 'read.php'; ?>
  <div id="qrModal" style="display:none;">
    <div id="qrContent">
      <img id="qrImage" src="" alt="QR Code">
      <button onclick="closeQR()">Cerrar</button>
    </div>
  </div>

  <script>
  function showQR(qrFile) {
    document.getElementById('qrImage').src = qrFile;
    document.getElementById('qrModal').style.display = 'block';
  }

  function closeQR() {
    document.getElementById('qrModal').style.display = 'none';
  }
  </script>
</body>