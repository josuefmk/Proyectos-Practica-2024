<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$id_usuario = isset($_GET['id_usuario']) ? intval($_GET['id_usuario']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $time_registro = date('Y-m-d H:i:s');

  $query = "INSERT INTO tbl_asistenciaqr (id_usuario, time_registro) VALUES (?, ?)";
  $stmt = $conn->prepare($query);

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("is", $id_usuario, $time_registro);

  if ($stmt->execute()) {
    echo "success";
  } else {
    echo "Error al confirmar la asistencia: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
  exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<link rel="stylesheet" href="styles.css">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirmar Asistencia</title>
</head>

<body>
  <div class="asistencia-container">
    <h1 class="asistencia-titulo">Confirmar Asistencia?</h1>
    <p>Aprete el Boton para confirmar!</p>
    <form id="asistenciaForm" class="asistencia-form">
      <button type="button" onclick="confirmarAsistencia()" class="asistencia-btn">Confirmar Asistencia</button>
    </form>
  </div>

  <div id="AsistenciaModal" style="display:none;">
    <div id="AsistenciaContent">

      <img id="ASImage" src="check.png" style="width:5%;">
      <p>Asistencia Confirmada!</p>
      <button onclick="closeQR()">Cerrar</button>
    </div>
  </div>

  <script>
  function confirmarAsistencia() {
    const formData = new FormData();
    formData.append("id_usuario", "<?php echo $id_usuario; ?>");

    fetch("<?php echo $_SERVER['PHP_SELF']; ?>", {
        method: "POST",
        body: formData
      })
      .then(response => response.text())
      .then(result => {
        if (result.trim() === "success") {
          showQR("check.png");
        } else {
          alert(result);
        }
      })
      .catch(error => console.error("Error:", error));
  }

  function showQR(qrFile) {
    document.getElementById('ASImage').src = qrFile;
    document.getElementById('AsistenciaModal').style.display = 'block';
  }

  function closeQR() {
    document.getElementById('AsistenciaModal').style.display = 'none';
  }
  </script>
</body>

</html>