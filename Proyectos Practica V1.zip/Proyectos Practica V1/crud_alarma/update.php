<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $dias_frecuencia = isset($_POST['dias_frecuencia']) ? implode(',', $_POST['dias_frecuencia']) : '';
    $hora = $conn->real_escape_string($_POST['hora']);
    $destinatario = $conn->real_escape_string($_POST['destinatario']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);

    $sql = "UPDATE tbl_alarmas SET dias_frecuencia='$dias_frecuencia', hora='$hora', destinatario='$destinatario', descripcion='$descripcion' WHERE id=$id";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_alarmas WHERE id=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Operación</h1>
    <form method="POST">

      <label class="label-frecuencia">Días de Frecuencia:</label><br>
      <div class="dias-frecuencia">
        <?php
        $diasSeleccionados = explode(',', $row['dias_frecuencia']);
        $dias = [
          1 => "Lunes",
          2 => "Martes",
          3 => "Miércoles",
          4 => "Jueves",
          5 => "Viernes",
          6 => "Sábado",
        ];

        foreach ($dias as $valor => $dia) {
          $checked = in_array($valor, $diasSeleccionados) ? 'checked' : '';
          echo "<label><input type='checkbox' name='dias_frecuencia[]' value='$valor' $checked> $dia</label><br>";
        }
        ?>
      </div>

      <label for="hora" class="label-hora">Hora:</label>
      <input type="time" id="hora" name="hora" value="<?php echo htmlspecialchars($row['hora']); ?>" required
        class="input-time">

      <label for="destinatario">Destinatario:</label>
      <select id="destinatario" name="destinatario" class="form-control" required>
        <option value="Relator" <?php if ($row['destinatario'] == 0)
          echo 'selected'; ?>>Relator</option>
        <option value="Administrativo" <?php if ($row['destinatario'] == 1)
          echo 'selected'; ?>>Administrativo</option>
        <option value="Alumno" <?php if ($row['destinatario'] == 2)
          echo 'selected'; ?>>Alumno</option>
      </select>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion"
        value="<?php echo htmlspecialchars($row['descripcion']); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>