<?php include 'conexion.php'; ?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Alarma</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <div id="alarmModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeModal" onclick="muestra_oculta('alarmModal')">&times;</span>

      <div id="modalMessage" class="modal-message">
        <h2>Alerta</h2>
      </div>
    </div>
  </div>
  <h1>Gestión de Alarma</h1>

  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>
      <label class="label-frecuencia">Días de Frecuencia:</label>
      <div class="dias-frecuencia">
        <label><input type="checkbox" name="dias_frecuencia[]" value="1"> Lunes</label>
        <label><input type="checkbox" name="dias_frecuencia[]" value="2"> Martes</label>
        <label><input type="checkbox" name="dias_frecuencia[]" value="3"> Miércoles</label>
        <label><input type="checkbox" name="dias_frecuencia[]" value="4"> Jueves</label>
        <label><input type="checkbox" name="dias_frecuencia[]" value="5"> Viernes</label>
        <label><input type="checkbox" name="dias_frecuencia[]" value="6"> Sábado</label>
      </div>

      <label for="hora" class="label-hora">Hora:</label>
      <input type="time" id="hora" name="hora" required class="input-time">

      <label for="destinatario">Destinatario:</label>
      <select id="destinatario" name="destinatario" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="Relator">Relator</option>
        <option value="Administrativo">Administrativo</option>
        <option value="Alumno">Alumno</option>
      </select>

      <label for="fecha_operacion">Fecha Operación:</label>
      <input type="date" id="fecha_operacion" name="fecha_operacion" required>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion" required>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_destinatario">Operación:</label>
    <select id="search_destinatario" name="search_destinatario">
      <option value="">-- Seleccionar --</option>
      <option value="Relator">Relator</option>
      <option value="Administrativo">Administrativo</option>
      <option value="Alumno">Alumno</option>
    </select>

    <label for="search_dias_frecuencia">Días de Frecuencia:</label>
    <select id="search_dias_frecuencia" name="search_dias_frecuencia">
      <option value="">-- Seleccionar --</option>
      <option value="1">Lunes</option>
      <option value="2">Martes</option>
      <option value="3">Miércoles</option>
      <option value="4">Jueves</option>
      <option value="5">Viernes</option>
      <option value="6">Sábado</option>
    </select>

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Productos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    function muestra_oculta(id) {
      if (document.getElementById) { //se obtiene el id
        var el = document.getElementById(id); //se define la variable 'el' igual a nuestro div
        el.style.display = (el.style.display == 'none') ? 'block' :
          'none'; //damos un atributo display:none que oculta el div
      }
    }




    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });

      function checkAlarms() {
        console.log("Verificando alarmas...");
        $.ajax({
          url: 'check_alarm.php',
          type: 'GET',
          dataType: 'json',
          success: function (response) {
            console.log(response);
            if (response.status === "No hay alarmas próximas") {
              console.log("Sin alarmas próximas");
            } else if (Array.isArray(response)) {
              let mensajeAlarma = '<ul class="alarms-scroll">';

              response.forEach(function (alarma) {
                mensajeAlarma += `<li>${alarma.descripcion} a las ${alarma.hora}</li>`;
              });

              mensajeAlarma += '</ul>';

              showModal(mensajeAlarma);
            }
          },
          error: function (xhr, status, error) {
            console.log('Error al verificar alarmas. Estado: ' + status);
            console.log('Mensaje de error: ' + error);
            console.log('Respuesta del servidor: ' + xhr.responseText);
          }
        });
      }

      // Verifica las alarmas cada minuto
      setInterval(checkAlarms, 60000);
    });

    function showModal(message) {
      document.getElementById("modalMessage").innerHTML = message;

      // Mostrar el modal
      let modal = document.getElementById("alarmModal");
      modal.style.display = "block";

      document.getElementById("closeModal").onclick = function () {
        modal.style.display = "none";
      };

      window.onclick = function (event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }
  </script>
</body>