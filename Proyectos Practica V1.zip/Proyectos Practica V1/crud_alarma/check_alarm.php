<?php
include 'conexion.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$now = new DateTime();


ob_start();

$query = "SELECT id, dias_frecuencia, hora, descripcion
          FROM tbl_alarmas
          WHERE FIND_IN_SET(?, dias_frecuencia) > 0";

$stmt = $conn->prepare($query);
if (!$stmt) {
  header('Content-Type: application/json');
  echo json_encode(["error" => "Error en la preparación de la consulta: " . $conn->error]);
  exit;
}

$dia_actual = $now->format('N');
$stmt->bind_param('i', $dia_actual);

if (!$stmt->execute()) {
  header('Content-Type: application/json');
  echo json_encode(["error" => "Error al ejecutar la consulta: " . $stmt->error]);
  exit;
}

$result = $stmt->get_result();
$alarmas_proximas = [];

while ($row = $result->fetch_assoc()) {
  $hora_alarma = DateTime::createFromFormat('H:i:s', $row['hora']);
  if ($hora_alarma === false) {
    echo "Error al convertir la hora: " . $row['hora'] . "\n";
    continue;
  }

  $diferencia_segundos = $hora_alarma->getTimestamp() - $now->getTimestamp();

  if ($diferencia_segundos > 0 && $diferencia_segundos <= 300) {
    $alarmas_proximas[] = $row;
  }
}

$stmt->close();
$conn->close();

$errores = ob_get_clean();
if (!empty($errores)) {
  header('Content-Type: application/json');
  echo json_encode(["error" => $errores]);
  exit;
}

header('Content-Type: application/json');
if (empty($alarmas_proximas)) {
  echo json_encode(["status" => "No hay alarmas próximas"]);
} else {
  echo json_encode($alarmas_proximas);
}