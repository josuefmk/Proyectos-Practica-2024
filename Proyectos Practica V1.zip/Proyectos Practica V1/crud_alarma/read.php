<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_destinatario = isset($_GET['search_destinatario']) ? $_GET['search_destinatario'] : '';
$search_dias_frecuencia = isset($_GET['search_dias_frecuencia']) ? $_GET['search_dias_frecuencia'] : '';


$dias_semana = [
  1 => 'Lunes',
  2 => 'Martes',
  3 => 'Miércoles',
  4 => 'Jueves',
  5 => 'Viernes',
  6 => 'Sábado',
  7 => 'Domingo'
];

$query = "SELECT id,dias_frecuencia, hora, destinatario, descripcion FROM tbl_alarmas WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_destinatario)) {
  $query .= " AND destinatario = ?";
  $types .= 's';
  $params[] = $search_destinatario;
}
if (!empty($search_dias_frecuencia)) {
  $query .= " AND FIND_IN_SET(?, dias_frecuencia) > 0";
  $types .= 'i';
  $params[] = $search_dias_frecuencia;
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Día Frecuencia</th>
                <th>Hora</th>
                <th>Destinatario</th>
                <th>Descripción</th>
                <th>Opciones</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    $dias_frecuencia_nombres = [];
    $dias_frecuencia = explode(',', $row['dias_frecuencia']);
    foreach ($dias_frecuencia as $dia) {
      $dia_num = (int) $dia;
      if (isset($dias_semana[$dia_num])) {
        $dias_frecuencia_nombres[] = $dias_semana[$dia_num];
      }
    }
    $dias_frecuencia_texto = implode(', ', $dias_frecuencia_nombres);

    echo "<tr id='row-{$row['id']}'>
            <td>" . htmlspecialchars($dias_frecuencia_texto) . "</td>
            <td>" . htmlspecialchars($row['hora']) . "</td>
            <td>" . htmlspecialchars($row['destinatario']) . "</td>
            <td>" . htmlspecialchars($row['descripcion']) . "</td>
            <td>
                <a href='update.php?id=" . urlencode($row['id']) . "' class='btn btn-sm btn-warning'>Editar</a>
                <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>