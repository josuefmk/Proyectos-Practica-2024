<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $dias_frecuencia = $_POST['dias_frecuencia'];
  $hora = $_POST['hora'];
  $destinatario = $_POST['destinatario'];
  $descripcion = $_POST['descripcion'];


  if (isset($_POST['dias_frecuencia'])) {
    $dias_frecuencia = implode(',', $_POST['dias_frecuencia']);
  } else {
    $dias_frecuencia = '';
  }

  $stmt = $conn->prepare("INSERT INTO tbl_alarmas (dias_frecuencia, hora, destinatario,descripcion) VALUES ( ?, ?,?,?)");
  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssss", $dias_frecuencia, $hora, $destinatario, $descripcion);

  if ($stmt->execute()) {
    echo "Alarma agregada correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}



?>