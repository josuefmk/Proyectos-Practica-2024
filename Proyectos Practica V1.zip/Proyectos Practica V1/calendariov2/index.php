<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Calendario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <div id="calendario">
    <h2 id="mes-anio"></h2>

    <div class="navegacion">
      <label for="select-mes">Mes:</label>
      <select id="select-mes"></select>

      <label for="select-año">Año:</label>
      <select id="select-año"></select>
    </div>

    <div class="dias-semana">
      <div class="box-dia" data-dia="0">Domingo</div>
      <div class="box-dia" data-dia="1">Lunes</div>
      <div class="box-dia" data-dia="2">Martes</div>
      <div class="box-dia" data-dia="3">Miércoles</div>
      <div class="box-dia" data-dia="4">Jueves</div>
      <div class="box-dia" data-dia="5">Viernes</div>
      <div class="box-dia" data-dia="6">Sábado</div>
    </div>

    <div id="calendario-mes"></div>
    <div id="descripcion" class="descripcion"></div>

    <div id="fecha-seleccionada" style="display:none;">
      <h3>Fechas Seleccionadas:</h3>
      <p id="fecha-detalles"></p>
    </div>

    <div id="input-dia-seleccionado" style="display:none;"></div>
  </div>

  <script>
  let mes = new Date().getMonth();
  let año = new Date().getFullYear();
  let diaSemanaSeleccionado = null;
  let diaSeleccionadoDelMes = null;

  function obtenerNombreMes(mes) {
    const nombresMes = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    return nombresMes[mes];
  }

  function obtenerNombreDia(dia) {
    const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    return dias[dia];
  }

  function cargarCalendario(mes, año) {
    const diasEnMes = new Date(año, mes + 1, 0).getDate();
    const primerDiaMes = new Date(año, mes, 1).getDay();

    $('#calendario-mes').empty();
    $('#mes-anio').text(`${obtenerNombreMes(mes)} ${año}`);
    $('#descripcion').hide().text('');
    $('#input-dia-seleccionado').hide();
    $('#fecha-seleccionada').hide();

    diaSemanaSeleccionado = null;
    diaSeleccionadoDelMes = null;
    $('.box-dia').removeClass('seleccionado');
    $('.dia').removeClass('seleccionado neutro');

    for (let i = 0; i < primerDiaMes; i++) {
      $('#calendario-mes').append('<div class="dia vacio"></div>');
    }

    for (let dia = 1; dia <= diasEnMes; dia++) {
      $('#calendario-mes').append(
        `<div class="dia neutro" data-dia="${dia}" data-dia-semana="${new Date(año, mes, dia).getDay()}">${dia}</div>`
      );
    }
  }

  function manejarSeleccionDiaSemana(diaSemana) {

    if (diaSeleccionadoDelMes !== null) {
      $(`.dia[data-dia="${diaSeleccionadoDelMes}"]`).removeClass('seleccionado');
      diaSeleccionadoDelMes = null;
    }

    if (diaSemanaSeleccionado === diaSemana) {

      diaSemanaSeleccionado = null;
      $('.box-dia').removeClass('seleccionado');
      $('.dia').removeClass('neutro').addClass('bloqueado');
      return;
    }


    diaSemanaSeleccionado = diaSemana;
    $('.box-dia').removeClass('seleccionado');
    $(`.box-dia[data-dia="${diaSemana}"]`).addClass('seleccionado');

    $('.dia').each(function() {
      const diaSemanaCalendario = parseInt($(this).attr('data-dia-semana'));
      if (diaSemanaCalendario === diaSemana) {
        $(this).removeClass('bloqueado').addClass('neutro');
      } else {
        $(this).removeClass('neutro').addClass('bloqueado');
      }
    });
  }

  function mostrarFechaSeleccionada() {
    if (diaSemanaSeleccionado !== null && diaSeleccionadoDelMes !== null) {
      const nombreDia = obtenerNombreDia(diaSemanaSeleccionado);
      const nombreMes = obtenerNombreMes(mes);
      $('#fecha-detalles').text(`${nombreDia} ${diaSeleccionadoDelMes} de ${nombreMes} de ${año}`);
      $('#fecha-seleccionada').show();
    }
  }

  $(document).ready(function() {
    cargarCalendario(mes, año);

    for (let i = 0; i < 12; i++) {
      $('#select-mes').append(`<option value="${i}">${obtenerNombreMes(i)}</option>`);
    }
    $('#select-mes').val(mes);

    const anioActual = new Date().getFullYear();
    for (let i = anioActual - 6; i <= anioActual + 2; i++) {
      $('#select-año').append(`<option value="${i}">${i}</option>`);
    }
    $('#select-año').val(año);


    $('#select-mes').change(function() {
      mes = parseInt($(this).val());
      cargarCalendario(mes, año);
      reiniciarSeleccionDiaSemana();
    });


    $('#select-año').change(function() {
      año = parseInt($(this).val());
      cargarCalendario(mes, año);
      reiniciarSeleccionDiaSemana();
    });


    $('.box-dia').click(function() {
      const diaSemana = parseInt($(this).attr('data-dia'));
      manejarSeleccionDiaSemana(diaSemana);
    });


    $('#calendario-mes').on('click', '.dia', function() {

      if (diaSemanaSeleccionado === null) {
        alert('Primero debes seleccionar un día de la semana.');
        return;
      }

      if ($(this).hasClass('bloqueado')) {
        return;
      }

      const dia = parseInt($(this).attr('data-dia'));

      if ($(this).hasClass('seleccionado')) {
        $(this).removeClass('seleccionado').addClass('neutro');
        diaSeleccionadoDelMes = null;
      } else {
        $('.dia.seleccionado').removeClass('seleccionado').addClass('neutro');
        $(this).removeClass('neutro').addClass('seleccionado');
        diaSeleccionadoDelMes = dia;
      }
      mostrarFechaSeleccionada();
    });


    function reiniciarSeleccionDiaSemana() {
      diaSemanaSeleccionado = null;
      $('.box-dia').removeClass('seleccionado');
      $('.dia').removeClass('neutro').addClass('bloqueado');
    }
  });
  </script>

</body>

</html>