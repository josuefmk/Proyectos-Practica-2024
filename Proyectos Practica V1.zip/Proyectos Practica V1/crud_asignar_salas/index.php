<?php
include 'conexion.php';

?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Horarios de Cursos</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Horario</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Horario</h2>
      <label for="id_curso">ID Curso:</label>
      <select id="id_curso" name="id_curso">
        <option value="">Seleccione un Curso</option>
        <?php echo $cursoaddOptions; ?>
      </select>

      <label for="diasem">Día de la Semana:</label>
      <select id="diasem" name="diasem" class="form-control" required>
        <option value=""> Seleccionar Día</option>
        <option value="1">1 (Lunes)</option>
        <option value="2">2 (Martes)</option>
        <option value="3">3 (Miércoles)</option>
        <option value="4">4 (Jueves)</option>
        <option value="5">5 (Viernes)</option>
        <option value="6">6 (Sábado)</option>
      </select>
      <label for="id_sala">ID Sala:</label>
      <select id="id_sala" name="id_sala" class="form-control" required>
        <option value=""> Seleccionar una Sala</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
      </select>
      <label for="tipo_clase">Tipo Clase:</label>
      <select id="tipo_clase" name="tipo_clase" class="form-control" required>
        <option value=""> Seleccionar Tipo Clase</option>
        <option value="1">Teoría</option>
        <option value="2">Práctico</option>
      </select>

      <input type="submit" value="Agregar Horario" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Horario</h3>

    <label for="search_id_curso">Curso:</label>
    <select id="search_id_curso" name="search_id_curso">
      <option value="">Seleccione un Curso</option>
      <?php echo $cursoOptions; ?>
    </select>

    <label for="search_id_sala">Sala:</label>
    <select id="search_id_sala" name="search_id_sala">
      <option value="">Seleccione una Sala</option>
      <?php
      for ($i = 1; $i <= 9; $i++) {
        echo "<option value='$i'>$i</option>";
      }
      ?>
    </select>

    <label for="diasem">Día de la Semana:</label>
    <select id="diasem" name="diasem" class="form-control">
      <option value=""> Seleccionar Día</option>
      <option value="1">1 (Lunes)</option>
      <option value="2">2 (Martes)</option>
      <option value="3">3 (Miércoles)</option>
      <option value="4">4 (Jueves)</option>
      <option value="5">5 (Viernes)</option>
      <option value="6">6 (Sábado)</option>
    </select>

    <input type="submit" value="Buscar" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>
  <h2>Lista de Horarios</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>


</body>