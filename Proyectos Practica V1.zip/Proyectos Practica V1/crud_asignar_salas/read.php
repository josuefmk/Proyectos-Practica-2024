<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$id_curso = isset($_GET['search_id_curso']) ? $_GET['search_id_curso'] : '';
$id_sala = isset($_GET['search_id_sala']) ? $_GET['search_id_sala'] : '';
$diasem = isset($_GET['diasem']) ? $_GET['diasem'] : '';

$dias_semana = [
  1 => 'Lunes',
  2 => 'Martes',
  3 => 'Miércoles',
  4 => 'Jueves',
  5 => 'Viernes',
  6 => 'Sábado',
];
$tipoclase = [
  1 => 'Teoría',
  2 => 'Práctico',
];

$query = "SELECT id_asigna_sala, id_sala, id_curso, diasem, tipo_clase FROM tbl_asignar_salas WHERE 1=1";

if ($id_curso != '') {
  $query .= " AND id_curso = '$id_curso'";
}
if ($id_sala != '') {
  $query .= " AND id_sala = '$id_sala'";
}
if ($diasem != '') {
  $query .= " AND diasem = '$diasem'";
}

$stmt = $conn->prepare($query);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>ID Sala</th>
                <th>ID Curso</th>
                <th>Día de Semana</th>
                <th>Tipo De Clase</th>
                <th>Opciones</th>
            </tr>";

  while ($row = $result->fetch_assoc()) {
    $dias_frecuencia_nombres = [];
    $dias_clases = str_split($row['diasem']);
    foreach ($dias_clases as $dia) {
      $dia_num = (int) $dia;
      if (isset($dias_semana[$dia_num])) {
        $dias_frecuencia_nombres[] = $dias_semana[$dia_num];
      }
    }
    $dias_frecuencia_texto = implode(', ', $dias_frecuencia_nombres);

    $dias_nombres = [];
    $tipo_c = str_split($row['tipo_clase']);
    foreach ($tipo_c as $tc) {
      $tipo = (int) $tc;
      if (isset($tipoclase[$tipo])) {
        $dias_nombres[] = $tipoclase[$tipo];
      }
    }
    $tipo_clases_texto = implode(', ', $dias_nombres);

    // Añadir un id único para cada fila
    echo "
          <tr id='row-" . htmlspecialchars($row['id_asigna_sala']) . "'>
           <td>" . htmlspecialchars($row['id_sala']) . "</td>
           <td>" . htmlspecialchars($row['id_curso']) . "</td>
           <td>" . htmlspecialchars($dias_frecuencia_texto) . "</td>
           <td>" . htmlspecialchars($tipo_clases_texto) . "</td>
           <td>
              <a href='update.php?id_asigna_sala=" . urlencode($row['id_asigna_sala']) . "' class='btn btn-sm btn-warning'>Editar</a>
              <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_asigna_sala'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
           </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id: id,
          action: 'delete' // Asegúrate de enviar la acción de eliminación
        },
        success: function (response) {
          if (response.trim() === 'Horario eliminado correctamente.') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }
</script>