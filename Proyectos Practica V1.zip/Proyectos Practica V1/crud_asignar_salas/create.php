<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  $action = $_POST['action'] ?? null;

  if ($action === null) {
    echo "Error: Acción no definida.";
    exit;
  }

  if ($action === 'check') {
    // Obtener los valores para verificación
    $id_curso = $_POST['id_curso'];
    $diasem = $_POST['diasem'];
    $id_sala = $_POST['id_sala'];

    // Verificar si el id_curso ya existe
    $queryExists = "SELECT id_asigna_sala FROM tbl_asignar_salas WHERE id_curso = ?";
    $stmt = $conn->prepare($queryExists);
    $stmt->bind_param("i", $id_curso);
    $stmt->execute();
    $resultExists = $stmt->get_result();

    if ($resultExists->num_rows > 0) {
      echo 'Existe';
      exit;
    }

    // Solo si no existe el curso, verificamos conflictos en la sala
    $queryConflict = "SELECT id_asigna_sala FROM tbl_asignar_salas WHERE id_sala = ? AND diasem = ?";
    $stmtConflict = $conn->prepare($queryConflict);
    $stmtConflict->bind_param("ii", $id_sala, $diasem);
    $stmtConflict->execute();
    $resultConflict = $stmtConflict->get_result();

    if ($resultConflict->num_rows > 0) {
      echo 'conflict';  // Hay un conflicto de sala
    } else {
      echo 'ok';
    }

    $stmt->close();
    $stmtConflict->close();
  } elseif ($action === 'delete') {
    // Eliminar el horario anterior
    $id_curso = $_POST['id_curso'];

    $queryDelete = "DELETE FROM tbl_asignar_salas WHERE id_curso = ?";
    $stmtDelete = $conn->prepare($queryDelete);
    $stmtDelete->bind_param("i", $id_curso);

    if ($stmtDelete->execute()) {
      echo 'Horario eliminado correctamente.';
    } else {
      echo 'Error al eliminar el horario: ' . $stmtDelete->error;
    }

    $stmtDelete->close();
  } elseif ($action === 'add') {
    // Agregar un nuevo horario
    $id_sala = $_POST['id_sala'];
    $id_curso = $_POST['id_curso'];
    $diasem = $_POST['diasem'];
    $tipo_clase = $_POST['tipo_clase'];

    // Verificar si ya existe un horario para ese curso y sala
    $queryExists = "SELECT id_asigna_sala FROM tbl_asignar_salas WHERE id_curso = ? AND diasem = ? AND id_sala = ?";
    $stmtExists = $conn->prepare($queryExists);
    $stmtExists->bind_param("iii", $id_curso, $diasem, $id_sala);
    $stmtExists->execute();
    $resultExists = $stmtExists->get_result();

    if ($resultExists->num_rows > 0) {
      echo 'Ya existe un horario para este curso en esta sala en este día.';
      $stmtExists->close();
      exit;
    }

    // Consulta para insertar
    $stmtInsert = $conn->prepare("INSERT INTO tbl_asignar_salas (id_sala, id_curso, diasem, tipo_clase) VALUES (?, ?, ?, ?)");
    if ($stmtInsert === false) {
      die("Error en la preparación de la consulta: " . $conn->error);
    }

    $stmtInsert->bind_param("iiis", $id_sala, $id_curso, $diasem, $tipo_clase);
    if ($stmtInsert->execute()) {
      echo "Datos agregados correctamente.";
    } else {
      echo "Error al guardar el horario: " . $stmtInsert->error;
    }

    $stmtInsert->close();
  }
}

$conn->close();






?>