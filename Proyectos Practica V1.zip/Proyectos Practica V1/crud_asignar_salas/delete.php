<?php
include 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['id'] ?? null;

  if ($id) {
    $stmt = $conn->prepare("DELETE FROM tbl_asignar_salas WHERE id_asigna_sala = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
      echo 'Horario eliminado correctamente.';
    } else {
      echo 'Error al eliminar el horario: ' . $stmt->error;
    }
    $stmt->close();
  } else {
    echo 'Error: ID no proporcionado.';
  }
}

$conn->close();
?>