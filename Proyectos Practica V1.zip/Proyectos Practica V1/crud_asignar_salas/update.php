<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  $id = $_GET['id_asigna_sala'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $diasem = isset($_POST['diasem']) ? implode(',', $_POST['diasem']) : '';
    $id_sala = $conn->real_escape_string($_POST['id_sala']);
    $tipo_clase = $conn->real_escape_string($_POST['tipo_clase']);
    $id_curso = $conn->real_escape_string($_POST['id_curso']);

    $sql = "UPDATE tbl_asignar_salas SET id_sala='$id_sala', id_curso='$id_curso', tipo_clase='$tipo_clase', diasem='$diasem' WHERE id_asigna_sala=$id";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_asignar_salas WHERE id_asigna_sala=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Operación</h1>
    <form method="POST">

      <label for="id_sala">ID Sala:</label>
      <input type="text" id="id_sala" name="id_sala" value="<?php echo htmlspecialchars($row['id_sala']); ?>" required>

      <label class="label-frecuencia">Días de Clases:</label><br>
      <div class="dias-frecuencia">
        <?php
        $diasSeleccionados = explode(',', $row['diasem']);
        $dias = [
          1 => "Lunes",
          2 => "Martes",
          3 => "Miércoles",
          4 => "Jueves",
          5 => "Viernes",
          6 => "Sábado",
        ];

        foreach ($dias as $valor => $dia) {
          $checked = in_array($valor, $diasSeleccionados) ? 'checked' : '';
          echo "<label><input type='checkbox' name='diasem[]' value='$valor' $checked> $dia</label><br>";
        }
        ?>
      </div>

      <label for="id_sala">ID Sala:</label>
      <input type="text" id="id_sala" name="id_sala" value="<?php echo htmlspecialchars($row['id_sala']); ?>" required>

      <label for="tipo_clase">Tipo Clase:</label>
      <select id="tipo_clase" name="tipo_clase" class="form-control" required>
        <option value="1" <?php if ($row['tipo_clase'] == 1)
          echo 'selected'; ?>>Teoría</option>
        <option value="2" <?php if ($row['tipo_clase'] == 2)
          echo 'selected'; ?>>Práctico</option>

      </select>



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>