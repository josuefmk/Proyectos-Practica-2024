<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$sql = "
    SELECT nombre,id_curso,dias_clases,hora_desde,hora_hasta,fecha_inicio
    FROM tbl_cursos cursos JOIN tbl_centrosdeingreso centros ON cursos.id_centronegocio = centros.id_centroingreso;
";
$result = mysqli_query($conn, $sql);
$result_cursos = $result;
$query = $sql;

$diasArray = array('lun', 'mar', 'mie', 'jue', 'vie', 'sab');
$cursoOptions = "<option=''>SELECCIONE CURSO</option>";
while ($row = mysqli_fetch_assoc($result)) {

  $cursoOptions .= "<option value='" . $row['id_curso'] . "'>";
  $cursoOptions .= $row['nombre'];
  for ($i = 0; $i < strlen($row['dias_clases']); $i++) {
    $cursoOptions .= " " . $diasArray[$i] . " ";
  }
  $cursoOptions .= " " . $row['hora_desde'] . " " . $row['hora_hasta'] . " " . $row['fecha_inicio'];
  $cursoOptions .= "</option>";
}
$cursoaddOptions = $cursoOptions;

$dias_semana = [
  1 => 'Lunes',
  2 => 'Martes',
  3 => 'Miércoles',
  4 => 'Jueves',
  5 => 'Viernes',
  6 => 'Sábado',
];

$tipoclase = [
  1 => 'Teoría',
  2 => 'Práctico',
];
?>