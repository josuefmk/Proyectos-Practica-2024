
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('addForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append('action', 'add');

    fetch('create.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.text())
      .then(data => {
        document.getElementById('result').innerHTML = data;
        this.reset();
        loadRecords();
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });

  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('tableContainer').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }

  loadRecords();
});

  $(document).ready(function() {
    // Limpiar los filtros de búsqueda
    $('#clearFilterBtn').on('click', function() {
        $('#search_id_curso').val('');
        $('#search_id_sala').val('');
        $('#diasem').val('');
        $('#searchForm').submit();
    });
});


$(document).ready(function () {
  $('#toggleAddFormBtn').click(function () {
    $('#addFormContainer').toggle();
  });

  $('#addForm').on('submit', function (event) {
    event.preventDefault(); // Evita el envío del formulario por defecto

    var id_curso = $('#id_curso').val();
    var diasem = $('#diasem').val();
    var id_sala = $('#id_sala').val();
    var tipo_clase = $('#tipo_clase').val();

    // Verificar si el id_curso ya existe
    $.post('create.php', {
      id_curso: id_curso,
      diasem: diasem,
      id_sala: id_sala,
      action: 'check'
    }, function (response) {
      if (response === 'Existe') {
        manejarConfirmacionEliminar(id_curso, diasem, id_sala, tipo_clase);
      } else if (response === 'conflict') {
        manejarAlerta('Conflicto: ya existe un curso asignado a esta sala en ese día.', false);
      } else {
        agregarNuevoHorario(id_curso, diasem, id_sala, tipo_clase);
      }
    });
  });

  function manejarAlerta(mensaje, esExitoso) {
    if (esExitoso) {
      alert('Éxito: ' + mensaje);
    } else {
      alert('Error: ' + mensaje);
    }
  }

  function manejarConfirmacionEliminar(id_curso, diasem, id_sala, tipo_clase) {
    if (confirm('Este curso ya tiene un horario asignado. ¿Desea eliminar el horario existente?')) {
      // Eliminar el horario existente
      $.post('create.php', {
        id_curso: id_curso,
        action: 'delete'
      }, function (deleteResponse) {
        if (deleteResponse.includes('correctamente')) {
          manejarAlerta(deleteResponse, true);
          agregarNuevoHorario(id_curso, diasem, id_sala, tipo_clase);
        } else {
          manejarAlerta('Error al eliminar el horario existente.', false);
        }
      });
    } else {
      manejarAlerta('El horario no ha sido eliminado.', false);
    }
  }

  function agregarNuevoHorario(id_curso, diasem, id_sala, tipo_clase) {
    $.post('create.php', {
      id_curso: id_curso,
      diasem: diasem,
      id_sala: id_sala,
      tipo_clase: tipo_clase,
      action: 'add'
    }, function (addResponse) {
      if (addResponse.includes('correctamente')) {
        manejarAlerta('Horario agregado correctamente.', true);
      } else {
        manejarAlerta('Error al agregar el horario: ' + addResponse, false);
      }
    });
  }
});
