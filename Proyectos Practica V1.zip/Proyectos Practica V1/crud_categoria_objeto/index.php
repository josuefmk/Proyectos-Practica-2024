<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>CRUD Categoria Objeto</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleFormBtn">Agregar Categoria Objeto</button>
  <div class="form-container-add" id="CategoriaFormContainer">
    <form id="CategoriaForm" method="post" action="insert.php">
      <h2>Nuevo Categoria Objeto</h2>
      <label for="id_categoria_objeto">ID Categoria:</label>
      <input type="text" id="id_categoria_objeto" name="id_categoria_objeto" required>
      <label for="nombre_categoria">Nombre Categoria:</label>
      <input type="text" id="nombre_categoria" name="nombre_categoria" required>
      <label for="descripcion_categoria">Descripcion Categoria:</label>
      <input type="text" id="descripcion_categoria" name="descripcion_categoria" required>
      <input type="submit" value="Agregar Categoria Objeto" class="submit-btn">
    </form>
  </div>

  <form id="searchForm">
    <h3>Buscar por ID Categoria y Nombre Categoria</h3>
    <label for="search_id_categoria_objeto">ID Encuesta:</label>
    <input type="text" id="search_id_categoria_objeto" name="search_id_categoria_objeto">
    <label for="search_nombre_categoria">Nombre Empresa:</label>
    <input type="text" id="search_nombre_categoria" name="search_nombre_categoria">
    <input type="submit" value="Buscar">
  </form>

  <div id="searchResult"></div>
  <h1>Lista de Categoria Objeto</h1>
  <div id="result"></div>
  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

</body>

</html>