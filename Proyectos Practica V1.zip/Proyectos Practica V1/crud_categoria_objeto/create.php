<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_categoria_objeto = $_POST['id_categoria_objeto'];
  $nombre_categoria = $_POST['nombre_categoria'];
  $descripcion_categoria = $_POST['descripcion_categoria'];

  $sql = "INSERT INTO tbl_categoria_objetos (id_categoria_objeto, nombre_categoria, descripcion_categoria)
            VALUES ('$id_categoria_objeto', '$nombre_categoria', '$descripcion_categoria')";

  if ($conn->query($sql) === TRUE) {
    echo "Encuesta guardada correctamente";
  } else {
    echo "Error al guardar la encuesta: " . $sql . "<br>" . $conn->error;
  }


}
?>