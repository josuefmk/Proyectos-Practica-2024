<?php
include 'conexion.php';

if (isset($_POST['id'])) {
  $id = $_POST['id'];


  if (filter_var($id, FILTER_VALIDATE_INT) === false) {
    echo 'error';
    exit;
  }

  $sql = "DELETE FROM tbl_categoria_objetos WHERE id_categoria_objeto='$id'";

  if ($conn->query($sql) === TRUE) {
    echo 'success';
  } else {
    echo 'error';
  }
} else {
  echo 'error';
}

$conn->close();
?>