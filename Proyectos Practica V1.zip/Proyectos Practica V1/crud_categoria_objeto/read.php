<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_id_categoria_objeto = isset($_GET['search_id_categoria_objeto']) ? $_GET['search_id_categoria_objeto'] : '';
$search_nombre_categoria = isset($_GET['search_nombre_categoria']) ? $_GET['search_nombre_categoria'] : '';

// Consulta SQL
$sql = "SELECT id_categoria_objeto, nombre_categoria, descripcion_categoria FROM tbl_categoria_objetos WHERE 1=1";

if ($search_id_categoria_objeto !== '') {
  $sql .= " AND id_categoria_objeto LIKE '%" . $conn->real_escape_string($search_id_categoria_objeto) . "%'";
}
if ($search_nombre_categoria !== '') {
  $sql .= " AND nombre_categoria LIKE '%" . $conn->real_escape_string($search_nombre_categoria) . "%'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='1'>
          <tr>
            <th>Nombre Categoria</th>
            <th>Descripcion Categoria</th>
             <th>Opciones</th>
          </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_categoria_objeto']}'>
            <td>{$row['nombre_categoria']}</td>
            <td>{$row['descripcion_categoria']}</td>
            <td>
              <a href='update.php?id={$row['id_categoria_objeto']}'>Editar</a>
              <a href='javascript:void(0);' onclick='confirmDelete({$row['id_categoria_objeto']});'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$conn->close();
?>

<script>
// Confirmación de eliminación de un registro
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        if (response === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro.');
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>