<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Categoria</title>
</head>

<body>

  <?php
  include 'conexion.php';


  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_categoria_objeto = $conn->real_escape_string($_POST['id_categoria_objeto']);
    $nombre_categoria = $conn->real_escape_string($_POST['nombre_categoria']);


    $sql = "UPDATE tbl_categoria_objetos SET nombre_categoria='$nombre_categoria' WHERE id_categoria_objeto=$id";

    if ($conn->query($sql)) {
      echo "<p class='success'>Registro actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_categoria_objetos WHERE id_categoria_objeto=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Categoría</h1>
    <form method="POST">
      <label for="id_categoria_objeto">ID Categoria Objeto:</label>
      <input type="text" id="id_categoria_objeto" name="id_categoria_objeto"
        value="<?php echo htmlspecialchars($row['id_categoria_objeto']); ?>" required>

      <label for="nombre_categoria">Nombre Categoria:</label>
      <input type="text" id="nombre_categoria" name="nombre_categoria"
        value="<?php echo htmlspecialchars($row['nombre_categoria']); ?>" required>
      <input type="submit" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>