<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$empleadosOptions = '';
$fechaOptions = '';

$result_empleados = $conn->query("SELECT DISTINCT id_empleado FROM tbl_atrasos");
while ($row = $result_empleados->fetch_assoc()) {
  $empleadosOptions .= "<option value='{$row['id_empleado']}'>{$row['id_empleado']}</option>";
}
$result_fecha = $conn->query("SELECT DISTINCT fecha_atraso FROM tbl_atrasos");
while ($row = $result_fecha->fetch_assoc()) {
  $fechaOptions .= "<option value='{$row['fecha_atraso']}'>{$row['fecha_atraso']}</option>";
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Atrasos</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>


      <label for="fecha_atraso">Fecha de Atrasao:</label>
      <input type="date" id="fecha_atraso" name="fecha_atraso" required>

      <label for="minutos_atraso">Mínutos de Atrasos:</label>
      <input type="number" id="minutos_atraso" name="minutos_atraso" required>

      <label for="id_empleado">ID de Empleado:</label>
      <select id="id_empleado" name="id_empleado">
        <option value="">Seleccione un Empleado</option>
        <?php echo $empleadosOptions; ?>
      </select>
      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_fecha_atraso">Feche Atraso:</label>
    <select id="search_fecha_atraso" name="search_fecha_atraso">
      <option value="">Seleccione una Fecha</option>
      <?php echo $fechaOptions; ?>
    </select>

    <label for="search_idempleado">ID de Empleado :</label>
    <select id="search_idempleado" name="search_idempleado">
      <option value="">Seleccione un ID </option>
      <?php echo $empleadosOptions; ?>
    </select>



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>