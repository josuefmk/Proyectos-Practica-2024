<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha_atraso = $_POST['fecha_atraso'];
  $minutos_atraso = $_POST['minutos_atraso'];
  $id_empleado = $_POST['id_empleado'];

  $stmt = $conn->prepare("INSERT INTO tbl_atrasos( fecha_atraso, minutos_atraso, id_empleado) VALUES ( ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sii", $fecha_atraso, $minutos_atraso, $id_empleado);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>