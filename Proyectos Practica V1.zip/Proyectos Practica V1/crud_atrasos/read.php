<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_fecha_atraso = isset($_GET['search_fecha_atraso']) ? $_GET['search_fecha_atraso'] : '';
$search_idempleado = isset($_GET['search_idempleado']) ? $_GET['search_idempleado'] : '';



$query = "SELECT * FROM tbl_atrasos WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_fecha_atraso)) {
  $query .= " AND fecha_atraso = ?";
  $types .= 's';
  $params[] = $search_fecha_atraso;
}
if (!empty($search_idempleado)) {
  $query .= " AND 	id_empleado = ?";
  $types .= 's';
  $params[] = $search_idempleado;
}


$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Fecha de Atraso</th>
                <th>Mínutos de atraso</th>
                <th>ID de Empleado</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['fecha_atraso']) . "</td>
           <td>" . htmlspecialchars($row['minutos_atraso']) . "</td>
           <td>" . htmlspecialchars($row['id_empleado']) . "</td>
            <td>
              <a href='update.php?id_atrasos=" . urlencode($row['id_atrasos']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_atrasos'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_atrasos: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>