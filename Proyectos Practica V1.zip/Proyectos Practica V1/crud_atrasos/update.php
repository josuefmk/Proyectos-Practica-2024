<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Atraso</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_atrasos'])) {
    $id = $_GET['id_atrasos'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $fecha_atraso = $conn->real_escape_string($_POST['fecha_atraso']);
    $minutos_atraso = $conn->real_escape_string($_POST['minutos_atraso']);
    $id_empleado = $conn->real_escape_string($_POST['id_empleado']);


    $sql = "UPDATE tbl_atrasos
        SET fecha_atraso='$fecha_atraso', minutos_atraso='$minutos_atraso', id_empleado='$id_empleado',
        WHERE id_atrasos='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_atrasos WHERE id_atrasos=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Atraso</h1>
    <form method="POST">
      <label for="fecha_atraso">Fecha Atraso:</label>
      <input type="date" id="fecha_atraso" name="fecha_atraso"
        value="<?php echo htmlspecialchars($row['fecha_atraso'] ?? ''); ?>" required>

      <label for="minutos_atraso">Mínutos de atraso:</label>
      <input type="number" id="minutos_atraso" name="minutos_atraso"
        value="<?php echo htmlspecialchars($row['minutos_atraso'] ?? ''); ?>" required>

      <label for="id_empleado">ID de empleado:</label>
      <input type="number" id="id_empleado" name="id_empleado"
        value="<?php echo htmlspecialchars($row['id_empleado'] ?? ''); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>