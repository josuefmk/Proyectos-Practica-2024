<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Asistencia QR</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_usuario'])) {
    $id = $_GET['id_usuario'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_usuario = $conn->real_escape_string($_POST['id_usuario']);



    $sql = "UPDATE tbl_asistenciaqr SET id_usuario='$id_usuario' WHERE id_usuario='$id'";


    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_asistenciaqr WHERE id_usuario=$id");
    $row = $result->fetch_assoc();
    $id_usuario = isset($_GET['id_usuario']) ? $_GET['id_usuario'] : "";

    $sql = "
   SELECT id_usuario,nombres,apellidos FROM tbl_usuarios
";
    $result_usuario = $conn->query($sql);
    $centros = [];
    if ($result_usuario) {
      if ($result_usuario->num_rows > 0) {
        while ($row_user = $result_usuario->fetch_assoc()) {
          $centros[] = $row_user;
        }
      }
    }

  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Asistencia QR</h1>
    <form method="POST">
      <label for="id_usuario">Nombre Usuario:</label>
      <select id="id_usuario" name="id_usuario" required>
        <option value="">Seleccione un Nombre</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_usuario'] == $id_usuario) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_usuario']) . "' $selected>" . htmlspecialchars($centro['nombres']) . " " . $centro['apellidos'] . "</option>";
        }
        ?>
      </select>



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>