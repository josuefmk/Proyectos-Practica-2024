<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);



$id_usuario = isset($_GET['id_usuario']) ? $_GET['id_usuario'] : "";

$sql = "
   SELECT id_usuario,nombres,apellidos FROM tbl_usuarios
";
$result = $conn->query($sql);
$centros = [];
if ($result) {
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $centros[] = $row;
    }
  }
}



?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Asistencia QR</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Usuario</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar un Nuevo Usuario</h2>

      <label for="id_usuario">Nombre Usuario:</label>
      <select id="id_usuario" name="id_usuario" required>
        <option value="">Seleccione un Nombre</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_usuario'] == $id_usuario) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_usuario']) . "' $selected>" . htmlspecialchars($centro['nombres']) . " " . $centro['apellidos'] . "</option>";
        }
        ?>
      </select>






      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Usuario</h3>

    <label for="search_usuario">Nombre Usuario:</label>
    <select id="search_usuario" name="search_usuario" required>
      <option value="">Seleccione un Nombre</option>
      <?php
      foreach ($centros as $centro) {
        $selected = ($centro['id_usuario'] == $id_usuario) ? 'selected' : '';
        echo "<option value='" . htmlspecialchars($centro['id_usuario']) . "' $selected>" . htmlspecialchars($centro['nombres']) . " " . $centro['apellidos'] . "</option>";
      }
      ?>
    </select>

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>