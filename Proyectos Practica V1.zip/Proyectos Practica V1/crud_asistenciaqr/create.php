<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_usuario = $_POST['id_usuario'];
  $time_registro = date('Y-m-d H:i:s');


  $stmt = $conn->prepare("INSERT INTO tbl_diplomas( id_usuario, time_registro) VALUES ( ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sisis", $codigo_matricula, $id_curso, $fecha, $estado, $fecha2);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el Usuario: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>