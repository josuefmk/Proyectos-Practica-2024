<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_subclase = $_POST['id_subclase'];
  $estado = $_POST['estado'];
  $usuario_creacion = $_POST['usuario_creacion'];
  $time_creacion = $_POST['time_creacion'];
  $codigo = $_POST['codigo'];
  $nombre = $_POST['nombre'];
  #$contador = !empty($_POST['contador']) ? $_POST['contador'] : NULL;
  $nombre_corto = !empty($_POST['nombre_corto']) ? $_POST['nombre_corto'] : NULL;
  $c_sence = !empty($_POST['c_sence']) ? (int) $_POST['c_sence'] : NULL;

  $url_video = !empty($_POST['url_video']) ? $_POST['url_video'] : NULL;
  $titulo_web = !empty($_POST['titulo_web']) ? $_POST['titulo_web'] : NULL;
  $meta_descriptor = !empty($_POST['meta_descriptor']) ? $_POST['meta_descriptor'] : NULL;
  $alt = !empty($_POST['alt']) ? $_POST['alt'] : NULL;

  $stmt = $conn->prepare("INSERT INTO tbl_centrosdeingreso(id_subclase, estado, usuario_creacion, time_creacion, codigo, nombre, nombre_corto, c_sence, url_video, titulo_web, meta_descriptor, alt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssssssssssss", $id_subclase, $estado, $usuario_creacion, $time_creacion, $codigo, $nombre, $nombre_corto, $c_sence, $url_video, $titulo_web, $meta_descriptor, $alt);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>