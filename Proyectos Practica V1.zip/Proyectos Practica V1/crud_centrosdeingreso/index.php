<?php include 'conexion.php';
// Las opciones para las listas desplegables
$nombreOptions = '';
$nombe_cortoOptions = '';
$codigoOptions = '';
$c_senceOptions = '';

$result_nombre = $conn->query("SELECT DISTINCT nombre FROM tbl_centrosdeingreso");
while ($row = $result_nombre->fetch_assoc()) {
  $nombreOptions .= "<option value='{$row['nombre']}'>{$row['nombre']}</option>";
}

$result_nombre_corto = $conn->query("SELECT DISTINCT nombre_corto FROM tbl_centrosdeingreso");
while ($row = $result_nombre_corto->fetch_assoc()) {
  $nombe_cortoOptions .= "<option value='{$row['nombre_corto']}'>{$row['nombre_corto']}</option>";
}

$result_codigo = $conn->query("SELECT DISTINCT codigo FROM tbl_centrosdeingreso");
while ($row = $result_codigo->fetch_assoc()) {
  $codigoOptions .= "<option value='{$row['codigo']}'>{$row['codigo']}</option>";
}
$result_c_sence = $conn->query("SELECT DISTINCT c_sence FROM tbl_centrosdeingreso");
while ($row = $result_c_sence->fetch_assoc()) {
  $c_senceOptions .= "<option value='{$row['c_sence']}'>{$row['c_sence']}</option>";
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Centros De Ingreso</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>


  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>


      <label for="id_subclase">ID SubClase:</label>
      <input type="number" id="id_subclase" name="id_subclase" required>

      <label for="estado">Estado:</label>
      <input type="number" id="estado" name="estado" required>

      <label for="usuario_creacion">Usuario Creacion:</label>
      <input type="number" id="usuario_creacion" name="usuario_creacion" required>

      <label for="time_creacion">Time Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion" required>

      <label for="codigo">Codigo:</label>
      <input type="text" id="codigo" name="codigo" required>

      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>

      <label for="nombre_corto">Nombre Corto:</label>
      <input type="text" id="nombre_corto" name="nombre_corto" required>

      <label for="c_sence">C_sence:</label>
      <input type="number" id="	c_sence" name="c_sence">

      <label for="url_video">URL Video:</label>
      <input type="text" id="url_video" name="url_video">

      <label for="titulo_web">Titulo Web:</label>
      <input type="text" id="titulo_web" name="titulo_web">

      <label for="meta_descriptor">Meta Descriptor:</label>
      <input type="text" id="meta_descriptor" name="meta_descriptor">

      <label for="alt">Alt:</label>
      <input type="text" id="alt" name="alt">

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_nombre">Nombre:</label>
    <select id="search_nombre" name="search_nombre">
      <option value="">Seleccione un Nombre</option>
      <?php echo $nombreOptions; ?>
    </select>

    <label for="search_nombre_corto">Nombre Corto:</label>
    <select id="search_nombre_corto" name="search_nombre_corto">
      <option value="">Seleccione un Nombre Corto</option>
      <?php echo $nombe_cortoOptions; ?>
    </select>

    <label for="search_c_sence">C_sence:</label>
    <select id="search_c_sence" name="search_c_sence">
      <option value="">Seleccione un C_sence</option>
      <?php echo $c_senceOptions; ?>
    </select>

    <label for="search_codigo">Codigo:</label>
    <select id="search_codigo" name="search_codigo">
      <option value="">Seleccione un Codigo</option>
      <?php echo $codigoOptions; ?>
    </select>

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>