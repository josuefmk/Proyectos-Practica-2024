<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_nombre = isset($_GET['search_nombre']) ? $_GET['search_nombre'] : '';
$search_nombre_corto = isset($_GET['search_nombre_corto']) ? $_GET['search_nombre_corto'] : '';
$search_c_sence = isset($_GET['search_c_sence']) ? $_GET['search_c_sence'] : '';
$search_codigo = isset($_GET['search_codigo']) ? $_GET['search_codigo'] : '';


$query = "SELECT id_centroingreso,id_subclase, estado, usuario_creacion,time_creacion,codigo,nombre,nombre_corto,c_sence,url_video,titulo_web,meta_descriptor,alt FROM tbl_centrosdeingreso WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_codigo)) {
  $query .= " AND codigo = ?";
  $types .= 's';
  $params[] = $search_codigo;
}
if (!empty($search_nombre)) {
  $query .= " AND nombre = ?";
  $types .= 's';
  $params[] = $search_nombre;
}
if (!empty($search_nombre_corto)) {
  $query .= " AND nombre_corto = ?";
  $types .= 's';
  $params[] = $search_nombre_corto;
}
if (!empty($search_c_sence)) {
  $query .= " AND c_sence = ?";
  $types .= 'i';
  $params[] = $search_c_sence;
}


$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Estado</th>
                <th>Usuario Creación</th>
                <th>Time Creación</th>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Nombre Corto</th>
                <th>C_Sence</th>
                <th>URL Video</th>
                <th>Titulo Web</th>
                <th>Meta Descriptor</th>
                <th>Alt</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['estado']) . "</td>
           <td>" . htmlspecialchars($row['usuario_creacion']) . "</td>
           <td>" . htmlspecialchars($row['time_creacion']) . "</td>
           <td>" . htmlspecialchars($row['codigo']) . "</td>
           <td>" . htmlspecialchars($row['nombre']) . "</td>
           <td>" . htmlspecialchars($row['nombre_corto']) . "</td>
           <td>" . htmlspecialchars($row['c_sence']) . "</td>
            <td>" . htmlspecialchars($row['url_video']) . "</td>
            <td>" . htmlspecialchars($row['titulo_web']) . "</td>
            <td>" . htmlspecialchars($row['meta_descriptor']) . "</td>
                     <td>" . htmlspecialchars($row['alt']) . "</td>
            <td>
              <a href='update.php?id_centroingreso=" . urlencode($row['id_centroingreso']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_centroingreso'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>