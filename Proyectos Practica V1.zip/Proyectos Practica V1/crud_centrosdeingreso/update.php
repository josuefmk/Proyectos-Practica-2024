<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  // Asegurarse de que 'id_centroingreso' esté definido en la URL
  if (isset($_GET['id_centroingreso'])) {
    $id = $_GET['id_centroingreso'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $id_subclase = $conn->real_escape_string($_POST['id_subclase']);
    $estado = $conn->real_escape_string($_POST['estado']);
    $usuario_creacion = $conn->real_escape_string($_POST['usuario_creacion']);
    $time_creacion = $conn->real_escape_string($_POST['time_creacion']);
    $codigo = $conn->real_escape_string($_POST['codigo']);
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $nombre_corto = $conn->real_escape_string($_POST['nombre_corto']);
    $c_sence = $conn->real_escape_string($_POST['c_sence']);
    $url_video = $conn->real_escape_string($_POST['url_video']);
    $titulo_web = $conn->real_escape_string($_POST['titulo_web']);
    $meta_descriptor = $conn->real_escape_string($_POST['meta_descriptor']);
    $alt = $conn->real_escape_string($_POST['alt']);

    // Consulta para actualizar el registro
    $sql = "UPDATE tbl_centrosdeingreso
        SET id_subclase='$id_subclase', estado='$estado', usuario_creacion='$usuario_creacion',
            time_creacion='$time_creacion', codigo='$codigo', nombre='$nombre', nombre_corto='$nombre_corto',
            c_sence='$c_sence', url_video='$url_video', titulo_web='$titulo_web',
            meta_descriptor='$meta_descriptor', alt='$alt'
        WHERE id_centroingreso='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_centrosdeingreso WHERE id_centroingreso=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Centro de Ingreso</h1>
    <form method="POST">
      <label for="id_subclase">ID Subclase:</label>
      <input type="number" id="id_subclase" name="id_subclase"
        value="<?php echo htmlspecialchars($row['id_subclase'] ?? ''); ?>" required>

      <label for="estado">Estado:</label>
      <input type="number" id="estado" name="estado" value="<?php echo htmlspecialchars($row['estado'] ?? ''); ?>"
        required>

      <label for="usuario_creacion">Usuario Creación:</label>
      <input type="number" id="usuario_creacion" name="usuario_creacion"
        value="<?php echo htmlspecialchars($row['usuario_creacion'] ?? ''); ?>" required>

      <label for="time_creacion">Time Creacion:</label>
      <input type="number" id="time_creacion" name="time_creacion"
        value="<?php echo htmlspecialchars($row['time_creacion'] ?? ''); ?>" required>

      <label for="codigo">Código:</label>
      <input type="text" id="codigo" name="codigo" value="<?php echo htmlspecialchars($row['codigo'] ?? ''); ?>"
        required>

      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($row['nombre'] ?? ''); ?>"
        required>

      <label for="nombre_corto">Nombre Corto:</label>
      <input type="text" id="nombre_corto" name="nombre_corto"
        value="<?php echo htmlspecialchars($row['nombre_corto'] ?? ''); ?>" required>

      <label for="c_sence">C Sence:</label>
      <input type="number" id="c_sence" name="c_sence" value="<?php echo htmlspecialchars($row['c_sence'] ?? ''); ?>">

      <label for="url_video">URL Video:</label>
      <input type="text" id="url_video" name="url_video"
        value="<?php echo htmlspecialchars($row['url_video'] ?? ''); ?>">

      <label for="titulo_web">Título Web:</label>
      <input type="text" id="titulo_web" name="titulo_web"
        value="<?php echo htmlspecialchars($row['titulo_web'] ?? ''); ?>">

      <label for="meta_descriptor">Meta Descriptor:</label>
      <input type="text" id="meta_descriptor" name="meta_descriptor"
        value="<?php echo htmlspecialchars($row['meta_descriptor'] ?? ''); ?>">

      <label for="alt">Alt:</label>
      <input type="text" id="alt" name="alt" value="<?php echo htmlspecialchars($row['alt'] ?? ''); ?>">

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>