<?php include 'conexion.php';
$comunaOPtions = '';
$result_Comuna = $conn->query("SELECT DISTINCT comuna FROM tbl_clientes_empresas");
while ($row = $result_Comuna->fetch_assoc()) {
  $comunaOptions .= "<option value='{$row['comuna']}'>{$row['comuna']}</option>";
}
?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Gestión de Clientes</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <h1>Gestión de Clientes</h1>

  <button id="toggleAddFormBtn" class="btn">Agregar Cliente</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Cliente</h2>
      <label for="id_usuario">ID Usuario:</label>
      <input type="number" id="id_usuario" name="id_usuario" required>

      <label for="id_vendedor">ID Vendedor:</label>
      <input type="text" id="id_vendedor" name="id_vendedor" required>

      <label for="codigo_empresa">Código Empresa:</label>
      <input type="number" id="codigo_empresa" name="codigo_empresa" required>

      <label for="time_creacion">Tiempo Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion" required>

      <label for="tipo_cliente">Tipo Cliente:</label>
      <select id="tipo_cliente" name="tipo_cliente" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="E">Empresa</option>
        <option value="N">Persona Natural</option>
        <option value="U">Universidad</option>
      </select>


      <label for="estado">Estado:</label>
      <select id="estado" name="estado" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="0">Inactivo</option>
        <option value="1">Activo</option>
      </select>

      <label for="rut">RUT:</label>
      <input type="text" id="rut" name="rut" required>

      <label for="razon_social">Razón Social:</label>
      <input type="text" id="razon_social" name="razon_social" required>

      <label for="nombre_fantasia">Nombre Fantasía:</label>
      <input type="text" id="nombre_fantasia" name="nombre_fantasia">


      <label for="telefono">Teléfono:</label>
      <input type="text" id="telefono" name="telefono" required>

      <label for="fax">Fax:</label>
      <input type="text" id="fax" name="fax">

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="sitio_web">Sitio Web:</label>
      <input type="text" id="sitio_web" name="sitio_web" required>

      <label for="direccion">Dirección:</label>
      <input type="text" id="direccion" name="direccion" required>

      <label for="id_region">ID Región:</label>
      <input type="number" id="id_region" name="id_region" required>

      <label for="id_ciudad">ID Ciudad:</label>
      <input type="number" id="id_ciudad" name="id_ciudad" required>

      <label for="id_comuna">ID Comuna:</label>
      <input type="number" id="id_comuna" name="id_comuna" required>

      <label for="comuna">Comuna:</label>
      <input type="text" id="comuna" name="comuna">

      <label for="ciudad">Ciudad:</label>
      <input type="text" id="ciudad" name="ciudad">

      <label for="region">Región:</label>
      <input type="text" id="region" name="region">

      <label for="contacto">Contacto:</label>
      <input type="text" id="contacto" name="contacto" required>

      <label for="tel_contacto">Teléfono de Contacto:</label>
      <input type="text" id="tel_contacto" name="tel_contacto" required>

      <label for="contacto_cobranza">Contacto_cobranza</label>
      <input type="text" id="contacto_cobranza" name="contacto_cobranza">

      <label for="mail_cobranza">Email Cobranza:</label>
      <input type="email" id="mail_cobranza" name="mail_cobranza">

      <label for="fono_cobranza">fono_cobranza:</label>
      <input type="text" id="fono_cobranza" name="fono_cobranza">

      <label for="id_comuna_laboral">ID Comuna Laboral:</label>
      <input type="number" id="id_comuna_laboral" name="id_comuna_laboral" required>

      <label for="direccion_laboral">Direccion Laboral:</label>
      <input type="text" id="direccion_laboral" name="direccion_laboral">

      <label for="celular">Celular:</label>
      <input type="text" id="celular" name="celular">

      <label for="fecha_nacimiento">Fecha Nacimiento:</label>
      <input type="date" id="fecha_nacimiento" name="fecha_nacimiento">

      <input type="submit" value="Agregar Cliente" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Cliente</h3>
    <label for="search_rut">RUT:</label>
    <input type="text" id="search_rut" name="search_rut">

    <label for="search_tel">Teléfono:</label>
    <input type="text" id="search_tel" name="search_tel">

    <label for="search_email">Email:</label>
    <input type="text" id="search_email" name="search_email">


    <label for="search_direccion">Dirección:</label>
    <input type="text" id="search_direccion" name="search_direccion">

    <label for="search_comuna">Comuna:</label>
    <select id="search_comuna" name="search_comuna">
      <option value="">Seleccione una Comuna</option>
      <?php echo $comunaOPtions; ?>
    </select>


    <input type="submit" class="btn" value="Buscar">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Clientes</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
    });
  });
  </script>
</body>