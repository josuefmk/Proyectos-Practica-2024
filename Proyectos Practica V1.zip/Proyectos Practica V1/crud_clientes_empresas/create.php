<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Recoger datos del formulario

  $id_usuario = $_POST['id_usuario'];
  $id_vendedor = $_POST['id_vendedor'];
  $codigo_empresa = $_POST['codigo_empresa'];
  $tipo_cliente = $_POST['tipo_cliente'];
  $time_creacion = $_POST['time_creacion'];
  $estado = $_POST['estado'];
  $rut = $_POST['rut'];
  $razon_social = $_POST['razon_social'];
  $nombre_fantasia = $_POST['nombre_fantasia'];
  $telefono = $_POST['telefono'];
  $fax = $_POST['fax'];
  $email = $_POST['email'];
  $sitio_web = $_POST['sitio_web'];
  $direccion = $_POST['direccion'];
  $id_region = $_POST['id_region'];
  $id_ciudad = $_POST['id_ciudad'];
  $id_comuna = $_POST['id_comuna'];
  $comuna = $_POST['comuna'];
  $ciudad = $_POST['ciudad'];
  $region = $_POST['region'];
  $contacto = $_POST['contacto'];
  $tel_contacto = $_POST['tel_contacto'];
  $contacto_cobranza = $_POST['contacto_cobranza'];
  $mail_cobranza = $_POST['mail_cobranza'];
  $fono_cobranza = $_POST['fono_cobranza'];
  $id_comuna_laboral = $_POST['id_comuna_laboral'];
  $direccion_laboral = $_POST['direccion_laboral'];
  $celular = $_POST['celular'];
  $fecha_nacimiento = $_POST['fecha_nacimiento'];
  // Preparar la consulta
  $stmt = $conn->prepare("INSERT INTO tbl_clientes_empresas (id_usuario,id_vendedor,codigo_empresa,tipo_cliente,time_creacion,estado,rut,razon_social,nombre_fantasia,telefono,fax,email,sitio_web,direccion,id_region,id_ciudad,id_comuna,comuna,ciudad,region,contacto,tel_contacto,contacto_cobranza,mail_cobranza,fono_cobranza,id_comuna_laboral,direccion_laboral,celular,fecha_nacimiento) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  // Vincular parámetros
  $stmt->bind_param(
    "iiissssssssssssssssssssssssss",
    $id_usuario,
    $id_vendedor,
    $codigo_empresa,
    $tipo_cliente,
    $time_creacion,
    $estado,
    $rut,
    $razon_social,
    $nombre_fantasia,
    $telefono,
    $fax,
    $email,
    $sitio_web,
    $direccion,
    $id_region,
    $id_ciudad,
    $id_comuna,
    $comuna,
    $ciudad,
    $region,
    $contacto,
    $tel_contacto,
    $contacto_cobranza,
    $mail_cobranza,
    $fono_cobranza,
    $id_comuna_laboral,
    $direccion_laboral,
    $celular,
    $fecha_nacimiento
  );

  // Ejecutar la consulta
  if ($stmt->execute()) {
    echo "Cliente agregado correctamente.";
  } else {
    echo "Error al guardar el cliente: " . $stmt->error;
  }

  // Cerrar la declaración y la conexión
  $stmt->close();
  $conn->close();
}
?>