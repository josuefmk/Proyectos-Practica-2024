<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
$search_rut = isset($_GET['search_rut']) ? $_GET['search_rut'] : '';
$search_tel = isset($_GET['search_tel']) ? $_GET['search_tel'] : '';
$search_email = isset($_GET['search_email']) ? $_GET['search_email'] : '';
$search_comuna = isset($_GET['search_comuna']) ? $_GET['search_comuna'] : '';
$search_direccion = isset($_GET['search_direccion']) ? $_GET['search_direccion'] : '';

$query = "SELECT * FROM tbl_clientes_empresas WHERE 1=1";

if (!empty($search_rut)) {
  $query .= " AND rut LIKE ?";
}
if (!empty($search_tel)) {
  $query .= " AND telefono LIKE ?";
}
if (!empty($search_email)) {
  $query .= " AND email LIKE ?";
}
if (!empty($search_comuna)) {
  $query .= " AND comuna LIKE ?";
}
if (!empty($search_direccion)) {
  $query .= " AND direccion LIKE ?";
}


$stmt = $conn->prepare($query);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}
$tipo_cliente_nom = [
  'E' => 'Empresa',
  'N' => 'Persona Natural',
  'U' => 'Universidad',
];

$estado_cli = [
  '0' => 'Inactivo',
  '1' => 'Activo',
];
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo '<div class="carta-container">';
  while ($row = $result->fetch_assoc()) {
    $nombres = [];
    $nombre_cli = explode(',', $row['tipo_cliente']);
    foreach ($nombre_cli as $nom) {
      $nom_cli = trim($nom);
      if (isset($tipo_cliente_nom[$nom_cli])) {
        $nombres[] = $tipo_cliente_nom[$nom_cli];
      }
    }
    $nombre_cliente_texto = implode(', ', $nombres);

    $nombres_estado = [];
    $estado_cliente = str_split($row['estado']);
    foreach ($estado_cliente as $nom) {
      $est_cli = trim($nom);
      if (isset($estado_cli[$est_cli])) {
        $nombres_estado[] = $estado_cli[$est_cli];
      }
    }

    $nombre_estado_texto = implode(', ', $nombres_estado);


    echo '<div class="carta">';
    echo '<div class="carta-header">';
    echo '<h3>Cliente: ' . htmlspecialchars($row['razon_social']) . '</h3>';
    echo '</div>';
    echo '<div class="carta-body">';
    echo '<p><strong>ID Usuario:</strong> ' . htmlspecialchars($row['id_usuario']) . '</p>';
    echo '<p><strong>ID Vendedor:</strong> ' . htmlspecialchars($row['id_vendedor']) . '</p>';
    echo '<p><strong>Código Empresa:</strong> ' . htmlspecialchars($row['codigo_empresa']) . '</p>';
    echo '<p><strong>Hora de Creación:</strong> ' . htmlspecialchars($row['time_creacion']) . '</p>';
    echo '<p><strong>Tipo de Cliente:</strong> ' . htmlspecialchars($nombre_cliente_texto) . '</p>';
    echo '<p><strong>Estado:</strong> ' . htmlspecialchars($nombre_estado_texto) . '</p>';
    echo '<p><strong>RUT:</strong> ' . htmlspecialchars($row['rut']) . '</p>';
    echo '<p><strong>Nombre Fantasía:</strong> ' . htmlspecialchars($row['nombre_fantasia']) . '</p>';
    echo '<p><strong>Teléfono:</strong> ' . htmlspecialchars($row['telefono']) . '</p>';
    echo '<p><strong>Fax:</strong> ' . htmlspecialchars($row['fax']) . '</p>';
    echo '<p><strong>Email:</strong> ' . htmlspecialchars($row['email']) . '</p>';
    echo '<p><strong>Sitio Web:</strong> ' . htmlspecialchars($row['sitio_web']) . '</p>';
    echo '<p><strong>Dirección:</strong> ' . htmlspecialchars($row['direccion']) . '</p>';
    echo '<p><strong>Comuna:</strong> ' . htmlspecialchars($row['comuna']) . '</p>';
    echo '<p><strong>Ciudad:</strong> ' . htmlspecialchars($row['ciudad']) . '</p>';
    echo '<p><strong>Región:</strong> ' . htmlspecialchars($row['region']) . '</p>';
    echo '<p><strong>Contacto:</strong> ' . htmlspecialchars($row['contacto']) . '</p>';
    echo '<p><strong>Teléfono de Contacto:</strong> ' . htmlspecialchars($row['tel_contacto']) . '</p>';
    echo '<p><strong>Condiciones de Venta:</strong> ' . htmlspecialchars($row['id_condiciones_venta']) . '</p>';
    echo '<p><strong>Tipo de Facturación:</strong> ' . htmlspecialchars($row['tipo_facturacion']) . '</p>';
    echo '<p><strong>Forma de Pago:</strong> ' . htmlspecialchars($row['forma_pago']) . '</p>';
    echo '<p><strong>Contacto de Cobranza:</strong> ' . htmlspecialchars($row['contacto_cobranza']) . '</p>';
    echo '<p><strong>Email de Cobranza:</strong> ' . htmlspecialchars($row['mail_cobranza']) . '</p>';
    echo '<p><strong>Teléfono de Cobranza:</strong> ' . htmlspecialchars($row['fono_cobranza']) . '</p>';
    echo '<p><strong>Dirección Laboral:</strong> ' . htmlspecialchars($row['direccion_laboral']) . '</p>';
    echo '<p><strong>Celular:</strong> ' . htmlspecialchars($row['celular']) . '</p>';
    echo '<p><strong>Fecha de Nacimiento:</strong> ' . htmlspecialchars($row['fecha_nacimiento']) . '</p>';
    echo '<div class="acciones">';
    echo '<a href="update.php?id_empresa=' . htmlspecialchars($row['id_empresa']) . '" class="btn btn-sm btn-warning">Editar</a>';
    echo '<a href="javascript:void(0);" onclick="confirmDelete(' . htmlspecialchars($row['id_empresa']) . ');" class="btn btn-sm btn-danger">Eliminar</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
  }
  echo '</div>';
} else {
  echo "<p>No se encontraron resultados.</p>";
}

$stmt->close();
$conn->close();
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_empresa: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('.carta').filter(function() {
            return $(this).find('a[href*="' + id + '"]').length > 0;
          }).fadeOut(500, function() {
            $(this).remove();
          });
        } else {
          alert('Error al eliminar el registro: ' + response);
        }
      }
    });
  }
}
</script>