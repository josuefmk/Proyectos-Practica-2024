<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_empresa'])) {
    $id = $_GET['id_empresa'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $id_usuario = $conn->real_escape_string($_POST['id_usuario']);
    $id_vendedor = $conn->real_escape_string($_POST['id_vendedor']);
    $codigo_empresa = $conn->real_escape_string($_POST['codigo_empresa']);
    $tipo_cliente = $conn->real_escape_string($_POST['tipo_cliente']);
    $time_creacion = $conn->real_escape_string($_POST['time_creacion']);
    $estado = $conn->real_escape_string($_POST['estado']);
    $rut = $conn->real_escape_string($_POST['rut']);
    $razon_social = $conn->real_escape_string($_POST['razon_social']);
    $nombre_fantasia = $conn->real_escape_string($_POST['nombre_fantasia']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $fax = $conn->real_escape_string($_POST['fax']);
    $sitio_web = $conn->real_escape_string($_POST['sitio_web']);
    $email = $conn->real_escape_string($_POST['email']);
    $direccion = $conn->real_escape_string($_POST['id_region']);
    $id_region = $conn->real_escape_string($_POST['empresa']);
    $id_ciudad = $conn->real_escape_string($_POST['id_ciudad']);
    $id_comuna = $conn->real_escape_string($_POST['id_comuna']);
    $comuna = $conn->real_escape_string($_POST['comuna']);
    $ciudad = $conn->real_escape_string($_POST['ciudad']);
    $region = $conn->real_escape_string($_POST['region']);
    $contacto = $conn->real_escape_string($_POST['contacto']);
    $tel_contacto = $conn->real_escape_string($_POST['tel_contacto']);
    $contacto_cobranza = $conn->real_escape_string($_POST['contacto_cobranza']);
    $mail_cobranza = $conn->real_escape_string($_POST['mail_cobranza']);
    $fono_cobranza = $conn->real_escape_string($_POST['fono_cobranza']);
    $id_comuna_laboral = $conn->real_escape_string($_POST['id_comuna_laboral']);
    $direccin_laboral = $conn->real_escape_string($_POST['direccin_laboral']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $fecha_nacimiento = $conn->real_escape_string($_POST['fecha_nacimiento']);


    // Consulta para actualizar el registro
    $sql = "UPDATE tbl_cursos
        SET id_usuario='$id_usuario',
            id_vendedor='$id_vendedor',
            codigo_empresa='$codigo_empresa',
            tipo_cliente='$tipo_cliente',
            time_creacion='$time_creacion',
            estado='$estado',
            rut='$rut',
            razon_social='$razon_social',
            nombre_fantasia='$nombre_fantasia',
            telefono='$telefono',
            fax='$fax',
            sitio_web='$sitio_web',
            email='$email',
            direccion='$direccion',
            id_region='$id_region',
            id_ciudad='$id_ciudad',
            id_comuna='$id_comuna',
            comuna='$comuna',
            ciudad='$ciudad',
            region='$region',
            contacto='$contacto',
            tel_contacto='$tel_contacto',
            contacto_cobranza='$contacto_cobranza',
            mail_cobranza='$mail_cobranza',
            fono_cobranza='$fono_cobranza',
            id_comuna_laboral='$id_comuna_laboral',
            direccin_laboral='$direccin_laboral',
            celular='$celular',
            fecha_nacimiento='$fecha_nacimiento',
        WHERE id_empresa='$id'";
    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_clientes_empresas WHERE id_empresa=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>
  <div class="form-container">
    <h1>Actualizar Centro de Ingreso</h1>
    <form method="POST">
      <label for="id_usuario">ID Usuario:</label>
      <input type="number" id="id_usuario" name="id_usuario"
        value="<?php echo htmlspecialchars($row['id_usuario'] ?? ''); ?>" required>

      <label for="id_vendedor">ID Vendedor:</label>
      <input type="number" id="id_vendedor" name="id_vendedor"
        value="<?php echo htmlspecialchars($row['id_vendedor'] ?? ''); ?>" required>

      <label for="codigo_empresa">Codigo Empresa:</label>
      <input type="text" id="codigo_empresa" name="codigo_empresa"
        value="<?php echo htmlspecialchars($row['codigo_empresa'] ?? ''); ?>" required>


      <label for="tipo_cliente">Tipo Cliente:</label>
      <select id="tipo_cliente" name="tipo_cliente" class="form-control" required>
        <option value="E" <?php if ($row['tipo_cliente'] == 0)
          echo 'selected'; ?>>Empresa</option>
        <option value="N" <?php if ($row['tipo_cliente'] == 1)
          echo 'selected'; ?>>Persona Natural</option>
        <option value="U" <?php if ($row['tipo_cliente'] == 2)
          echo 'selected'; ?>>Universidad</option>
      </select>


      <label for="time_creacion">Time Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion"
        value="<?php echo htmlspecialchars($row['time_creacion'] ?? ''); ?>" required>


      <label for="estado">Estado:</label>
      <select id="estado" name="estado" class="form-control" required>
        <option value="0" <?php if ($row['estado'] == 0)
          echo 'selected'; ?>>Inactvo</option>
        <option value="1" <?php if ($row['estado'] == 1)
          echo 'selected'; ?>>Activo</option>
      </select>

      <label for="rut">RUT:</label>
      <input type="text" id="rut" name="rut" value="<?php echo htmlspecialchars($row['rut'] ?? ''); ?>" required>

      <label for="razon_social">Razon Social:</label>
      <input type="text" id="razon_social" name="razon_social"
        value="<?php echo htmlspecialchars($row['razon_social'] ?? ''); ?>" required>


      <label for="nombre_fantasia">Nombre Fantasia:</label>
      <input type="text" id="nombre_fantasia" name="nombre_fantasia"
        value="<?php echo htmlspecialchars($row['nombre_fantasia'] ?? ''); ?>" required>

      <label for="telefono">Telefono:</label>
      <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($row['telefono'] ?? ''); ?>">

      <label for="fax">Fax:</label>
      <input type="text" id="fax" name="fax" value="<?php echo htmlspecialchars($row['fax'] ?? ''); ?>">

      <label for="sitio_web">Sitio Web:</label>
      <input type="text" id="sitio_web" name="sitio_web"
        value="<?php echo htmlspecialchars($row['sitio_web'] ?? ''); ?>">

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($row['email'] ?? ''); ?>">

      <label for="direccion">Dirección:</label>
      <input type="text" id="direccion" name="direccion"
        value="<?php echo htmlspecialchars($row['direccion'] ?? ''); ?>">

      <label for="id_region"> ID Región:</label>
      <input type="number" id="id_region" name="id_region"
        value="<?php echo htmlspecialchars($row['id_region'] ?? ''); ?>">

      <label for="id_ciudad">ID Ciudad:</label>
      <input type="number" id="id_ciudad" name="id_ciudad"
        value="<?php echo htmlspecialchars($row['id_ciudad'] ?? ''); ?>">

      <label for="id_comuna">ID COmuna:</label>
      <input type="number" id="id_comuna" name="id_comuna"
        value="<?php echo htmlspecialchars($row['id_comuna'] ?? ''); ?>">

      <label for="comuna">Comuna:</label>
      <input type="text" id="comuna" name="comuna" value="<?php echo htmlspecialchars($row['comuna'] ?? ''); ?>">

      <label for="region">Región:</label>
      <input type="text" id="region" name="region" value="<?php echo htmlspecialchars($row['region'] ?? ''); ?>">

      <label for="ciudad">Ciudad:</label>
      <input type="text" id="ciudad" name="ciudad" value="<?php echo htmlspecialchars($row['ciudad'] ?? ''); ?>">

      <label for="contacto">Contacto:</label>
      <input type="tel" id="contacto" name="contacto" value="<?php echo htmlspecialchars($row['contacto'] ?? ''); ?>">

      <label for="tel_contacto">Telefono Contacto:</label>
      <input type="text" id="tel_contacto" name="tel_contacto"
        value="<?php echo htmlspecialchars($row['tel_contacto'] ?? ''); ?>">

      <label for="contacto_cobranza">Contacto Cobranza:</label>
      <input type="text" id="contacto_cobranza" name="contacto_cobranza"
        value="<?php echo htmlspecialchars($row['contacto_cobranza'] ?? ''); ?>">

      <label for="mail_cobranza">Email Cobranza:</label>
      <input type="email" id="mail_cobranza" name="mail_cobranza"
        value="<?php echo htmlspecialchars($row['mail_cobranza'] ?? ''); ?>">

      <label for="fono_cobranza">Fono Cobranza:</label>
      <input type="text" id="fono_cobranza" name="fono_cobranza"
        value="<?php echo htmlspecialchars($row['fono_cobranza'] ?? ''); ?>">

      <label for="id_comuna_laboral">ID Comuna Laboral:</label>
      <input type="number" id="id_comuna_laboral" name="id_comuna_laboral"
        value="<?php echo htmlspecialchars($row['id_comuna_laboral'] ?? ''); ?>">

      <label for="direccin_laboral">Dirección Laboral:</label>
      <input type="text" id="direccin_laboral" name="direccin_laboral"
        value="<?php echo htmlspecialchars($row['direccin_laboral'] ?? ''); ?>">

      <label for="celular">Celular:</label>
      <input type="text" id="celular" name="celular" value="<?php echo htmlspecialchars($row['celular'] ?? ''); ?>">

      <label for="fecha_nacimiento" class="fecha_nacimiento">Fecha Nacimiento:</label>
      <input type="date" id="fecha_nacimiento" name="hora_hasta" class="input-time"
        value="<?php echo htmlspecialchars($row['fecha_nacimiento'] ?? ''); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>


  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>