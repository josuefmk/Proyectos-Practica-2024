<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id_empresa = isset($_POST['id_empresa']) ? $_POST['id_empresa'] : '';

  if (!empty($id_empresa)) {
    $stmt = $conn->prepare("DELETE FROM tbl_clientes_empresas WHERE id_empresa = ?");
    if ($stmt === false) {
      die("Error en la preparación de la consulta: " . $conn->error);
    }

    $stmt->bind_param('s', $id_empresa);
    if ($stmt->execute()) {
      echo 'success';
    } else {
      echo 'Error: ' . $conn->error;
    }

    $stmt->close();
  } else {
    echo 'ID de empresa no válido.';
  }
}

$conn->close();
?>