<script>
  document.getElementById('expand-icon').addEventListener('click', function() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
      tab.style.display = (tab.style.display === 'block' || tab.style.display === '') ? 'none' : 'block';
    });
  });
</script>