<?php
session_start();
include 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['id_usuario'])) {
  header("Location: login.php");
  exit();
}

if (!isset($_SESSION['username'])) {
  exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id_usuario = $_SESSION['id_usuario'];
  $nombre = $_SESSION['username'];

  // Manejo de archivo
  $file = $_FILES['documento'];

  if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Error al subir el archivo.']);
    exit;
  }

  $tipoArchivo = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
  $timestamp = time();
  $nombreOriginal = basename($file['name']);
  $nombreArchivo = $timestamp . '_' . $nombreOriginal;
  $rutaArchivo = 'uploads/' . $nombreArchivo;

  $tiposPermitidos = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf'];
  if (!in_array($tipoArchivo, $tiposPermitidos)) {
    echo json_encode(['success' => false, 'message' => 'Tipo de archivo no permitido.']);
    exit;
  }

  if (file_exists($rutaArchivo)) {
    echo json_encode(['success' => false, 'message' => 'El archivo ya existe.']);
    exit;
  }

  $tamañoArchivo = $file['size'];

  if (move_uploaded_file($file['tmp_name'], $rutaArchivo)) {
    $link = $rutaArchivo;
    try {
      $stmt = $conn->prepare("INSERT INTO tbl_documentos_alumno (nombre, type, size, link, id_usuario, fecha_creacion) VALUES (?, ?, ?, ?, ?, NOW())");
      if (!$stmt) {
        throw new Exception("Error en la preparación de la consulta: " . $conn->error);
      }
      $stmt->bind_param("ssisi", $nombreOriginal, $tipoArchivo, $tamañoArchivo, $link, $id_usuario);

      if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Archivo subido exitosamente.']);
        exit();
      } else {
        echo json_encode(['success' => false, 'message' => 'Error al insertar el archivo en la base de datos.']);
      }
      $stmt->close();
    } catch (Exception $e) {
      echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
    }
  } else {
    echo json_encode(['success' => false, 'message' => 'Error al mover el archivo subido.']);
  }
}
?>