<?php
session_start();
include 'conexion.php';

// Función para cerrar sesión
function cerrarSesion($conn, $id_usuario, $id_sesion)
{

  $deleteQuery = "DELETE FROM tbl_login WHERE id_usuario = ? AND id_sesion = ?";
  $stmt = $conn->prepare($deleteQuery);

  if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error al preparar la consulta de eliminación: ' . $conn->error]);
    exit();
  }

  $stmt->bind_param('is', $id_usuario, $id_sesion);

  if ($stmt->execute()) {
    return true;
  } else {
    echo json_encode(['success' => false, 'message' => 'Error al cerrar sesión.']);
    exit();
  }
}
$id_usuario = $_SESSION['id_usuario'];
$id_sesion = session_id();


cerrarSesion($conn, $id_usuario, $id_sesion);

// Limpiar la sesión
session_unset();
session_destroy();

// Redirigir a la página de inicio de sesión
header('Location: index.php');
exit();
?>