<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="Ajax.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <title>Login</title>
</head>

<body>
  <div class="login-container">
    <form class="login-form" id="loginForm">
      <h2>Iniciar sesión</h2>
      <div class="login-form-group">
        <label for="username">Nombre de usuario</label>
        <input type="text" id="username" name="username" placeholder="Ingresa tu usuario" required>
      </div>
      <div class="login-form-group">
        <label for="contrasena">Contraseña</label>
        <input type="password" id="contrasena" name="contrasena" placeholder="Ingresa tu contraseña" required>
      </div>
      <button type="submit" class="btn">Iniciar sesión</button>
      <div id="error-message" class="error"></div>
    </form>
  </div>
</body>

</html>