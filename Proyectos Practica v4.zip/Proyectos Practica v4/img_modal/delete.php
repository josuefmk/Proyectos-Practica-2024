<?php
session_start();
include 'conexion.php';

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
  echo 'error';
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
  $id_documento = $_POST['id'];
  $id_usuario = $_SESSION['id_usuario'];

  // Consulta para eliminar el documento
  $stmt = $conn->prepare("SELECT link FROM tbl_documentos_alumno WHERE id_documento = ? AND id_usuario = ?");
  $stmt->bind_param("ii", $id_documento, $id_usuario);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
    $documento = $result->fetch_assoc();
    $link = $documento['link'];

    $stmt_delete = $conn->prepare("DELETE FROM tbl_documentos_alumno WHERE id_documento = ? AND id_usuario = ?");
    $stmt_delete->bind_param("ii", $id_documento, $id_usuario);
    if ($stmt_delete->execute()) {
      if (file_exists($link)) {
        unlink($link);
      }
      echo 'success';
    } else {
      echo 'error';
    }
    $stmt_delete->close();
  } else {
    echo 'error';
  }

  $stmt->close();
} else {
  echo 'error';
}
?>