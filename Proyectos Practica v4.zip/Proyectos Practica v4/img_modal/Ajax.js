$(document).ready(function() {

    const modal = $('#documentModal');
    const modalImage = $('#modalImage');
    const downloadButton = $('#downloadButton');
    const span = $('.close');


    function openModal(fileLink, iconSrc) {
        modalImage.attr('src', iconSrc);
        downloadButton.attr('href', fileLink);
        modal.show();
    }


    function assignIconClick() {
        $('.clickable-icon').off('click').on('click', function() {
            const fileLink = $(this).data('link');
            const iconSrc = $(this).attr('src');
            openModal(fileLink, iconSrc);
        });
    }

    assignIconClick();

    span.on('click', function() {
        modal.hide();
    });

    $(window).on('click', function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });


    $('#uploadForm').on('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        $.ajax({
            url: 'insert.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                try {
                    const res = JSON.parse(response);
                    if (res.success) {
                        alert(res.message);
                        loadDocuments();
                        $('#uploadForm')[0].reset();
                    } else {
                        alert(res.message);
                    }
                } catch (error) {
                    console.error('Error al parsear la respuesta JSON:', error);
                    alert('Respuesta inválida del servidor.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error en la solicitud AJAX:', error);
                alert('Error al realizar la solicitud: ' + error);
            }
        });
    });


    function loadDocuments() {
        $.ajax({
            url: 'consultas.php',
            method: 'GET',
            data: {
                tipo_archivo: $('#tipo_archivo').val(),
                ordenar_por_fecha: $('#ordenar_por_fecha').val(),
                buscar_por_nombre: $('#buscar_por_nombre').val()
            },
            success: function(data) {
                $('.documents-grid').html(data);

                assignIconClick();
            },
            error: function() {
                alert('Error al cargar los documentos.');
            }
        });
    }

    /* Función para Confirmar y Eliminar un Documento */
    window.confirmDelete = function(id) {
        if (confirm("¿Estás seguro que deseas eliminar este documento?")) {
            $.ajax({
                url: 'delete.php',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    if (response.trim() === 'success') {
                        $('#row-' + id).fadeOut(500, function() {
                            $(this).remove();
                        });
                        alert('Documento eliminado exitosamente.');
                    } else {
                        alert('Error al eliminar el documento.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Hubo un error en la solicitud.');
                }
            });
        }
    };
});