<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'conexion.php';

header('Content-Type: application/json');

// Asegura de que no haya contenido previo
ob_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'] ?? '';
  $contrasena = $_POST['contrasena'] ?? '';

  if (empty($username) || empty($contrasena)) {
    echo json_encode(['success' => false, 'message' => 'Usuario o contraseña vacíos.']);
    exit();
  }

  $query = "SELECT id_usuario, contrasena FROM tbl_usuarios_documentos WHERE usuario = ?";
  $stmt = $conn->prepare($query);

  if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error al preparar la consulta: ' . $conn->error]);
    exit();
  }

  $stmt->bind_param('s', $username);
  $stmt->execute();
  $result = $stmt->get_result();


  if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    // Compara la contraseña ingresada en la tabla
    if ($contrasena === $row['contrasena']) {
      $_SESSION['username'] = $username;
      $_SESSION['id_usuario'] = $row['id_usuario'];
      $_SESSION['id_sesion'] = session_id();

      // Insertar en la tabla de login
      $insertQuery = "INSERT INTO tbl_login (id_usuario, usuario, id_sesion) VALUES (?, ?, ?)";
      $insertStmt = $conn->prepare($insertQuery);

      if (!$insertStmt) {
        echo json_encode(['success' => false, 'message' => 'Error al preparar la consulta de inserción: ' . $conn->error]);
        exit();
      }

      $insertStmt->bind_param('iss', $row['id_usuario'], $username, $_SESSION['id_sesion']);

      if ($insertStmt->execute()) {
        echo json_encode(['success' => true]);
        exit();
      } else {
        echo json_encode(['success' => false, 'message' => 'Error al registrar el inicio de sesión.']);
        exit();
      }
    } else {
      echo json_encode(['success' => false, 'message' => 'La contraseña no coincide']);
      exit();
    }
  } else {
    echo json_encode(['success' => false, 'message' => 'El usuario no se encontró']);
    exit();
  }
}

// Limpiar la salida
ob_end_clean();
?>