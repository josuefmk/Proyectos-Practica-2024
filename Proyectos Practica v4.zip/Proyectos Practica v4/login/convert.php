<?php
include 'conexion.php';
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$id_usuario = $_SESSION['id_usuario'];

$tipo_archivo = isset($_GET['tipo_archivo']) ? $_GET['tipo_archivo'] : '';
$ordenar_por_fecha = isset($_GET['ordenar_por_fecha']) ? $_GET['ordenar_por_fecha'] : '';
$buscar_por_nombre = isset($_GET['buscar_por_nombre']) ? $_GET['buscar_por_nombre'] : '';

$documentos = [];

// Comenzar la consulta SQL
$query = "SELECT id_documento, nombre, link, type, fecha_creacion FROM tbl_documentos_alumno WHERE id_usuario = ?";
$params = [$id_usuario];

if ($tipo_archivo) {
  $query .= " AND type = ?";
  $params[] = $tipo_archivo;
}

if ($buscar_por_nombre) {
  $query .= " AND nombre LIKE ?";
  $params[] = '%' . $buscar_por_nombre . '%';
}

if ($ordenar_por_fecha) {
  $query .= " ORDER BY fecha_creacion " . ($ordenar_por_fecha === 'asc' ? 'ASC' : 'DESC');
} else {
  $query .= " ORDER BY nombre ASC";
}

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($query);
$stmt->bind_param(str_repeat('s', count($params)), ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $documentos[] = $row;
  }
} else {
  echo "<p>No se encontraron documentos.</p>";
}

$stmt->close();

// Mostrar los documentos en formato de tarjetas
foreach ($documentos as $doc) {
  $iconPath = match ($doc['type']) {
    'pdf' => 'icons/pdf.png',
    'doc', 'docx' => 'icons/docx.png',
    'xls', 'xlsx' => 'icons/xlsx.png',
    'ppt', 'pptx' => 'icons/pptx.png',
    default => 'icons/default.png'
  };

  echo "<div class='document-card' id='row-" . htmlspecialchars($doc['id_documento']) . "'>";
  echo "<div class='document-icon'>";
  echo "<img src='" . htmlspecialchars($iconPath) . "' alt='" . htmlspecialchars($doc['type']) . "' class='doc-icon' />";
  echo "</div>";
  echo "<div class='document-info'>";
  echo "<p>Fecha: " . htmlspecialchars($doc['fecha_creacion']) . "</p>";
  echo "<h3>" . htmlspecialchars(preg_replace('/^\d+_/', '', $doc['nombre'])) . "</h3>";
  echo "</div>";
  echo "<div class='document-actions'>";
  echo "<a href='" . htmlspecialchars($doc['link']) . "' download class='action-btn download-btn'><i class='fas fa-download'></i></a>";
  echo "<a href='convertir_pdf.php?id=" . htmlspecialchars($doc['id_documento']) . "' class='action-btn pdf-btn'><i class='fas fa-file-pdf'></i></a>";
  echo "<a href='#' onclick='confirmDelete(" . htmlspecialchars($doc['id_documento']) . ")' class='action-btn delete-btn'><i class='fas fa-trash-alt'></i></a>";
  echo "</div>";
  echo "</div>";
}
?>