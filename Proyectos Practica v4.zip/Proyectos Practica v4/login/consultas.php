<?php
include 'conexion.php';
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$id_usuario = $_SESSION['id_usuario'];

$tipo_archivo = isset($_GET['tipo_archivo']) ? $_GET['tipo_archivo'] : '';
$ordenar_por_fecha = isset($_GET['ordenar_por_fecha']) ? $_GET['ordenar_por_fecha'] : '';
$buscar_por_nombre = isset($_GET['buscar_por_nombre']) ? $_GET['buscar_por_nombre'] : '';

$documentos = [];

// Comenzar la consulta SQL
$query = "SELECT id_documento, nombre, link, type, fecha_creacion FROM tbl_documentos_alumno WHERE id_usuario = ?";
$params = [$id_usuario];

if ($tipo_archivo) {
  $query .= " AND type = ?";
  $params[] = $tipo_archivo;
}

if ($buscar_por_nombre) {
  $query .= " AND nombre LIKE ?";
  $params[] = '%' . $buscar_por_nombre . '%';
}

if ($ordenar_por_fecha) {
  $query .= " ORDER BY fecha_creacion " . ($ordenar_por_fecha === 'asc' ? 'ASC' : 'DESC');
} else {
  $query .= " ORDER BY nombre ASC";
}

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($query);
$stmt->bind_param(str_repeat('s', count($params)), ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $documentos[] = $row;
  }
} else {
  echo "<p>No se encontraron documentos.</p>";
}

$stmt->close();

if (!empty($_GET['buscar_por_nombre'])) {
  foreach ($documentos as $doc) {
    echo "<li class='documento-result'>";
    echo "<a href='" . htmlspecialchars($doc['link']) . "'>" . htmlspecialchars($doc['nombre']) . " (" . htmlspecialchars(strtoupper($doc['type'])) . ")</a>";
    echo "</li>";
  }
}
?>