<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Redirigir si el usuario no está autenticado
if (!isset($_SESSION['id_usuario'])) {
  header("Location: login.php");
  exit();
}

include 'consultas.php';

// Obtener los filtros
$tipo_archivo = isset($_GET['tipo_archivo']) ? $_GET['tipo_archivo'] : '';
$ordenar_por_fecha = isset($_GET['ordenar_por_fecha']) ? $_GET['ordenar_por_fecha'] : '';
$buscar_por_nombre = isset($_GET['buscar_por_nombre']) ? $_GET['buscar_por_nombre'] : '';
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - Gestión de Documentos</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="Ajax.js"></script>
</head>

<body>
  <header class="header">
    <div class="header-container">
      <div class="header-title-container">
        <h1 class="header-title">Gestión de Documentos</h1>
      </div>
      <a href="logout.php" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i> Cerrar sesión
      </a>
    </div>
  </header>

  <main class="main-content">

    <section class="upload-section">
      <h2>Subir Documento</h2>
      <form id="uploadForm" method="POST" action="insert.php" enctype="multipart/form-data">
        <div class="form-group">
          <label for="documento"><i class="fas fa-upload"></i> Selecciona un Documento:</label>
          <input type="file" name="documento" accept=".doc,.docx,.xls,.xlsx,.ppt,.pptx,.pdf" required>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Subir Documento</button>
      </form>
    </section>

    <section class="documents-section">
      <h2>Busqueda Documentos</h2>
      <form method="GET" id="filterForm" class="filter-form">
        <div class="filter-group">
          <label for="tipo_archivo">Tipo de Archivo:</label>
          <select name="tipo_archivo" id="tipo_archivo">
            <option value="">Todos</option>
            <option value="pdf" <?php echo ($tipo_archivo === 'pdf') ? 'selected' : ''; ?>>PDF</option>
            <option value="doc" <?php echo ($tipo_archivo === 'doc') ? 'selected' : ''; ?>>Word</option>
            <option value="docx" <?php echo ($tipo_archivo === 'docx') ? 'selected' : ''; ?>>Word (docx)</option>
            <option value="xls" <?php echo ($tipo_archivo === 'xls') ? 'selected' : ''; ?>>Excel</option>
            <option value="xlsx" <?php echo ($tipo_archivo === 'xlsx') ? 'selected' : ''; ?>>Excel (xlsx)</option>
            <option value="ppt" <?php echo ($tipo_archivo === 'ppt') ? 'selected' : ''; ?>>PowerPoint</option>
            <option value="pptx" <?php echo ($tipo_archivo === 'pptx') ? 'selected' : ''; ?>>PowerPoint (pptx)</option>
          </select>
        </div>

        <div class="filter-group-name">
          <label for="buscar_por_nombre">Buscar por Nombre:</label>
          <input type="text" id="buscar_por_nombre" name="buscar_por_nombre" placeholder="Nombre del documento" />
        </div>

        <div class="filter-group">
          <label for="ordenar_por_fecha">Ordenar por Fecha:</label>
          <select name="ordenar_por_fecha" id="ordenar_por_fecha">
            <option value="">Ninguno</option>
            <option value="asc" <?php echo ($ordenar_por_fecha === 'asc') ? 'selected' : ''; ?>>Ascendente</option>
            <option value="desc" <?php echo ($ordenar_por_fecha === 'desc') ? 'selected' : ''; ?>>Descendente</option>
          </select>
        </div>

        <div class="filter-actions">
          <button type="submit" class="btn btn-secondary">Filtrar</button>
          <a href="dashboard.php" class="btn btn-danger">Quitar Filtro</a>
        </div>
      </form>

      <div class="filter-actions-convert">
        <form action="convert.php" method="GET">
          <label for="documento">Seleccionar Documento:</label>
          <select name="id" class="form-control-convert" required>
            <option value="">Todos los Documentos</option>
            <?php foreach ($documentos as $doc): ?>
            <?php if ($doc['type'] !== 'pdf'): ?>
            <option value="<?php echo htmlspecialchars($doc['id_documento']); ?>">
              <?php echo htmlspecialchars($doc['nombre']); ?>
              (<?php echo htmlspecialchars(strtoupper($doc['type'])); ?>)
            </option>
            <?php endif; ?>
            <?php endforeach; ?>
          </select>
          <br>
          <button type="submit" class="btn btn-secondary pdf-icon">Convertir a PDF</button>

        </form>
      </div>

      <h2>Documentos Subidos</h2>
      <div class="documents-grid">
        <?php if (!empty($documentos)): ?>
        <?php foreach ($documentos as $doc): ?>
        <div class="document-card" id="row-<?php echo htmlspecialchars($doc['id_documento']); ?>">
          <div class="document-icon">
            <?php
                $iconPath = match ($doc['type']) {
                  'pdf' => 'icons/pdf.png',
                  'doc', 'docx' => 'icons/docx.png',
                  'xls', 'xlsx' => 'icons/xlsx.png',
                  'ppt', 'pptx' => 'icons/pptx.png',
                  default => 'icons/default.png'
                };
                ?>
            <img src="<?php echo htmlspecialchars($iconPath); ?>" alt="<?php echo htmlspecialchars($doc['type']); ?>"
              class="doc-icon" />
          </div>
          <div class="document-info">
            <p>Fecha: <?php echo htmlspecialchars($doc['fecha_creacion']); ?></p>
            <h3><?php echo htmlspecialchars(preg_replace('/^\d+_/', '', $doc['nombre'])); ?></h3>
          </div>
          <div class="document-actions">
            <a href="<?php echo htmlspecialchars($doc['link']); ?>" download class="action-btn download-btn">
              <i class="fas fa-download"></i>
            </a>
            <a href="#" onclick="confirmDelete(<?php echo htmlspecialchars($doc['id_documento']); ?>)"
              class="action-btn delete-btn">
              <i class="fas fa-trash-alt"></i>
            </a>
          </div>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <p>No se encontraron documentos.</p>
        <?php endif; ?>
      </div>
    </section>

  </main>

  <script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este documento?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id: id
        },
        success: function(response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function() {
              $(this).remove();
            });
            alert('Documento eliminado exitosamente.');
          } else {
            alert('Error al eliminar el documento.');
          }
        },
        error: function(xhr, status, error) {
          console.error(xhr.responseText);
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function() {
    $('#form-busqueda').on('submit', function(event) {
      event.preventDefault();

      $.ajax({
        url: 'consultas.php',
        method: 'GET',
        data: $(this).serialize(),
        success: function(data) {
          $('#resultados_busqueda').html(data);
        },
        error: function() {
          $('#resultados_busqueda').html('<li>Error en la búsqueda.</li>');
        }
      });
    });
  });
  </script>
  </script>
</body>

</html>