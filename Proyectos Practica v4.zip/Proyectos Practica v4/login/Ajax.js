$(document).ready(function() {
    $('#loginForm').on('submit', function(e) {
        e.preventDefault();

        var username = $('#username').val();
        var contrasena = $('#contrasena').val();

        $.ajax({
            url: 'login.php',
            type: 'POST',
            data: { username: username, contrasena: contrasena },
            success: function(response) {
                if (response.success) {
                    window.location.href = 'dashboard.php';
                } else {
                    $('#error-message').text(response.message);
                }
            },
            error: function(xhr, status) {
                $('#error-message').text('Error en la conexión, por favor intenta de nuevo.');
            }
        });
    });
});
$(document).ready(function() {
    $('#uploadForm').on('submit', function(e) {
        e.preventDefault();

        var formData = new FormData(this);

        $.ajax({
            url: 'insert.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                response = JSON.parse(response);
                if (response.success) {
                    alert(response.message);
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al realizar la solicitud: ' + error);
            }
        });
    });
});