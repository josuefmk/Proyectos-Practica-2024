document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('UsuarioForm').addEventListener('submit', function(e) {
      e.preventDefault();

      const formData = new FormData(this);

      fetch('create.php', {
          method: 'POST',
          body: formData
      })
      .then(response => response.text())
      .then(data => {
          document.getElementById('result').innerHTML = data;
          this.reset();
          loadRecords();
      })
      .catch(error => {
          console.error('Error:', error);
      });
  });

  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('tableContainer').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }


loadRecords();

//Formulario agregar
   $(document).ready(function () {
      $('#diagnosticoForm').submit(function (e) {
        e.preventDefault();

        $.ajax({
          type: $(this).attr('method'),
          url: $(this).attr('action'),
          data: $(this).serialize(),
          success: function (response) {
            $('#result').html('<p class="success">Diagnóstico agregado exitosamente.</p>');
            location.reload();
          },
          error: function () {
            $('#result').html('<p class="error">Error al agregar diagnóstico.</p>');
          }
        });
      });



  // Manejador para mostrar/ocultar el formulario de agregar usuario
  document.getElementById("toggleFormBtn").addEventListener("click", function () {
    const formContainer = document.getElementById("UsuarioFormContainer");

    if (formContainer.style.display === "none" || formContainer.style.display === "") {
      formContainer.style.display = "block";
    } else {
      formContainer.style.display = "none";
    }
  });
});
});


$(document).ready(function () {

  $('#searchForm').submit(function (e) {
    e.preventDefault();

    if (validarBusqueda()) {
      $.ajax({
        type: 'GET',
        url: 'read.php',
        data: $(this).serialize(),
        success: function (response) {
          $('#searchResult').html(response);
        },
        error: function () {
          $('#searchResult').html('<p class="error">Error al buscar.</p>');
        }
      });
    } else {
      alert('Por favor, ingresa al menos un dato para buscar.');
    }
  });

  // Función de validación simple
  function validarBusqueda() {
    const usuario = $('#search_usuario').val().trim();
    return usuario.length > 0;
  }
});
