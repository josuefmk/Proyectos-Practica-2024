<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Usuario</title>
</head>

<body>

  <?php
  include 'conexion.php';

  if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
  }

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];
  } else {
    echo "<p class='error'>ID inválido.</p>";
    exit;
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['usuario'])) {
      $usuario = $conn->real_escape_string($_POST['usuario']);

      $sql = "UPDATE tbl_usuarios_documentos SET usuario='$usuario' WHERE id_usuario=$id";

      if ($conn->query($sql)) {
        echo "<p class='success'>Registro actualizado correctamente.</p>";
      } else {
        echo "<p class='error'>Error al actualizar: " . $conn->error . "</p>";
      }
    } else {
      echo "<p class='error'>Campo 'usuario' no enviado.</p>";
    }
  } else {
    // Obtener los datos actuales del usuario
    $result = $conn->query("SELECT * FROM tbl_usuarios_documentos WHERE id_usuario=$id");

    if ($result && $result->num_rows > 0) {
      $row = $result->fetch_assoc();
    } else {
      echo "<p class='error'>No se encontró el usuario.</p>";
      exit;
    }
  }


  $conn->close();
  ?>


  <div class="form-container">
    <h1>Actualizar Usuario</h1>
    <form method="POST">
      <label for="usuario">Nombre Usuario:</label>
      <input type="text" id="usuario" name="usuario" value="<?php echo htmlspecialchars($row['usuario']); ?>" required>
      <input type="submit" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>