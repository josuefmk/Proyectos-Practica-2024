<?php
include 'conexion.php';

$search_usuario = isset($_GET['search_usuario']) ? $_GET['search_usuario'] : '';

// Consulta SQL para mostrar todos los usuarios
$sql = "SELECT id_usuario, usuario, contrasena FROM tbl_usuarios_documentos";

// Si se ingresó un nombre de usuario, agregamos el filtro
if ($search_usuario !== '') {
  $sql .= " WHERE usuario LIKE '%" . $conn->real_escape_string($search_usuario) . "%'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='1'>
          <tr>
            <th>Usuario</th>
            <th>Contraseña</th>
            <th>Acciones</th>
          </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_usuario']}'>
            <td>{$row['usuario']}</td>
            <td>{$row['contrasena']}</td>
            <td>
              <a href='update.php?id={$row['id_usuario']}'>Editar</a>
              <a href='javascript:void(0);' onclick='confirmDelete({$row['id_usuario']});'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay usuarios registrados.";
}

$conn->close();
?>
<script>
// Confirmación de eliminación de un registro
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        console.log(response);
        if (response === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro.');
        }
      },
      error: function(xhr, status, error) {
        console.log(xhr.responseText);
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>