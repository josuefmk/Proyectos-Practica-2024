<?php
include 'conexion.php';

// Mostrar errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Obtener datos y validar
  $usuario = $_POST['usuario'];

  if (empty($usuario)) {
    echo "Error: El Usuario es obligatorio.";
    exit;
  }

  $checkSql = "SELECT * FROM tbl_usuarios_documentos WHERE usuario = '$usuario'";
  $result = $conn->query($checkSql);

  if ($result->num_rows > 0) {
    echo "Error: El nombre de usuario ya existe.";
    exit;
  }


  $letras = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 3);
  $numeros = substr(str_shuffle('0123456789'), 0, 3);
  $contrasena = $letras . $numeros;


  $sql = "INSERT INTO tbl_usuarios_documentos (usuario, contrasena) VALUES ('$usuario', '$contrasena')";

  if ($conn->query($sql) === TRUE) {
    echo "Usuario guardado correctamente. Contraseña generada: $contrasena";
  } else {
    echo "Error al guardar el usuario: " . $conn->error;
  }
}
?>