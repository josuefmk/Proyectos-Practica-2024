<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$queryCursos = "SELECT nombre, dias_clases, hora_desde, hora_hasta, fecha_inicio, horas_totales, id_centroingreso FROM tbl_cursos
                JOIN tbl_centrosdeingreso
                ON id_centronegocio = id_centroingreso";

$queryFeriados = "SELECT fecha FROM tbl_feriados";

$dias_semana_espanol = [
  1 => 'Lunes',
  2 => 'Martes',
  3 => 'Miércoles',
  4 => 'Jueves',
  5 => 'Viernes',
  6 => 'Sábado',
];

// Obtener lista de feriados
$feriados = [];
$resultFeriados = $conn->query($queryFeriados);
if ($resultFeriados) {
  while ($row = $resultFeriados->fetch_assoc()) {
    $feriados[] = $row['fecha'];
  }
}

// Función para obtener las fechas de clase y ajustar con feriados
function obtenerFechasClases($fechaInicioStr, $fechaFinStr, $diasClases, $feriados)
{
  $fechaInicio = new DateTime($fechaInicioStr);
  $fechaFin = new DateTime($fechaFinStr);
  $fechasClases = [];
  $feriadosEnClases = [];

  while ($fechaInicio <= $fechaFin) {
    $diaNumero = (int) $fechaInicio->format('N');

    if (in_array($fechaInicio->format('Y-m-d'), $feriados) && in_array($diaNumero, $diasClases)) {
      $feriadosEnClases[] = $fechaInicio->format('Y-m-d');
    } elseif (in_array($diaNumero, $diasClases)) {
      $fechasClases[] = $fechaInicio->format('Y-m-d');
    }

    $fechaInicio->modify('+1 day');
  }

  return [$fechasClases, $fechaFin, $feriadosEnClases];
}

// Función para calcular la fecha propuesta del próximo curso
function calcularFechaPropuesta($fechaFin, $diasClases, $feriados)
{
  $fechaPropuesta = clone $fechaFin;

  do {
    $fechaPropuesta->modify('+1 day');
    $diaNumero = (int) $fechaPropuesta->format('N');
  } while (!in_array($diaNumero, $diasClases) || in_array($fechaPropuesta->format('Y-m-d'), $feriados));

  return $fechaPropuesta;
}

// Ejecutar la consulta de cursos
$stmt = $conn->prepare($queryCursos);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Nombre</th>
                <th>Día Clases</th>
                <th>Hora Inicio</th>
                <th>Hora Termino</th>
                <th>Fecha Inicio</th>
                <th>Fecha Fin</th>
                <th>Horas Totales</th>
                <th>Feriados en Clases</th>
                <th>Fecha Propuesta Próximo Curso</th> <!-- Nueva columna -->
            </tr>";

  while ($row = $result->fetch_assoc()) {
    $dias_frecuencia_nombres = [];
    $dias_clases = str_split($row['dias_clases']);

    foreach ($dias_clases as $dia) {
      $dia_num = (int) $dia;
      if (isset($dias_semana_espanol[$dia_num])) {
        $dias_frecuencia_nombres[] = $dias_semana_espanol[$dia_num];
      }
    }
    $dias_frecuencia_texto = implode(', ', $dias_frecuencia_nombres);

    $horaInicio = DateTime::createFromFormat('H:i', $row['hora_desde']);
    $horaTermino = DateTime::createFromFormat('H:i', $row['hora_hasta']);
    if (!$horaInicio || !$horaTermino) {
      die("Error al crear las horas de clase: Hora inicio (" . $row['hora_desde'] . "), Hora termino (" . $row['hora_hasta'] . ")");
    }
    $duracionClaseHoras = ($horaTermino->getTimestamp() - $horaInicio->getTimestamp()) / 3600;

    $horas_por_dia = array_fill(1, 7, 0);
    foreach ($dias_clases as $dia) {
      $horas_por_dia[(int) $dia] += $duracionClaseHoras;
    }

    $horas_semanales = array_sum($horas_por_dia);

    if ($horas_semanales > 0) {
      $semanas_necesarias = ceil($row['horas_totales'] / $horas_semanales);
      $dias_necesarios = $semanas_necesarias * 7;

      $fechaInicio = DateTime::createFromFormat('d/m/Y', $row['fecha_inicio']);
      if (!$fechaInicio) {
        die("Error al crear la fecha de inicio: " . $row['fecha_inicio']);
      }
      $fechaFin = clone $fechaInicio;
      $fechaFin->modify("+$dias_necesarios days");
    } else {
      $fechaFin = clone $fechaInicio;
    }

    list($fechasDeClases, $fechaFinAjustada, $feriadosEnClases) = obtenerFechasClases(
      $fechaInicio->format('Y-m-d'),
      $fechaFin->format('Y-m-d'),
      $dias_clases,
      $feriados
    );

    $fechasDeClasesTexto = implode(', ', $fechasDeClases);
    $feriadosEnClasesTexto = implode(', ', $feriadosEnClases);

    // Calcular la fecha propuesta
    $fechaPropuesta = calcularFechaPropuesta($fechaFinAjustada, $dias_clases, $feriados);

    echo "
            <tr>
                <td>" . htmlspecialchars($row['nombre']) . "</td>
                <td>" . htmlspecialchars($dias_frecuencia_texto) . "</td>
                <td>" . htmlspecialchars($row['hora_desde']) . "</td>
                <td>" . htmlspecialchars($row['hora_hasta']) . "</td>
                <td>" . htmlspecialchars($fechaInicio->format('Y-m-d')) . "</td>
                <td>" . htmlspecialchars($fechaFinAjustada->format('Y-m-d')) . "</td>
                <td>" . htmlspecialchars($row['horas_totales']) . "</td>
                <td>" . htmlspecialchars($feriadosEnClasesTexto) . "</td>
                <td>
                    <a href='../crud_cursos/index.php?fecha_inicio=" . urlencode($fechaPropuesta->format('Y-m-d')) . "&id_centroingreso=" . urlencode($row['id_centroingreso']) . "' class='curso-link'>
                " . htmlspecialchars($fechaPropuesta->format('Y-m-d')) . "
            </a>
                </td>
            </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>