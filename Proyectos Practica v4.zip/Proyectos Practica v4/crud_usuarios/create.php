<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_usuario = time();
  $estado = $_POST['estado'];
  $acceso = $_POST['acceso'];
  $rut = $_POST['rut'];
  $rut_usuario = $_POST['rut_usuario'];
  $usuario = $_POST['usuario'];
  $clave = $_POST['clave'];
  $id_nivel = $_POST['id_nivel'];
  $nombres = $_POST['nombres'];
  $apellidos = $_POST['apellidos'];
  $sexo = $_POST['sexo'];
  $edad = $_POST['edad'];
  $referencia = time();
  $correo = $_POST['correo'];
  $correo_pass = $_POST['correo_pass'];
  $telefono = $_POST['telefono'];
  $anexo = $_POST['anexo'];
  $id_sesion = time();
  $id_click = time();


  $foto = '';
  if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
    $archivo_tmp = $_FILES['foto']['tmp_name'];
    $nombre_archivo = $_FILES['foto']['name'];
    $tipo_archivo = $_FILES['foto']['type'];
    $tamanio_archivo = $_FILES['foto']['size'];


    $directorio_destino = 'uploads/';


    $nombre_archivo_destino = $directorio_destino . time() . '-' . basename($nombre_archivo);


    $tipos_permitidos = ['image/jpeg', 'image/png'];
    if (in_array($tipo_archivo, $tipos_permitidos)) {
      if (move_uploaded_file($archivo_tmp, $nombre_archivo_destino)) {
        $foto = $nombre_archivo_destino;
      } else {
        echo 'Error al mover el archivo.';
        exit;
      }
    } else {
      echo 'El archivo no es una imagen válida.';
      exit;
    }
  }


  $stmt = $conn->prepare("INSERT INTO tbl_usuarios(id_usuario, estado, acceso, rut, rut_usuario, usuario, clave, id_nivel, nombres, apellidos, sexo, edad, referencia, correo, correo_pass, telefono, anexo, id_sesion, id_click, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }


  $stmt->bind_param(
    "iiissssissiiisssisis",
    $id_usuario,
    $estado,
    $acceso,
    $rut,
    $rut_usuario,
    $usuario,
    $clave,
    $id_nivel,
    $nombres,
    $apellidos,
    $sexo,
    $edad,
    $referencia,
    $correo,
    $correo_pass,
    $telefono,
    $anexo,
    $id_sesion,
    $id_click,
    $foto
  );


  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el usuario: " . $stmt->error;
  }


  $stmt->close();
  $conn->close();
}
?>