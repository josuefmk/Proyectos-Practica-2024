<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);

$EstadoString = [
  0 => 'Off',
  1 => 'On'
];

$AccesoString = [
  0 => 'Local',
  1 => 'Remoto'
];

$SexoString = [
  0 => 'Hombre',
  1 => 'Mujer'
];





//estados
$estadosOptions = '';
$result_estado = $conn->query("SELECT DISTINCT estado FROM tbl_usuarios");
while ($row = $result_estado->fetch_assoc()) {
  $estado_num = (int) $row['estado'];
  $estado_texto = isset($EstadoString[$estado_num]) ? $EstadoString[$estado_num] : 'No existe';
  $estadosOptions .= "<option value='{$estado_num}'>{$estado_texto}</option>";
}

//  acceso
$accesoOptions = '';
$result_acc = $conn->query("SELECT DISTINCT acceso FROM tbl_usuarios");
while ($row = $result_acc->fetch_assoc()) {
  $acceso_num = (int) $row['acceso'];
  $acceso_texto = isset($AccesoString[$acceso_num]) ? $AccesoString[$acceso_num] : 'No existe';
  $accesoOptions .= "<option value='{$acceso_num}'>{$acceso_texto}</option>";
}

// sexo
$sexoOptions = '';
$result_sex = $conn->query("SELECT DISTINCT sexo FROM tbl_usuarios");
while ($row = $result_sex->fetch_assoc()) {
  $sexo_num = (int) $row['sexo'];
  $sexo_texto = isset($SexoString[$sexo_num]) ? $SexoString[$sexo_num] : 'No existe';
  $sexoOptions .= "<option value='{$sexo_num}'>{$sexo_texto}</option>";
}


$cargoOptions = '';
$result_cargo = $conn->query("SELECT DISTINCT cargo FROM tbl_niveles");
while ($row = $result_cargo->fetch_assoc()) {
  $cargoOptions .= "<option value='{$row['cargo']}'>{$row['cargo']}</option>";
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Usuario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Usuario</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php" enctype="multipart/form-data">
      <h2>Agregar Nuevo Usuario</h2>

      <label for="estado">Estado:</label>
      <select id="estado" name="estado">
        <option value="">Seleccione el Estado</option>
        <?php echo $estadosOptions; ?>
      </select>

      <label for="acceso">Acceso:</label>
      <select id="acceso" name="acceso">
        <option value="">Seleccione el Acceso</option>
        <?php echo $accesoOptions; ?>
      </select>


      <label for="rut">RUT:</label>
      <input type="text" id="rut" name="rut" max="12" required>

      <label for="rut_usuario">RUT Usuario:</label>
      <input type="text" id="rut_usuario" name="rut_usuario" required>

      <label for="usuario">Usuario:</label>
      <input type="text" id="usuario" name="usuario" required>

      <label for="clave">Clave:</label>
      <input type="text" id="clave" name="clave" required>



      <label for="id_nivel">ID Nivel:</label>
      <input type="number" id="id_nivel" name="id_nivel" required>

      <label for="nombres">Nombres:</label>
      <input type="text" id="nombres" name="nombres" required>

      <label for="apellidos">Apellidos:</label>
      <input type="text" id="apellidos" name="apellidos" required>

      <label for="sexo">Sexo:</label>
      <select id="sexo" name="sexo">
        <option value="">Seleccione el Sexo</option>
        <?php echo $sexoOptions; ?>
      </select>

      <label for="edad">Edad:</label>
      <input type="number" id="edad" name="edad" required>

      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" required>

      <label for="correo_pass">Contraseña Correo:</label>
      <input type="password" id="correo_pass" name="correo_pass" required>

      <label for="telefono">Telefono:</label>
      <input type="tel" id="telefono" name="telefono" required>

      <label for="anexo">Anexo:</label>
      <input type="number" id="anexo" name="anexo" required>



      <label for="foto">Foto:</label>
      <input type="file" id="foto" name="foto" accept="image/*">

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_cargo">Cargo:</label>
    <select id="search_cargo" name="search_cargo">
      <option value="">Seleccione un Cargo</option>
      <?php echo $cargoOptions; ?>
    </select>

    <label for="search_rut">RUT:</label>
    <input type="text" id="search_rut" name="search_rut">



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>