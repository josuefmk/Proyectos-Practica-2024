<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Usuario</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  if (isset($_GET['id_usuario'])) {
    $id = $_GET['id_usuario'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $estado = $conn->real_escape_string($_POST['estado'] ?? '');
    $acceso = $conn->real_escape_string($_POST['acceso'] ?? '');
    $rut = $conn->real_escape_string($_POST['rut'] ?? '');
    $rut_usuario = $conn->real_escape_string($_POST['rut_usuario'] ?? '');
    $usuario = $conn->real_escape_string($_POST['usuario'] ?? '');
    $clave = $conn->real_escape_string($_POST['clave'] ?? '');
    $id_nivel = !empty($_POST['id_nivel']) ? $conn->real_escape_string($_POST['id_nivel']) : null;
    $nombres = $conn->real_escape_string($_POST['nombres'] ?? '');
    $apellidos = $conn->real_escape_string($_POST['apellidos'] ?? '');
    $sexo = $conn->real_escape_string($_POST['sexo'] ?? '');
    $edad = $conn->real_escape_string($_POST['edad'] ?? '');
    $correo = $conn->real_escape_string($_POST['correo'] ?? '');
    $correo_pass = $conn->real_escape_string($_POST['correo_pass'] ?? '');
    $telefono = $conn->real_escape_string($_POST['telefono'] ?? '');
    $anexo = $conn->real_escape_string($_POST['anexo'] ?? '');

    // Manejar la foto solo si se ha subido una
    if (!empty($_FILES['foto']['name'])) {
      $foto = 'ruta_de_guardado/' . basename($_FILES['foto']['name']);
      move_uploaded_file($_FILES['foto']['tmp_name'], $foto);
    } else {
      $foto = $row['foto'] ?? null;
    }



    $sql = "UPDATE tbl_usuarios
            SET estado='$estado', acceso='$acceso', rut='$rut', rut_usuario='$rut_usuario', usuario='$usuario',
                clave='$clave', id_nivel=" . ($id_nivel !== null ? "'$id_nivel'" : "NULL") . ",
                nombres='$nombres', apellidos='$apellidos', sexo='$sexo', edad='$edad', correo='$correo',
                correo_pass='$correo_pass', telefono='$telefono', anexo='$anexo', foto=" . ($foto !== null ? "'$foto'" : "NULL") . "
            WHERE id_usuario='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    $result = $conn->query("SELECT * FROM tbl_usuarios Where id_usuario=$id");
    $row = $result->fetch_assoc();


    $EstadoString = [
      0 => 'Off',
      1 => 'On'
    ];

    $AccesoString = [
      0 => 'Local',
      1 => 'Remoto'
    ];

    $SexoString = [
      0 => 'Hombre',
      1 => 'Mujer'
    ];

    $cargoOptions = '';
    $result_cargo = $conn->query("SELECT DISTINCT cargo, id_nivel FROM tbl_niveles");

    while ($rowcargo = $result_cargo->fetch_assoc()) {

      $selected = ($row['id_nivel'] == $rowcargo['id_nivel']) ? 'selected' : '';
      $cargoOptions .= "<option value='{$rowcargo['id_nivel']}' {$selected}>{$rowcargo['cargo']}</option>";
    }


    $estadoOptions = '';
    foreach ($EstadoString as $estado_num => $estado_texto) {
      $selected = ($row['estado'] == $estado_num) ? 'selected' : '';
      $estadoOptions .= "<option value='{$estado_num}' {$selected}>{$estado_texto}</option>";
    }


    $accesoOptions = '';
    foreach ($AccesoString as $acceso_num => $acceso_texto) {
      $selected = ($row['acceso'] == $acceso_num) ? 'selected' : '';
      $accesoOptions .= "<option value='{$acceso_num}' {$selected}>{$acceso_texto}</option>";
    }


    $sexoOptions = '';
    foreach ($SexoString as $sexo_num => $sexo_texto) {
      $selected = ($row['sexo'] == $sexo_num) ? 'selected' : '';
      $sexoOptions .= "<option value='{$sexo_num}' {$selected}>{$sexo_texto}</option>";
    }


  }


  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Nivel</h1>
    <form method="POST" enctype="multipart/form-data">

      <label for="estado">Estado:</label>
      <select id="estado" name="estado">
        <?php echo $estadoOptions; ?>
      </select>

      <label for="acceso">Acceso:</label>
      <select id="acceso" name="acceso">
        <?php echo $accesoOptions; ?>
      </select>
      <label for="rut">RUT:</label>
      <input type="text" id="rut" name="rut" value="<?php echo htmlspecialchars($row['rut'] ?? ''); ?>" required>

      <label for="rut_usuario">RUT Usuario:</label>
      <input type="text" id="rut_usuario" name="rut_usuario"
        value="<?php echo htmlspecialchars($row['rut_usuario'] ?? ''); ?>">

      <label for="usuario">Usuario:</label>
      <input type="text" id="usuario" name="usuario" value="<?php echo htmlspecialchars($row['usuario'] ?? ''); ?>"
        required>

      <label for="clave">Clave:</label>
      <input type="password" id="clave" name="clave" value="<?php echo htmlspecialchars($row['clave'] ?? ''); ?>">

      <label for="id_nivel">Cargo:</label>
      <select id="id_nivel" name="id_nivel">
        <option value="">Seleccione un Cargo</option>
        <?php echo $cargoOptions; ?>
      </select>

      <label for="nombres">Nombres:</label>
      <input type="text" id="nombres" name="nombres" value="<?php echo htmlspecialchars($row['nombres'] ?? ''); ?>"
        required>

      <label for="apellidos">Apellidos:</label>
      <input type="text" id="apellidos" name="apellidos"
        value="<?php echo htmlspecialchars($row['apellidos'] ?? ''); ?>" required>

      <label for="sexo">Sexo:</label>
      <select id="sexo" name="sexo">
        <?php echo $sexoOptions; ?>
      </select>

      <label for="edad">Edad:</label>
      <input type="number" id="edad" name="edad" value="<?php echo htmlspecialchars($row['edad'] ?? ''); ?>">


      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($row['correo'] ?? ''); ?>"
        required>

      <label for="correo_pass">Correo Pass:</label>
      <input type="password" id="correo_pass" name="correo_pass"
        value="<?php echo htmlspecialchars($row['correo_pass'] ?? ''); ?>">

      <label for="telefono">Teléfono:</label>
      <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($row['telefono'] ?? ''); ?>">

      <label for="anexo">Anexo:</label>
      <input type="text" id="anexo" name="anexo" value="<?php echo htmlspecialchars($row['anexo'] ?? ''); ?>">


      <?php if (!empty($row['foto'])): ?>

        <p>Imagen actual:</p>
        <img src="<?php echo htmlspecialchars($row['foto']); ?>" alt="Foto actual" style="max-width: 200px;">
      <?php endif; ?>

      <label for="foto">Cambiar Foto:</label>
      <input type="file" id="foto" name="foto" accept="image/*">



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>