<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_cargo = isset($_GET['search_cargo']) ? $_GET['search_cargo'] : '';
$search_rut = isset($_GET['search_rut']) ? $_GET['search_rut'] : '';



$query = "SELECT u.*, n.cargo
          FROM tbl_usuarios u
          JOIN tbl_niveles n ON u.id_nivel = n.id_nivel";


$types = '';
$params = [];

if (!empty($search_rut)) {
  $query .= " AND rut LIKE ?";
  $params[] = "%" . $search_rut . "%";
  $types .= 's';
}
if (!empty($search_cargo)) {
  $query .= " AND cargo LIKE ?";
  $params[] = "%" . $search_cargo . "%";
  $types .= 's';
}

$EstadoString = [
  0 => 'Off',
  1 => 'On'
];

$AccesoString = [
  0 => 'Local',
  1 => 'Remoto'
];

$SexoString = [
  0 => 'Hombre',
  1 => 'Mujer'
];



$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

function safe_htmlspecialchars($value)
{
  return htmlspecialchars($value ?? '');
}
if ($result->num_rows > 0) {
  echo '<div class="carta-container">';
  while ($row = $result->fetch_assoc()) {
    # Estado Texto
    $Estado = [];
    $EstadoS = explode(',', $row['estado']);
    foreach ($EstadoS as $Esta) {
      $Est = (int) $Esta;
      if (isset($EstadoString[$Est])) {
        $Estado[] = $EstadoString[$Est];
      }
    }
    $Estado_texto = implode(', ', $Estado);

    # Acceso Texto
    $Acceso = [];
    $AccesoS = explode(',', $row['acceso']);
    foreach ($AccesoS as $Acc) {
      $AccVal = (int) $Acc;
      if (isset($AccesoString[$AccVal])) {
        $Acceso[] = $AccesoString[$AccVal];
      }
    }
    $Acceso_texto = implode(', ', $Acceso);

    # Sexo Texto
    $Sexo = [];
    $SexoS = explode(',', $row['sexo']);
    foreach ($SexoS as $Sx) {
      $SxVal = (int) $Sx;
      if (isset($SexoString[$SxVal])) {
        $Sexo[] = $SexoString[$SxVal];
      }
    }
    $Sexo_texto = implode(', ', $Sexo);
    echo '<div class="carta">';
    echo '<div class="carta-header">';
    echo '<h3>Nombre Usuario : ' . safe_htmlspecialchars($row['nombres']) . '</h3>';
    echo '</div>';
    echo '<p><strong>Estado:</strong> ' . safe_htmlspecialchars($Estado_texto) . '</p>';
    echo '<p><strong>Acceso:</strong> ' . safe_htmlspecialchars($Acceso_texto) . '</p>';
    echo '<p><strong>RUT:</strong> ' . safe_htmlspecialchars($row['rut']) . '</p>';
    echo '<p><strong>RUT Usuario:</strong> ' . safe_htmlspecialchars($row['rut_usuario'] ?? '') . '</p>';
    echo '<p><strong>Usuario:</strong> ' . safe_htmlspecialchars($row['usuario'] ?? '') . '</p>';
    echo '<p><strong>Clave:</strong> ' . safe_htmlspecialchars($row['clave'] ?? '') . '</p>';
    echo '<p><strong>Cargo:</strong> ' . safe_htmlspecialchars($row['cargo'] ?? '') . '</p>';
    echo '<p><strong>Nombres:</strong> ' . safe_htmlspecialchars($row['nombres'] ?? '') . '</p>';
    echo '<p><strong>Apellidos:</strong> ' . safe_htmlspecialchars($row['apellidos'] ?? '') . '</p>';
    echo '<p><strong>Sexo:</strong> ' . safe_htmlspecialchars($Sexo_texto ?? '') . '</p>';
    echo '<p><strong>Edad:</strong> ' . safe_htmlspecialchars($row['edad'] ?? '') . '</p>';
    echo '<p><strong>Correo:</strong> ' . safe_htmlspecialchars($row['correo'] ?? '') . '</p>';
    echo '<p><strong>Correo Pass:</strong> ' . safe_htmlspecialchars($row['correo_pass'] ?? '') . '</p>';
    echo '<p><strong>Telefono:</strong> ' . safe_htmlspecialchars($row['telefono'] ?? '') . '</p>';
    echo '<p><strong>Anexo:</strong> ' . safe_htmlspecialchars($row['anexo'] ?? '') . '</p>';
    echo '<p><strong>Foto:</strong> <img src="' . safe_htmlspecialchars($row['foto'] ?? '') . '" alt="Imagen" style="max-width: 100%; height: auto;" /></p>';


    echo '<td>';
    echo '<div class="acciones">';
    echo '<a href="update.php?id_usuario=' . urlencode($row['id_usuario']) . '" class="btn btn-sm btn-warning">Editar</a>';
    echo '<a href="javascript:void(0);" onclick="confirmDelete(' . htmlspecialchars(json_encode($row['id_usuario'])) . ');" class="btn btn-sm btn-danger">Eliminar</a>';
    echo '</div>';

    echo '</td>';

    echo '</div>';
  }

  echo '</div>';
} else {
  echo "No hay registros.";
}


$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_usuario: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });
</script>