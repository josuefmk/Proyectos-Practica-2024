<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['id_usuario'])) {
    $id = $_POST['id_usuario'];

    $stmt = $conn->prepare("DELETE FROM tbl_usuarios WHERE id_usuario = ?");
    if ($stmt === false) {
      echo "Error en la preparación de la consulta: " . $conn->error;
      exit;
    }
    $stmt->bind_param("i", $id);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
      echo "success";
    } else {
      echo "Error al eliminar el Nivel: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
  } else {
    echo "ID del producto no está.";
  }
} else {
  echo "Método de solicitud no válido.";
}
?>