<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_nombre_completo = isset($_GET['search_nombre_completo']) ? $_GET['search_nombre_completo'] : '';
$fecha_desde = isset($_GET['fecha_desde']) ? $_GET['fecha_desde'] : '';
$fecha_hasta = isset($_GET['fecha_hasta']) ? $_GET['fecha_hasta'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';

$query = "SELECT pp.* ,mp.nombre FROM tbl_pagos_profesores pp JOIN tbl_medio_pago mp ON mp.id_mediopago=pp.forma_pago";

$types = '';
$params = [];

if (!empty($search_nombre_completo)) {
  $query .= " AND pp.nombre_empleado = ?";
  $types .= 's';
  $params[] = $search_nombre_completo;
}
if (!empty($fecha_desde) && !empty($fecha_hasta)) {
  $query .= " AND (pp.fecha_desde >= ? AND pp.fecha_hasta <= ?)";
  $types .= 'ss';
  $params[] = $fecha_desde;
  $params[] = $fecha_hasta;
} elseif (!empty($fecha_desde)) {
  $query .= " AND pp.fecha_desde >= ?";
  $types .= 's';
  $params[] = $fecha_desde;
} elseif (!empty($fecha_hasta)) {
  $query .= " AND pp.fecha_hasta <= ?";
  $types .= 's';
  $params[] = $fecha_hasta;
}
if (!empty($search_estado)) {
  $query .= " AND pp.estado = ?";
  $types .= 's';
  $params[] = $search_estado;
}

$EstadoString = [
  0 => 'Pendiente',
  1 => 'Pago'
];
$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Monto</th>
                <th>Nombre Empleado</th>
                <th>Fecha de Pago</th>
                <th>Fecha Desde</th>
                <th>Fecha Hasta</th>
                <th>RUT Relator</th>
                <th>Forma de Pago</th>
                <th>Nro de Boleta</th>
                <th>Link Boleta</th>
                <th>Estado</th>
                <th>Retención</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    # Estado Texto
    $Estado = [];
    $EstadoS = explode(',', $row['estado']);
    foreach ($EstadoS as $Esta) {
      $Est = (int) $Esta;
      if (isset($EstadoString[$Est])) {
        $Estado[] = $EstadoString[$Est];
      }
    }
    $Estado_texto = implode(', ', $Estado);
    echo "
           <td>" . htmlspecialchars($row['montos']) . "</td>
           <td>" . htmlspecialchars($row['nombre_empleado']) . "</td>
           <td>" . htmlspecialchars($row['fecha_pago']) . "</td>
           <td>" . htmlspecialchars($row['fecha_desde']) . "</td>
           <td>" . htmlspecialchars($row['fecha_hasta']) . "</td>
           <td>" . htmlspecialchars($row['rut_relator']) . "</td>
           <td>" . htmlspecialchars($row['nombre']) . "</td>
           <td>" . htmlspecialchars($row['nro_boleta']) . "</td>
             <td><a href='" . htmlspecialchars($row['link_boleta']) . "' target='_blank'>Ver PDF</a></td>
           <td>" . htmlspecialchars($Estado_texto) . "</td>
           <td>" . htmlspecialchars($row['retencion']) . "</td>

            <td>
              <a href='update.php?id_pago=" . urlencode($row['id_pago']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_pago'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_pago: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });
</script>