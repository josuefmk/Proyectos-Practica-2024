<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$formapagoOptions = '';
$result_formapago = $conn->query("SELECT id_mediopago, nombre FROM tbl_medio_pago");
while ($row = $result_formapago->fetch_assoc()) {
  $formapagoOptions .= "<option value='{$row['id_mediopago']}'>{$row['nombre']}</option>";
}


$nombreEmpOptions = '';
$result_nombreEmp = $conn->query("SELECT DISTINCT id_usuario, nombres, apellidos FROM tbl_usuarios");
while ($row = $result_nombreEmp->fetch_assoc()) {

  $nombreEmpOptions .= "<option value='{$row['id_usuario']}'>{$row['nombres']} {$row['apellidos']}</option>";
}



$EstadoString = [
  0 => 'Pendiente',
  1 => 'Pago'
];
$estadosOptions = '';
$result_estado = $conn->query("SELECT DISTINCT estado FROM tbl_pagos_profesores");
while ($row = $result_estado->fetch_assoc()) {
  $estado_num = (int) $row['estado'];
  $estado_texto = isset($EstadoString[$estado_num]) ? $EstadoString[$estado_num] : 'No existe';
  $estadosOptions .= "<option value='{$estado_num}'>{$estado_texto}</option>";
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Pagos Profesores</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php" enctype="multipart/form-data">
      <h2>Agregar Nuevo Dato</h2>


      <label for="montos">Monto:</label>
      <input type="number" id="montos" name="montos" required>


      <label for="nombre_empleado">Nombre de Empleado:</label>
      <select id="nombre_empleado" name="id_usuario">
        <option value="">Seleccione un Empleado</option>
        <?php echo $nombreEmpOptions; ?>
      </select>

      <label for="fecha_pago">Fecha Pago:</label>
      <input type="date" id="fecha_pago" name="fecha_pago" required>

      <label for="fecha_desde">Fecha Desde:</label>
      <input type="date" id="fecha_desde" name="fecha_desde" required>

      <label for="fecha_hasta">Fecha Hasta:</label>
      <input type="date" id="fecha_hasta" name="fecha_hasta" required>

      <label for="rut_relator">RUT Relator:</label>
      <input type="text" id="rut_relator" name="rut_relator" required>

      <label for="forma_pago">Forma de Pago:</label>
      <select id="forma_pago" name="forma_pago">
        <option value="">Seleccione una Forma de Pago</option>
        <?php echo $formapagoOptions; ?>
      </select>

      <label for="nro_boleta">Número de boleta:</label>
      <input type="text" id="nro_boleta" name="nro_boleta" required>

      <div class="form-group">
        <label for="link_boleta"><i class="fas fa-upload"></i> Suba Boleta:</label>
        <input type="file" name="link_boleta" accept=".pdf" required>
      </div>

      <label for="estado">Estado:</label>
      <select id="estado" name="estado">
        <option value="">Seleccione el Estado</option>
        <?php echo $estadosOptions; ?>
      </select>

      <label for="retencion">Retención:</label>
      <input type="number" id="retencion" name="retencion" required>


      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Empleado</h3>

    <label for="search_nombre_completo">Nombre de Empleado:</label>
    <select id="search_nombre_completo" name="search_nombre_completo">
      <option value="">Seleccione un Empleado</option>
      <?php echo $nombreEmpOptions; ?>
    </select>

    <label for="fecha_desde">Fecha de Inicio:</label>
    <input type="date" id="fecha_desde" name="fecha_desde">

    <label for="fecha_hasta">Fecha de Fin:</label>
    <input type="date" id="fecha_hasta" name="fecha_hasta">

    <label for="search_estado">Estado:</label>
    <select id="search_estado" name="search_estado">
      <option value="">Seleccione el Estado</option>
      <?php echo $estadosOptions; ?>
    </select>


    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });
    });
  </script>
</body>