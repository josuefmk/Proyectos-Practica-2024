<?php
// Conexión a la base de datos
$conn = new mysqli("localhost", "developer", "elc2022prtc", "desarollo");

if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}