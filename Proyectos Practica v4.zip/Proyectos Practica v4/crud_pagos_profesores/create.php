<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $montos = isset($_POST['montos']) ? $_POST['montos'] : null;
  $id_usuario = isset($_POST['id_usuario']) ? $_POST['id_usuario'] : null;
  $fecha_pago = isset($_POST['fecha_pago']) ? $_POST['fecha_pago'] : null;
  $fecha_desde = isset($_POST['fecha_desde']) ? $_POST['fecha_desde'] : null;
  $fecha_hasta = isset($_POST['fecha_hasta']) ? $_POST['fecha_hasta'] : null;
  $rut_relator = isset($_POST['rut_relator']) ? $_POST['rut_relator'] : null;
  $forma_pago = isset($_POST['forma_pago']) ? $_POST['forma_pago'] : null;
  $nro_boleta = isset($_POST['nro_boleta']) ? $_POST['nro_boleta'] : null;
  $estado = isset($_POST['estado']) ? $_POST['estado'] : null;
  $retencion = isset($_POST['retencion']) ? $_POST['retencion'] : null;


  if ($id_usuario) {
    $result = $conn->query("SELECT nombres, apellidos FROM tbl_usuarios WHERE id_usuario = '$id_usuario'");
    if ($row = $result->fetch_assoc()) {
      $nombre_empleado = $row['nombres'] . ' ' . $row['apellidos'];
    } else {
      $nombre_empleado = '';
    }
  } else {
    $nombre_empleado = '';
  }

  if (isset($_FILES['link_boleta']) && $_FILES['link_boleta']['error'] == 0) {
    $link_boleta = 'uploads/' . basename($_FILES['link_boleta']['name']);
    move_uploaded_file($_FILES['link_boleta']['tmp_name'], $link_boleta);
  } else {
    $link_boleta = null;
  }

  $stmt = $conn->prepare("INSERT INTO tbl_pagos_profesores (montos, id_usuario, nombre_empleado, fecha_pago, fecha_desde, fecha_hasta, rut_relator, forma_pago, nro_boleta, link_boleta, estado, retencion)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("isssssssssii", $montos, $id_usuario, $nombre_empleado, $fecha_pago, $fecha_desde, $fecha_hasta, $rut_relator, $forma_pago, $nro_boleta, $link_boleta, $estado, $retencion);


  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>