<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Pago de Profesor</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_pago'])) {
    $id = $_GET['id_pago'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $montos = $conn->real_escape_string($_POST['montos']);

    $nombre_empleado = $conn->real_escape_string($_POST['nombre_empleado']);
    $fecha_pago = $conn->real_escape_string($_POST['fecha_pago']);
    $fecha_desde = $conn->real_escape_string($_POST['fecha_desde']);
    $fecha_hasta = $conn->real_escape_string($_POST['fecha_hasta']);
    $rut_relator = $conn->real_escape_string($_POST['rut_relator']);
    $forma_pago = $conn->real_escape_string($_POST['forma_pago']);
    $nro_boleta = $conn->real_escape_string($_POST['nro_boleta']);
    $estado = $conn->real_escape_string($_POST['estado']);
    $retencion = $conn->real_escape_string($_POST['retencion']);

    if (isset($_FILES['link_boleta']) && $_FILES['link_boleta']['error'] == 0) {
      $link_boleta = 'uploads/' . basename($_FILES['link_boleta']['name']);
      move_uploaded_file($_FILES['link_boleta']['tmp_name'], $link_boleta);
    } else {
      $link_boleta = null;
    }

    $sql = "UPDATE tbl_pagos_profesores
        SET montos='$montos',  nombre_empleado='$nombre_empleado',fecha_pago='$fecha_pago',fecha_desde='$fecha_desde',fecha_hasta='$fecha_hasta',rut_relator='$rut_relator',forma_pago='$forma_pago',nro_boleta='$nro_boleta',estado='$estado',retencion='$retencion',link_boleta='$link_boleta'
        WHERE id_pago='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_pagos_profesores WHERE id_pago=$id");
    $row = $result->fetch_assoc();


    $formapagoOptions = '';
    $result_formapago = $conn->query("SELECT id_mediopago, nombre FROM tbl_medio_pago");

    while ($rowforma = $result_formapago->fetch_assoc()) {
      $selected = ($rowforma['id_mediopago'] == $rowforma['id_mediopago']) ? 'selected' : '';
      $formapagoOptions .= "<option value='{$rowforma['id_mediopago']}' {$selected}>{$rowforma['nombre']}</option>";
    }


    $EstadoString = [
      0 => 'Pendiente',
      1 => 'Pago'
    ];
    $estadosOptions = '';
    $result_estado = $conn->query("SELECT DISTINCT estado FROM tbl_pagos_profesores");

    while ($rowestado = $result_estado->fetch_assoc()) {
      $estado_num = (int) $rowestado['estado'];
      $estado_texto = isset($EstadoString[$estado_num]) ? $EstadoString[$estado_num] : 'No existe';
      $selected = ($row['estado'] == $estado_num) ? 'selected' : '';
      $estadosOptions .= "<option value='{$estado_num}' {$selected}>{$estado_texto}</option>";
    }


    $nombreEmpOptions = '';
    $result_nombreEmp = $conn->query("SELECT DISTINCT  nombres, apellidos FROM tbl_usuarios");

    while ($rowEmp = $result_nombreEmp->fetch_assoc()) {

      $selected = ($row['nombre_empleado'] == $rowEmp['nombres'] . ' ' . $rowEmp['apellidos']) ? 'selected' : '';
      $nombreEmpOptions .= "<option value='{$rowEmp['nombres']} {$rowEmp['apellidos']}' {$selected}>{$rowEmp['nombres']} {$rowEmp['apellidos']}</option>";
    }

  }




  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Pago de Profesor</h1>
    <form method="POST" enctype="multipart/form-data">
      <label for="montos">Montos:</label>
      <input type="number" id="montos" name="montos" value="<?php echo htmlspecialchars($row['montos'] ?? ''); ?>"
        required>



      <label for="nombre_empleado">Nombre de Empleado:</label>
      <select id="nombre_empleado" name="nombre_empleado">
        <option value="">Seleccione un Empleado</option>
        <?php echo $nombreEmpOptions; ?>
      </select>

      <label for="fecha_pago">Fecha de Pago:</label>
      <input type="date" id="fecha_pago" name="fecha_pago"
        value="<?php echo htmlspecialchars($row['fecha_pago'] ?? ''); ?>" required>

      <label for="fecha_desde">Fecha desde:</label>
      <input type="date" id="fecha_desde" name="fecha_desde"
        value="<?php echo htmlspecialchars($row['fecha_desde'] ?? ''); ?>" required>

      <label for="fecha_hasta">Fecha Hasta:</label>
      <input type="date" id="fecha_hasta" name="fecha_hasta"
        value="<?php echo htmlspecialchars($row['fecha_hasta'] ?? ''); ?>" required>

      <label for="rut_relator">RUT Relator:</label>
      <input type="text" id="rut_relator" name="rut_relator"
        value="<?php echo htmlspecialchars($row['rut_relator'] ?? ''); ?>" required>

      <label for="forma_pago">Forma de Pago:</label>
      <select id="forma_pago" name="forma_pago">
        <option value="">Seleccione una Forma de Pago</option>
        <?php echo $formapagoOptions; ?>
      </select>
      <label for="nro_boleta">Número de Boleta:</label>
      <input type="text" id="nro_boleta" name="nro_boleta"
        value="<?php echo htmlspecialchars($row['nro_boleta'] ?? ''); ?>" required>

      <div class="form-group">
        <label for="link_boleta"><i class="fas fa-upload"></i> Suba Boleta:</label>
        <input type="file" name="link_boleta" accept=".pdf">
      </div>

      <label for="estado">Estado:</label>
      <select id="estado" name="estado">
        <option value="">Seleccione el Estado</option>
        <?php echo $estadosOptions; ?>
      </select>


      <label for="retencion">Retención:</label>
      <input type="number" id="retencion" name="retencion"
        value="<?php echo htmlspecialchars($row['retencion'] ?? ''); ?>" required>


      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>