<?php
$uploadDirectory = "uploads/";

// Función para contar cuántos archivos STL hay en el directorio de cargas
function countSTLFiles($directory)
{
  $files = glob($directory . '*.stl'); // Obtener todos los archivos STL
  return count($files);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
  $file = $_FILES['file'];
  $fileExtension = pathinfo($file["name"], PATHINFO_EXTENSION);

  // Validar que sea un archivo STL
  if (strtolower($fileExtension) === "stl") {
    // Comprobar el número de archivos STL ya existentes
    $existingFilesCount = countSTLFiles($uploadDirectory);
    if ($existingFilesCount >= 3) {
      echo json_encode(['status' => 'error', 'message' => 'Se ha alcanzado el número máximo de modelos (3).']);
      exit;
    }

    $filePath = $uploadDirectory . basename($file["name"]);

    // Mover el archivo subido a la carpeta
    if (move_uploaded_file($file["tmp_name"], $filePath)) {
      echo json_encode(['status' => 'success', 'filePath' => $filePath]);
    } else {
      echo json_encode(['status' => 'error', 'message' => 'Error al subir el archivo.']);
    }
  } else {
    echo json_encode(['status' => 'error', 'message' => 'Por favor sube un archivo STL válido.']);
  }
  exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Subir y visualizar STL</title>
</head>

<body>
  <div class="form-container">
    <h2>Subir un archivo STL</h2>
    <form id="uploadForm" enctype="multipart/form-data">
      <input type="file" name="file" id="file" accept=".stl">
      <input type="button" value="Subir archivo" id="uploadButton">
    </form>
  </div>
  <div class="container">
    <div class="viewer-container" id="viewer1"></div>
    <div class="viewer-container" id="viewer2"></div>
    <div class="viewer-container" id="viewer3"></div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/STLLoader.js"></script>
  <script>
  const uploadButton = document.getElementById('uploadButton');
  const uploadForm = document.getElementById('uploadForm');
  const viewerContainers = [
    document.getElementById('viewer1'),
    document.getElementById('viewer2'),
    document.getElementById('viewer3'),
  ];

  let loadedFiles = [];

  uploadButton.addEventListener('click', () => {
    const formData = new FormData(uploadForm);
    fetch('index.php', {
        method: 'POST',
        body: formData,
      })
      .then(response => response.json())
      .then(data => {
        if (data.status === 'success') {
          alert('Archivo subido exitosamente: ' + data.filePath);
          loadedFiles.push(data.filePath);
          renderSTLModels();
        } else {
          alert('Error: ' + data.message);
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });

  function renderSTLModels() {
    // Limpiar los contenedores
    viewerContainers.forEach(container => {
      container.innerHTML = '';
    });

    loadedFiles.forEach((filePath, index) => {
      if (index < viewerContainers.length) {
        const container = viewerContainers[index];
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({
          alpha: true
        }); // Permitir fondo transparente
        renderer.setSize(container.clientWidth, container.clientHeight);
        container.appendChild(renderer.domElement);

        const controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true; // Suavizar controles
        controls.dampingFactor = 0.25;

        const loader = new THREE.STLLoader();
        loader.load(filePath, geometry => {
          const material = new THREE.MeshNormalMaterial();
          const mesh = new THREE.Mesh(geometry, material);
          scene.add(mesh);

          // Centrar el modelo
          const box = new THREE.Box3().setFromObject(mesh);
          const center = box.getCenter(new THREE.Vector3());
          mesh.position.x = -center.x;
          mesh.position.y = -center.y;
          mesh.position.z = -center.z;

          camera.position.z = 5;

          const animate = function() {
            requestAnimationFrame(animate);
            controls.update(); // Actualizar controles
            renderer.render(scene, camera);
          };
          animate();
        });
      }
    });
  }
  </script>
</body>

</html>