document.getElementById('uploadButton').addEventListener('click', function () {
    if (modelCount >= MAX_MODELS) {
        alert('Se ha alcanzado el número máximo de modelos (3). No se pueden cargar más.');
        return; // Salir si se ha alcanzado el máximo
    }

    var formData = new FormData(document.getElementById('uploadForm'));

    fetch('index.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Cargar el archivo STL en el visualizador
            loadSTLModel(data.filePath);
        } else {
            alert(data.message);
        }
    })
    .catch(error => console.error('Error:', error));
});
