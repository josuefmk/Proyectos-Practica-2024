// VARIABLES
var myScene1, myCamera1, myRenderer1, controls1, myMesh1, myLight1, binary1, myGeom1, gl1;
var myScene2, myCamera2, myRenderer2, controls2, myLight2, myMesh2, binary2;
var myScene3, myCamera3, myRenderer3, controls3, myMesh3, binary3;
var stlLoader = new THREE.STLLoader();

var fov = 30;
NProgress.configure({ showBar: false });

var myVer1 = [];
var myVer2 = [];
var firstStl1 = true;
var firstStl2 = true;
var firstStl3 = true;

var container1 = document.getElementById("container1");
var container2 = document.getElementById("container2");
var container3 = document.getElementById("container3");

// INITIATE THREEJS
initiateScene1();
initiateScene2();
initiateScene3();

// RENDER FUNC
function render(){
    myRenderer1.render(myScene1, myCamera1);
    controls1.update();
    myLight1.position.copy(myCamera1.position);

    myRenderer2.render(myScene2, myCamera2);
    controls2.update();
    myLight2.position.copy(myCamera2.position);

    myRenderer3.render(myScene3, myCamera3);
    controls3.update();
    myLight3.position.copy(myCamera3.position);
    requestAnimationFrame(render);
}

// LOAD STL FIRST TIME
function loadSTL(filePath, myContainer){
    var windowContainer = document.getElementById(myContainer);

    if(myContainer === "container1"){
        // Lógica para el contenedor 1
        $(window).resize(function () {
            var width = $("#" + myContainer).width();
            var height = $("#" + myContainer).height();
            myCamera1.aspect = width / height;
            myCamera1.updateProjectionMatrix();
            myRenderer1.setSize(width, height);
        });

        stlLoader.load(filePath, createScene1);
        firstStl1 = false;
        myRenderer1.setSize($("#" + myContainer).innerWidth(), $("#" + myContainer).innerHeight());
        myRenderer1.setClearColor(0xFFFFFF, 1); // Fondo blanco
        windowContainer.appendChild(myRenderer1.domElement);
        render();

    } else if(myContainer === "container2"){
        // Lógica para el contenedor 2
        $(window).resize(function () {
            var width = $("#" + myContainer).innerWidth();
            var height = $("#" + myContainer).innerHeight();
            myCamera2.aspect = width / height;
            myCamera2.updateProjectionMatrix();
            myRenderer2.setSize(width, height);
        });

        stlLoader.load(filePath, createScene2);
        firstStl2 = false;
        myRenderer2.setSize($("#" + myContainer).innerWidth(), $("#" + myContainer).innerHeight());
        myRenderer2.setClearColor(0xFFFFFF, 1); // Fondo blanco
        windowContainer.appendChild(myRenderer2.domElement);
        render();

    } else if(myContainer === "container3"){
        // Lógica para el contenedor 3
        $(window).resize(function () {
            var width = $("#" + myContainer).innerWidth();
            var height = $("#" + myContainer).innerHeight();
            myCamera3.aspect = width / height;
            myCamera3.updateProjectionMatrix();
            myRenderer3.setSize(width, height);
        });

        stlLoader.load(filePath, createScene3);
        firstStl3 = false;
        myRenderer3.setSize($("#" + myContainer).innerWidth(), $("#" + myContainer).innerHeight());
        myRenderer3.setClearColor(0xFFFFFF, 1); // Fondo blanco
        windowContainer.appendChild(myRenderer3.domElement);
        render();
    }
}

// LOAD STL SUBSEQUENT TIMES
function loadAnotherSTL(filePath, myContainer){
    if(myContainer === "container1"){
        myScene1.remove(myScene1.children[1]);
        stlLoader.load(filePath, createScene1);
        render();
    } else if(myContainer === "container2"){
        myScene2.remove(myScene2.children[1]);
        stlLoader.load(filePath, createScene2);
        render();
    } else if(myContainer === "container3"){
        myScene3.remove(myScene3.children[1]);
        stlLoader.load(filePath, createScene3);
        render();
    }
}

// HANDLE FILE SELECTION
function handleFileSelect1(evt) {
    // Lógica para la selección de archivos en contenedor 1
}

function handleFileSelect2(evt) {
    // Lógica para la selección de archivos en contenedor 2
}

function handleFileSelect3(evt) {
    // Lógica para la selección de archivos en contenedor 3
}

// PREVENT FILES BEING DOWNLOADED
window.addEventListener("dragover", function(e) {
    e.preventDefault();
}, false);
window.addEventListener("drop", function(e) {
    e.preventDefault();
}, false);

// INITIATE SCENE
function initiateScene1(){
    myScene1 = new THREE.Scene();
    myCamera1 = new THREE.PerspectiveCamera(fov, window.innerWidth / window.innerHeight, 1, 10000);
    myRenderer1 = new THREE.WebGLRenderer();
    gl1 = myRenderer1.context;
    myCamera1.position.set(0, 0, 10);
    myScene1.add(myCamera1);
    myLight1 = new THREE.DirectionalLight(0xffffff, 0.5);
    myScene1.add(myLight1);
    controls1 = new THREE.TrackballControls(myCamera1, container1);
    controls1.rotateSpeed = 1.0;
    controls1.zoomSpeed = 1.2;
    controls1.panSpeed = 0.8;
}

function initiateScene2(){
    myScene2 = new THREE.Scene();
    myCamera2 = new THREE.PerspectiveCamera(fov, window.innerWidth / window.innerHeight, 1, 10000);
    myRenderer2 = new THREE.WebGLRenderer();
    myCamera2.position.set(0, 0, 10);
    myScene2.add(myCamera2);
    myLight2 = new THREE.DirectionalLight(0xffffff, 0.5);
    myScene2.add(myLight2);
    controls2 = new THREE.TrackballControls(myCamera2, container2);
    controls2.rotateSpeed = 1.0;
    controls2.zoomSpeed = 1.2;
    controls2.panSpeed = 0.8;
}

function initiateScene3(){
    myScene3 = new THREE.Scene();
    myCamera3 = new THREE.PerspectiveCamera(fov, window.innerWidth / window.innerHeight, 1, 10000);
    myRenderer3 = new THREE.WebGLRenderer();
    myCamera3.position.set(0, 0, 10);
    myScene3.add(myCamera3);
    myLight3 = new THREE.DirectionalLight(0xffffff, 0.5);
    myScene3.add(myLight3);
    controls3 = new THREE.TrackballControls(myCamera3, container3);
    controls3.rotateSpeed = 1.0;
    controls3.zoomSpeed = 1.2;
    controls3.panSpeed = 0.8;
}

// CREATE SCENE FUNC
function createScene1(geometry, materials) {
    myGeom1 = geometry;
    myMesh1 = new THREE.Mesh(geometry, new THREE.MeshLambertMaterial({color: 0xcab590}));
    myScene1.add(myMesh1);
    configureCamera(myCamera1, myMesh1);
    gotSTL();
}

function createScene2(geometry, materials) {
    myMesh2 = new THREE.Mesh(geometry, new THREE.MeshLambertMaterial({color: 0x82a8a9}));
    myScene2.add(myMesh2);
    configureCamera(myCamera2, myMesh2);
    gotSTL();
}

function createScene3(geometry, materials) {
    myMesh3 = new THREE.Mesh(geometry, new THREE.MeshLambertMaterial({color: 0xFFFFFF})); // Ajusta el color como desees
    myScene3.add(myMesh3);
    configureCamera(myCamera3, myMesh3);
    gotSTL();
}

// CONFIGURE CAMERA
function configureCamera(camera, mesh) {
    mesh.geometry.computeBoundingBox();
    var boundingBox = mesh.geometry.boundingBox;
    var myX = (boundingBox.max.x + boundingBox.min.x) / 2;
    var myY = (boundingBox.max.y + boundingBox.min.y) / 2;
    var myZ = (boundingBox.max.z + boundingBox.min.z) / 2;
    camera.position.set(myX, myY, boundingBox.max.z + 5);
    camera.lookAt(myX, myY, myZ);
}
