<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);


?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Ponderacion</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>


      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>

      <label for="ponderacion">Ponderación:</label>
      <input type="number" id="ponderacion" name="ponderacion" required>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_nombre">Nombre:</label>
    <input type="text" id="search_nombre" name="search_nombre" required>

    <label for="search_ponderacion">Ponderación:</label>
    <input type="number" id="search_ponderacion" name="search_ponderacion" required>


    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>