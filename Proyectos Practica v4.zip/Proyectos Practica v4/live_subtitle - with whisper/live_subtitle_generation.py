from flask import Flask, render_template, Response, stream_with_context
import cv2
import pyaudio
import wave
import os
from threading import Thread, Event
import time
import whisper
import torch

app = Flask(__name__)
camera = cv2.VideoCapture(0)

# Configuración del audio
CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100  # Puede variar
RECORD_SECONDS = 10
transcriptions = []
transcription_count = -1
waiting = False

p = pyaudio.PyAudio()
stream = p.open(format=FORMAT,
                channels=CHANNELS,
                rate=RATE,
                input=True,
                frames_per_buffer=CHUNK)

stop_event = Event()

# Función para transcribir audio con Whisper


def call_whisper(audio_stream):
    try:
        if os.path.exists(audio_stream.name):
            audio = whisper.load_audio(audio_stream.name)
            model = whisper.load_model("medium")
            result = model.transcribe(audio)
            transcription = result['text']
            # Almacena la transcripción completa
            transcriptions.append(transcription)
            print(f"Transcribed audio: {transcription}")
        else:
            print("El archivo de audio no existe.")
    except Exception as e:
        print(f"Error during transcription: {e}")

# Función que graba el audio y lo transcribe


def transcribe_audio():
    while not stop_event.is_set():
        frames = []
        for _ in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            if not stop_event.is_set():
                data = stream.read(CHUNK)
                frames.append(data)

        # Guardar los frames en un archivo WAV
        with wave.open("audio.wav", 'wb') as wf:
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(p.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(frames))

        # Transcribir audio
        if os.path.exists("audio.wav"):
            with open("audio.wav", "rb") as audio_file:
                call_whisper(audio_file)
        # Espera un segundo para evitar problemas de tiempo de audio
        time.sleep(1)


@app.route('/')
def index():
    # Iniciar el hilo de grabación al abrir la página
    if not stop_event.is_set():
        t = Thread(target=transcribe_audio)
        t.start()
    return render_template('live_subtitle_generation_index.html')


def generate_frames():
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/video')
def video():
    return Response(stream_with_context(generate_frames()), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/stop-transcription')
def stop_transcription():
    stop_event.set()
    print('Stopped transcription.')
    return "Stopped transcription."


@app.route('/get-transcription')
def generate_transcriptions():
    global waiting
    content = ''
    if transcriptions:  # Si hay transcripciones disponibles
        content = transcriptions[-1]  # Obtiene la última transcripción
        waiting = False
    elif not waiting:
        content = ""
    return content


if __name__ == "__main__":
    app.run(debug=True)
