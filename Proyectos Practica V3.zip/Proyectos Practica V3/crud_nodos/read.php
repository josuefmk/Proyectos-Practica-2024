<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_nombre = isset($_GET['search_nombre']) ? $_GET['search_nombre'] : '';




$query = "SELECT * FROM tbl_nodos WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_nombre)) {
  $query .= " AND nombre = ?";
  $types .= 's';
  $params[] = $search_nombre;
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Nombre</th>
                <th>IP</th>
                <th>Puerto</th>
                  <th>Status</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";


  while ($row = $result->fetch_assoc()) {
    $ip = $row['ip'];
    $puerto = $row['puerto'];
    $estado = 'offline';

    if (filter_var($ip, FILTER_VALIDATE_IP) && is_numeric($puerto)) {
      $conectado = @fsockopen($ip, $puerto, $errno, $errstr, 1);
      if ($conectado) {
        $estado = 'online';
        fclose($conectado);
      }
    }
    echo "
           <td>" . htmlspecialchars($row['nombre']) . "</td>
           <td>" . htmlspecialchars($row['ip']) . "</td>
           <td>" . htmlspecialchars($row['puerto']) . "</td>
           <td style='color: " . ($estado === 'online' ? 'green' : 'red') . ";'>" . ucfirst($estado) . "</td>
            <td>
              <a href='update.php?id_nodo=" . urlencode($row['id_nodo']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_nodo'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_nodo: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });


  function checkStatus(ip, puerto, button) {
    const statusIndicator = button.nextElementSibling;
    statusIndicator.textContent = "Verificando...";

    $.ajax({
      url: 'check_ip.php',
      type: 'GET',
      data: {
        ip: ip,
        puerto: puerto
      },
      success: function (response) {
        if (response === 'online') {
          statusIndicator.textContent = "Online";
          statusIndicator.style.color = "green";
        } else if (response === 'offline') {
          statusIndicator.textContent = "Offline";
          statusIndicator.style.color = "red";
        } else {
          statusIndicator.textContent = "Error";
          statusIndicator.style.color = "orange";
        }
      },
      error: function () {
        statusIndicator.textContent = "Error de conexión";
        statusIndicator.style.color = "orange";
      }
    });
  }
</script>