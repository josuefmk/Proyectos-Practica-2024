<?php
include 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nombre = $_POST['nombre'];
  $ip = $_POST['ip'];
  $puerto = $_POST['puerto'];

  $stmt = $conn->prepare("INSERT INTO tbl_nodos(nombre, ip, puerto) VALUES (?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssi", $nombre, $ip, $puerto);

  if ($stmt->execute()) {
    echo "Fecha guardada correctamente";
  } else {
    header('Location: index.php?error=1');
  }

  $stmt->close();
  $conn->close();
} else {
  header('Location: index.php');
  exit;
}
?>