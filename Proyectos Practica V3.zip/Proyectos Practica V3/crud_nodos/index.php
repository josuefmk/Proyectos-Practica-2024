<?php
include 'get_feriados.php';

?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Nodo</title>
  <link rel="stylesheet" href="styles.css">
  <script src="Ajax.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Nodo</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Nodo</h2>
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>


      <label for="ip">IP:</label>
      <input type="text" id="ip" name="ip" required placeholder="192.168.1.201">

      <label for="puerto">Puerto:</label>
      <input type="number" id="puerto" name="puerto" required placeholder="80">

      <input type="submit" value="Agregar Operación" class="btn" onclick="showModal()">
      <div id="successModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <p>¡Nodo agregado exitosamente!</p>
        </div>
      </div>

    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar por Nombre</h3>
    <label for="search_nombre">Nombre:</label>
    <input type="text" id="search_nombre" name="search_nombre">



    <input type="submit" class="btn">
    <a href="index.php" class="btn">Quitar Filtro</a>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Feriados</h2>


  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });


  function showModal() {
    document.getElementById('successModal').style.display = 'block';
  }

  function closeModal() {
    document.getElementById('successModal').style.display = 'none';
  }
  window.onclick = function(event) {
    const modal = document.getElementById('successModal');
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  }
  </script>
</body>

</html>