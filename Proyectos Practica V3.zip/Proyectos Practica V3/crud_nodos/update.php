<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Nodo</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  $id = $_GET['id_nodo'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $ip = $conn->real_escape_string($_POST['ip']);
    $puerto = $conn->real_escape_string($_POST['puerto']);

    $sql = "UPDATE tbl_feriados SET nombre='$nombre', ip='$ip', puerto='$puerto' WHERE id_nodo=$id";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_nodos WHERE id_nodo=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Nodo</h1>
    <form method="POST">

      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($row['nombre']); ?>" required>

      <label for="ip">IP:</label>
      <input type="number" id="ip" name="ip" value="<?php echo htmlspecialchars($row['ip']); ?>" required>

      <label for="puerto">Puerto:</label>
      <input type="text" id="sw_repeticion" name="puerto" value="<?php echo htmlspecialchars($row['puerto']); ?>"
        required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>