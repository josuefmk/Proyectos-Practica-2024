<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Nivel</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_nivel'])) {
    $id = $_GET['id_nivel'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $cargo = $conn->real_escape_string($_POST['cargo']);
    $departamento = $conn->real_escape_string($_POST['departamento']);


    $sql = "UPDATE tbl_niveles
        SET cargo='$cargo', departamento='$departamento'
        WHERE id_nivel='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_niveles WHERE id_nivel=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Nivel</h1>
    <form method="POST">
      <label for="cargo">Cargo:</label>
      <input type="text" id="cargo" name="cargo" value="<?php echo htmlspecialchars($row['cargo'] ?? ''); ?>" required>

      <label for="departamento">Departamento:</label>
      <input type="text" id="departamento" name="departamento"
        value="<?php echo htmlspecialchars($row['departamento'] ?? ''); ?>" required>



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>