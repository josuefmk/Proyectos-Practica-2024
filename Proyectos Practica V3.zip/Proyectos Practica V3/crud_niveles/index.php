<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);

$cargosOptions = '';
$departamentoOptions = '';

$result_cargo = $conn->query("SELECT DISTINCT cargo FROM tbl_niveles");
while ($row = $result_cargo->fetch_assoc()) {
  $cargosOptions .= "<option value='{$row['cargo']}'>{$row['cargo']}</option>";
}
$result_depart = $conn->query("SELECT DISTINCT departamento FROM tbl_niveles");
while ($row = $result_depart->fetch_assoc()) {
  $departamentoOptions .= "<option value='{$row['departamento']}'>{$row['departamento']}</option>";
}

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Niveles</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Nivel</h2>

      <label for="cargo">Cargo:</label>
      <select id="cargo" name="cargo" class="form-control" required>
        <option value="">Seleccionar Cargo</option>
        <option value="Super Usuario 2">Super Usuario 2</option>
        <option value="Director">Director</option>
        <option value="Sub Director">Sub Director</option>
        <option value="Administrador">Administrador</option>
        <option value="Secretaria">Secretaria</option>
        <option value="Contador">Contador</option>
        <option value="Operador">Operador</option>
        <option value="Cobranza">Cobranza</option>
        <option value="Docente">Docente</option>
        <option value="Alumno">Alumno</option>
        <option value="Practicante">Practicante</option>
        <option value="Publicidad">Publicidad</option>
        <option value="Coordinador Calidad">Coordinador Calidad</option>

      </select>

      <label for="departamento">Departamento:</label>
      <label for="departamento">Cargo:</label>
      <select id="departamento" name="departamento" class="form-control" required>
        <option value="">Seleccionar Departamento</option>
        <option value="Sin Departamento">Sin Departamento</option>
        <option value="Administración">Administración</option>
        <option value="Contabilidad">Contabilidad</option>
        <option value="Externo">Externo</option>
      </select>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_cargo">Cargo:</label>
    <select id="search_cargo" name="search_cargo">
      <option value="">Seleccione un Cargo</option>
      <?php echo $cargosOptions; ?>
    </select>

    <label for="search_departamento">Departamento:</label>
    <select id="search_departamento" name="search_departamento">
      <option value="">Seleccione un Departamento </option>
      <?php echo $departamentoOptions; ?>
    </select>



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>