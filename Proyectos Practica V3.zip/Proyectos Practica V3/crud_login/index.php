<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD Login Usuario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="Ajax.js"></script>
</head>

<body>
  <h1>Gestión de Login Usuarios</h1>

  <form id="searchForm">
    <h3>Buscar por Nombre de Usuario</h3>
    <label for="search_usuario">Nombre de Usuario:</label>
    <input type="text" id="search_usuario" name="search_usuario">
    <input type="submit" value="Buscar">
  </form>

  <div id="searchResult"></div>


  <button id="toggleFormBtn">Agregar Usuario</button>
  <div class="form-container-add" id="UsuarioFormContainer" style="display: none;">
    <form id="UsuarioForm" method="post" action="create.php">
      <h2>Nuevo Usuario</h2>
      <label for="usuario">Nombre Usuario:</label>
      <input type="text" id="usuario" name="usuario" required>
      <label for="id_usuario">ID Usuario</label>
      <input type="text" id="id_usuario" name="id_usuario" required>
      <label for="id_sesion">ID Sesion</label>
      <input type="text" id="id_sesion" name="id_sesion" required>
      <input type="submit" value="Agregar Usuario" class="submit-btn">
    </form>
  </div>

  <h1>Lista de Usuarios</h1>

  <div id="result">
    <?php include 'read.php'; ?>
  </div>

</body>

</html>