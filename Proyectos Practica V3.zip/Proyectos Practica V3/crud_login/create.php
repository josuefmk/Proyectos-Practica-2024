<?php


include 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['usuario'], $_POST['id_usuario'], $_POST['id_sesion'])) {
    $usuario = $_POST['usuario'];
    $id_usuario = $_POST['id_usuario'];
    $id_sesion = $_POST['id_sesion'];


    $stmt = $conn->prepare("INSERT INTO tbl_login (usuario, id_usuario, id_sesion) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $usuario, $id_usuario, $id_sesion);

    if ($stmt->execute()) {
      echo "Encuesta guardada correctamente";
    } else {
      echo "Error al guardar la encuesta: " . $stmt->error;
    }

    $stmt->close();
  } else {
    echo "Datos incompletos. Por favor, completa todos los campos.";
  }
}

$conn->close();