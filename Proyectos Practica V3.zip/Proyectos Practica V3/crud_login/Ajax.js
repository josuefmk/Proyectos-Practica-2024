document.addEventListener('DOMContentLoaded', function () {

  // Manejar el envío del formulario para agregar un nuevo usuario
  document.getElementById('UsuarioForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('create.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(data => {
      document.getElementById('result').innerHTML = data;
      this.reset();
      loadRecords();
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });

  // Función para cargar y mostrar los registros
  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('result').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }

  loadRecords();

  // Alternar la visibilidad del formulario de usuario
  document.getElementById("toggleFormBtn").addEventListener("click", function () {
    const formContainer = document.getElementById("UsuarioFormContainer");
    formContainer.style.display = (formContainer.style.display === "block") ? "none" : "block";
  });

  // Manejar el envío del formulario de búsqueda
  document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();

    if (validateSearch()) {
      const formData = new FormData(this);
      const queryString = new URLSearchParams(formData).toString();

      fetch('read.php?' + queryString, {
        method: 'GET',
      })
      .then(response => response.text())
      .then(data => {
        document.getElementById('searchResult').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
        document.getElementById('searchResult').innerHTML = '<p class="error">Error al buscar.</p>';
      });
    } else {
      alert('Por favor, ingresa al menos un dato para buscar.');
    }
  });

  // Función de validación simple para el formulario de búsqueda
  function validateSearch() {
    const usuario = document.getElementById('search_usuario').value.trim();
    return usuario.length > 0;
  }

});
