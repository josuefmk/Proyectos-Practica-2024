<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Metodo de pago</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Metodo de pago</h2>


      <label for="nombre">Metodo de Pago:</label>
      <select id="nombre" name="nombre" class="form-control" required>
        <option value=""> Seleccione Opción de pago</option>
        <option value="Transferencia">Transferencia</option>
        <option value="Credito">Credito</option>
        <option value="Debito">Debito</option>
        <option value="Efectivo">Efectivo</option>
      </select>



      <input type="submit" value="Agregar Metodo de pago" class="btn">
    </form>
  </div>




  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>