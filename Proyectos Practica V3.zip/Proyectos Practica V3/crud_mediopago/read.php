<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);




$query = "SELECT * FROM tbl_medio_pago WHERE 1=1";

$types = '';
$params = [];





$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Medio de pago</th>

                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['nombre']) . "</td>

            <td>
              <a href='update.php?id_mediopago=" . urlencode($row['id_mediopago']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_mediopago'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_mediopago: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>