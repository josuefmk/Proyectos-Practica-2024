<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha_atraso = $_POST['nombre'];


  $stmt = $conn->prepare("INSERT INTO tbl_medio_pago( nombre) VALUES (  ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("s", $nombre);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el medio de pago: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>