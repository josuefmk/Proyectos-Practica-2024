<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$cursoOptions = '';

$result_curso = $conn->query("SELECT DISTINCT nombre,id_curso FROM tbl_cursos JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio  GROUP BY id_centroingreso");
while ($row = $result_curso->fetch_assoc()) {
  $cursoOptions .= "<option value='{$row['id_curso']}'>{$row['nombre']}</option>";
}

$relatorOptions = "";
$result_relator = $conn->query("SELECT DISTINCT id_empleado, nombres, paterno, materno FROM tbl_empleados");
while ($row = $result_relator->fetch_assoc()) {
  $relatorOptions .= "<option value='{$row['id_empleado']}'>{$row['nombres']} {$row['paterno']} {$row['materno']}</option>";
}

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Incidencias</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nueva Incidencia</h2>


      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" required>

      <label for="hora">Hora:</label>
      <input type="time" id="hora" name="hora" required>

      <label for="curso">Curso:</label>
      <select id="curso" name="curso">
        <option value="">Seleccione un Curso</option>
        <?php echo $cursoOptions; ?>
      </select>

      <label for="relator">Relator:</label>
      <select id="relator" name="relator">
        <option value="">Seleccione un Nombre</option>
        <?php echo $relatorOptions; ?>
      </select>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion" required>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_fecha">Fecha:</label>
    <input type="date" id="search_fecha" name="search_fecha">



    <label for="search_curso">Curso :</label>
    <select id="search_curso" name="search_curso">
      <option value="">Seleccione un Curso </option>
      <?php echo $cursoOptions; ?>
    </select>

    <label for="search_relator">Relator:</label>
    <select id="search_relator" name="search_relator">
      <option value="">Seleccione un Nombre </option>
      <?php echo $relatorOptions; ?>
    </select>

    <label for="search_descripcion">Descripción:</label>
    <input type="text" id="search_descripcion" name="search_descripcion">

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });
    });
  </script>
</body>