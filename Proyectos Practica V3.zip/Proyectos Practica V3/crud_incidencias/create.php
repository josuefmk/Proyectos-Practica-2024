<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha = $_POST['fecha'];
  $hora = $_POST['hora'];
  $curso = $_POST['curso'];
  $relator = $_POST['relator'];
  $usuario_creador = 0;
  $descripcion = $_POST['descripcion'];

  $stmt = $conn->prepare("INSERT INTO tbl_incidencias( fecha, hora, curso,relator,usuario_creador,descripcion) VALUES ( ?, ?, ?,?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssiiis", $fecha, $hora, $curso, $relator, $usuario_creador, $descripcion);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>