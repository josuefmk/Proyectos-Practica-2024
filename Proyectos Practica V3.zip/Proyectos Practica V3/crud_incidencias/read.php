<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_fecha = isset($_GET['search_fecha']) ? $_GET['search_fecha'] : '';
$search_curso = isset($_GET['search_curso']) ? $_GET['search_curso'] : '';
$search_relator = isset($_GET['search_relator']) ? $_GET['search_relator'] : '';
$search_descripcion = isset($_GET['search_descripcion']) ? $_GET['search_descripcion'] : '';

$query = "SELECT nombre, i.*,e.nombres,e.paterno,e.materno
          FROM tbl_cursos
          JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio
         JOIN   tbl_incidencias i ON  curso=id_curso
         JOIN tbl_empleados e ON id_empleado=i.relator
          GROUP BY id_centroingreso";


$types = '';
$params = [];

if (!empty($search_fecha)) {
  $query .= " AND fecha = ?";
  $types .= 's';
  $params[] = $search_fecha;
}
if (!empty($search_curso)) {
  $query .= " AND 	curso = ?";
  $types .= 's';
  $params[] = $search_curso;
}

if (!empty($search_relator)) {
  $query .= " AND 	relator = ?";
  $types .= 's';
  $params[] = $search_relator;
}
if (!empty($search_descripcion)) {
  $query .= " AND descripcion LIKE ?";
  $params[] = "%" . $search_descripcion . "%";
  $types .= 's';
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Curso</th>
                <th>Relator</th>
                <th>Usuario Creador</th>
                <th>Descripción</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['fecha']) . "</td>
           <td>" . htmlspecialchars($row['hora']) . "</td>
           <td>" . htmlspecialchars($row['nombre']) . "</td>
            <td>" . htmlspecialchars($row['nombres'] . ' ' . $row['paterno'] . ' ' . $row['materno']) . "</td>
             <td>" . htmlspecialchars($row['usuario_creador']) . "</td>
<td>" . htmlspecialchars($row['descripcion']) . "</td>
            <td>
              <a href='update.php?id_incidencia=" . urlencode($row['id_incidencia']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_incidencia'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_incidencia: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });
</script>