
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('addForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('create.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.text())
      .then(data => {
        document.getElementById('result').innerHTML = data;
        this.reset();
        loadRecords();
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });

  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('tableContainer').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }


  loadRecords();


});
  $(document).ready(function() {
    // Limpiar los filtros de búsqueda
    $('#clearFilterBtn').on('click', function() {
        $('#search_codigo_matricula').val('');
        $('#search_id_curso').val('');
      $('#search_fecha').val('');
        $('#search_estado').val('');
        $('#searchForm').submit();
    });
});


