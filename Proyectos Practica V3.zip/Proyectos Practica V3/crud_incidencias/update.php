<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Incidencia</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_incidencia'])) {
    $id = $_GET['id_incidencia'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $fecha = $conn->real_escape_string($_POST['fecha']);
    $hora = $conn->real_escape_string($_POST['hora']);
    $curso = $conn->real_escape_string($_POST['curso']);
    $relator = $conn->real_escape_string($_POST['relator']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);


    $sql = "UPDATE tbl_incidencias
        SET fecha='$fecha', hora='$hora', curso='$curso', relator='$relator',descripcion='$descripcion'
        WHERE id_incidencia='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_incidencias WHERE id_incidencia=$id");
    $row = $result->fetch_assoc();

    $cursoOptions = '';
    $result_curso = $conn->query("SELECT DISTINCT nombre, id_curso FROM tbl_cursos JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio GROUP BY id_centroingreso");
    while ($row_curso = $result_curso->fetch_assoc()) {
      $selected = ($row['curso'] == $row_curso['id_curso']) ? 'selected' : '';
      $cursoOptions .= "<option value='{$row_curso['id_curso']}' {$selected}>{$row_curso['nombre']}</option>";
    }


    $relatorOptions = "";

    $result_relator = $conn->query("SELECT DISTINCT id_empleado, nombres, paterno, materno FROM tbl_empleados");
    while ($row_relator = $result_relator->fetch_assoc()) {
      $selected = ($row['relator'] == $row_relator['id_empleado']) ? 'selected' : '';
      $relatorOptions .= "<option value='{$row_relator['id_empleado']}' {$selected}>{$row_relator['nombres']} {$row_relator['paterno']} {$row_relator['materno']}</option>";
    }


  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Incidencia</h1>
    <form method="POST">
      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($row['fecha'] ?? ''); ?>" required>

      <label for="hora">Hora:</label>
      <input type="time" id="hora" name="hora" value="<?php echo htmlspecialchars($row['hora'] ?? ''); ?>" required>

      <label for="curso">Curso:</label>
      <select id="curso" name="curso">
        <option value="">Seleccione un Curso</option>
        <?php echo $cursoOptions; ?>
      </select>

      <label for="relator">Relator:</label>
      <select id="relator" name="relator">
        <option value="">Seleccione un Nombre</option>
        <?php echo $relatorOptions; ?>
      </select>



      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion"
        value="<?php echo htmlspecialchars($row['descripcion'] ?? ''); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>