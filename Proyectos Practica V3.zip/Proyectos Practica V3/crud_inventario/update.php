<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Cámara IP</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $categoria = $conn->real_escape_string($_POST['categoria']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);



    $sql = "UPDATE tbl_inventario SET  nombre='$nombre',
            categoria='$categoria', descripcion='$descripcion' WHERE id_inventario=$id";


    if ($conn->query($sql)) {
      echo "<p class='success'>Producto actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_inventario WHERE id_inventario=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Cámara IP</h1>
    <form method="POST">
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($row['nombre']); ?>" required>

      <label for="categoria">Categoria:</label>
      <input type="text" id="categoria" name="categoria" value="<?php echo htmlspecialchars($row['categoria']); ?>"
        required>

      <label for="descripcion">Descripcion:</label>
      <input type="text" id="descripcion" name="descripcion"
        value="<?php echo htmlspecialchars($row['descripcion']); ?>" required>


      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>