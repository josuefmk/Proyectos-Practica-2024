<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nombre = $_POST['nombre'];
  $categoria = $_POST['categoria'];
  $descripcion = $_POST['descripcion'];


  $stmt = $conn->prepare("INSERT INTO tbl_inventario (nombre, categoria, descripcion) VALUES (?, ?, ?)");
  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sss", $nombre, $categoria, $descripcion);

  if ($stmt->execute()) {
    echo "Producto guardado correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>