<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_nombre = isset($_GET['search_nombre']) ? $_GET['search_nombre'] : '';
$search_categoria = isset($_GET['search_categoria']) ? $_GET['search_categoria'] : '';

$query = "SELECT id_inventario, nombre, categoria, descripcion FROM tbl_inventario WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_nombre)) {
  $query .= " AND nombre LIKE ?";
  $types .= 's';
  $params[] = "%" . $search_nombre . "%";
}
if (!empty($search_categoria)) {
  $query .= " AND categoria LIKE ?";
  $types .= 's';
  $params[] = "%" . $search_categoria . "%";
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Nombre</th>
                <th>Categoria</th>
                <th>Descripcion</th>
                <th>Opciones</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_inventario']}'>
            <td>" . htmlspecialchars($row['nombre']) . "</td>
            <td>" . htmlspecialchars($row['categoria']) . "</td>
            <td>" . htmlspecialchars($row['descripcion']) . "</td>
            <td>
                <a href='update.php?id=" . urlencode($row['id_inventario']) . "' class='btn btn-sm btn-warning'>Editar</a>
                <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_inventario'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_inventario: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('El registro ha sido eliminado exitosamente.');
          } else {
            alert('Error al eliminar el registro: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }


  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });
</script>