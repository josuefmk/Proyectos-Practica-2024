<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Invtenario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <h1>Gestión de Inventario</h1>

  <button id="toggleAddFormBtn" class="btn">Agregar Producto</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="insert.php">
      <h2>Agregar Nuevo Producto</h2>
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>

      <label for="categoria">Categoria:</label>
      <input type="text" id="categoria" name="categoria" required>

      <label for="descripcion">Descripcion:</label>
      <input type="text" id="descripcion" name="descripcion" required>
      <input type="submit" value="Agregar Producto" class="btn">
    </form>
  </div>

  <form id="searchForm">
    <h3>Buscar Producto</h3>
    <label for="search_nombre">Nombre:</label>
    <input type="text" id="search_nombre" name="search_nombre">

    <label for="search_categoria">Categoria:</label>
    <input type="text" id="search_categoria" name="search_categoria">

    <input type="submit" value="Buscar" class="btn">
    <button type="button" id="clearFilterBtn" class="btn ">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>


  <h2>Lista de Productos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>


  <script>
  $(document).ready(function() {

    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });

  });
  </script>
</body>

</html>