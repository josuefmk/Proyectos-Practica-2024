<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_matricula'])) {
    $id = $_GET['id_matricula'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $time_creacion = $conn->real_escape_string($_POST['time_creacion']);
    $usuario_creacion = $conn->real_escape_string($_POST['usuario_creacion']);
    $id_especialidad = $conn->real_escape_string($_POST['id_especialidad']);
    $id_curso = $conn->real_escape_string($_POST['id_curso']);
    $tipo_plan = $conn->real_escape_string($_POST['tipo_plan']);
    $codigo_matricula = $conn->real_escape_string($_POST['codigo_matricula']);
    $fecha_matricula = $conn->real_escape_string($_POST['fecha_matricula']);
    $time_matricula = $conn->real_escape_string($_POST['time_matricula']);
    $rut_alumno = $conn->real_escape_string($_POST['rut_alumno']);
    $rut_apoderado = $conn->real_escape_string($_POST['rut_apoderado']);
    $nombre_alumno = $conn->real_escape_string($_POST['nombre_alumno']);
    $nombre_apoderado = $conn->real_escape_string($_POST['nombre_apoderado']);
    $valor_curso = $conn->real_escape_string($_POST['valor_curso']);
    $valor_matricula = $conn->real_escape_string($_POST['valor_matricula']);
    $cantidad_letras = $conn->real_escape_string($_POST['cantidad_letras']);
    $cantidad_cuotas = $conn->real_escape_string($_POST['cantidad_cuotas']);
    $id_formapago = $conn->real_escape_string($_POST['id_formapago']);
    $id_empresa_sence = $conn->real_escape_string($_POST['id_empresa_sence']);
    $id_tipocontrato = $conn->real_escape_string($_POST['id_tipocontrato']);
    $id_publicidad = $conn->real_escape_string($_POST['id_publicidad']);
    $id_tipo_alumno = $conn->real_escape_string($_POST['id_tipo_alumno']);
    $password = $conn->real_escape_string($_POST['password']);
    $sesion = $conn->real_escape_string($_POST['sesion']);
    $id_accion = $conn->real_escape_string($_POST['id_accion']);
    $recargo = $conn->real_escape_string($_POST['recargo']);
    $cuota_inicio_recargo = $conn->real_escape_string($_POST['cuota_inicio_recargo']);
    $antiguedad_laboral = $conn->real_escape_string($_POST['antiguedad_laboral']);
    $estudios = $conn->real_escape_string($_POST['estudios']);
    $link_imagen_alumno = $conn->real_escape_string($_POST['link_imagen_alumno']);
    $link_scan_matricula = $conn->real_escape_string($_POST['link_scan_matricula']);
    $switch_imbloqueable = $conn->real_escape_string($_POST['switch_imbloqueable']);
    $sw_cobranza = $conn->real_escape_string($_POST['sw_cobranza']);
    $traido_por = $conn->real_escape_string($_POST['traido_por']);
    $sexo = $conn->real_escape_string($_POST['sexo']);
    $nro_serie = $conn->real_escape_string($_POST['nro_serie']);
    $modalidad = $conn->real_escape_string($_POST['modalidad']);
    $confirma = $conn->real_escape_string($_POST['confirma']);
    $codigo_referido = $conn->real_escape_string($_POST['codigo_referido']);
    $codigo_campagna = $conn->real_escape_string($_POST['codigo_campagna']);
    $codigo_wsp = $conn->real_escape_string($_POST['codigo_wsp']);
    $sql = "UPDATE tbl_matriculas
        SET
            time_creacion = '$time_creacion',
            usuario_creacion = '$usuario_creacion',
            id_especialidad = '$id_especialidad',
            id_curso = '$id_curso',
            tipo_plan = '$tipo_plan',
            codigo_matricula = '$codigo_matricula',
            fecha_matricula = '$fecha_matricula',
            time_matricula = '$time_matricula',
            rut_alumno = '$rut_alumno',
            rut_apoderado = '$rut_apoderado',
            nombre_alumno = '$nombre_alumno',
            nombre_apoderado = '$nombre_apoderado',
            valor_curso = '$valor_curso',
            valor_matricula = '$valor_matricula',
            cantidad_letras = '$cantidad_letras',
            cantidad_cuotas = '$cantidad_cuotas',
            id_formapago = '$id_formapago',
            id_empresa_sence = '$id_empresa_sence',
            id_tipocontrato = '$id_tipocontrato',
            id_publicidad = '$id_publicidad',
            id_tipo_alumno = '$id_tipo_alumno',
            password = '$password',
            sesion = '$sesion',
            id_accion = '$id_accion',
            recargo = '$recargo',
            cuota_inicio_recargo = '$cuota_inicio_recargo',
            antiguedad_laboral = '$antiguedad_laboral',
            estudios = '$estudios',
            link_imagen_alumno = '$link_imagen_alumno',
            link_scan_matricula = '$link_scan_matricula',
            switch_imbloqueable = '$switch_imbloqueable',
            sw_cobranza = '$sw_cobranza',
            traido_por = '$traido_por',
            sexo = '$sexo',
            nro_serie = '$nro_serie',
            modalidad = '$modalidad',
            confirma = '$confirma',
            codigo_referido = '$codigo_referido',
            codigo_campagna = '$codigo_campagna',
            codigo_wsp = '$codigo_wsp'
        WHERE id_matricula = '$id'";
    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_matriculas WHERE id_matricula=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>
  <div class="form-container">
    <h1>Actualizar Centro de Ingreso</h1>
    <form method="POST">
      <label for="time_creacion">Tiempo de Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion"
        value="<?php echo htmlspecialchars($row['time_creacion'] ?? ''); ?>" required>

      <label for="usuario_creacion">Usario Creación:</label>
      <input type="number" id="usuario_creacion" name="usuario_creacion"
        value="<?php echo htmlspecialchars($row['usuario_creacion'] ?? ''); ?>" required>

      <label for="id_especialidad">ID Especialidad:</label>
      <input type="number" id="id_especialidad" name="id_especialidad"
        value="<?php echo htmlspecialchars($row['id_especialidad'] ?? ''); ?>" required>


      <label for="tipo_cliente">Tipo Cliente:</label>
      <input type="number" id="id_especialidad" name="id_especialidad"
        value="<?php echo htmlspecialchars($row['id_especialidad'] ?? ''); ?>" required>



      <label for="id_curso ">ID Curso:</label>
      <input type="number" id="id_curso " name="id_curso "
        value="<?php echo htmlspecialchars($row['id_curso '] ?? ''); ?>" required>


      <label for="tipo_plan">Tipo Plan:</label>
      <input type="number" id="tipo_plan " name="tipo_plan "
        value="<?php echo htmlspecialchars($row['tipo_plan '] ?? ''); ?>" required>

      <label for="codigo_matricula">Codigo Matrícula:</label>
      <input type="number" id="codigo_matricula" name="codigo_matricula"
        value="<?php echo htmlspecialchars($row['codigo_matricula'] ?? ''); ?>" required>

      <label for="fecha_matricula">Fecha Matrícula:</label>
      <input type="date" id="fecha_matricula" name="fecha_matricula"
        value="<?php echo htmlspecialchars($row['fecha_matricula'] ?? ''); ?>" required>


      <label for="time_matricula">Tiempo de Matrícula:</label>
      <input type="number" id="time_matricula" name="time_matricula"
        value="<?php echo htmlspecialchars($row['time_matricula'] ?? ''); ?>" required>

      <label for="rut_alumno">RUT Alumno:</label>
      <input type="text" id="rut_alumno" name="rut_alumno"
        value="<?php echo htmlspecialchars($row['rut_alumno'] ?? ''); ?>">

      <label for="rut_apoderado">RUT Apoderado:</label>
      <input type="text" id="rut_apoderado" name="rut_apoderado"
        value="<?php echo htmlspecialchars($row['rut_apoderado'] ?? ''); ?>">

      <label for="nombre_alumno">Nombre Alumno:</label>
      <input type="text" id="nombre_alumno" name="nombre_alumno"
        value="<?php echo htmlspecialchars($row['nombre_alumno'] ?? ''); ?>">

      <label for="nombre_apoderado">Nombre Apoderado:</label>
      <input type="text" id="nombre_apoderado" name="nombre_apoderado"
        value="<?php echo htmlspecialchars($row['nombre_apoderado'] ?? ''); ?>">

      <label for="valor_curso">Valor Curso:</label>
      <input type="number" id="valor_curso" name="valor_curso"
        value="<?php echo htmlspecialchars($row['valor_curso'] ?? ''); ?>">

      <label for="valor_matricula">Valor de Matrícula:</label>
      <input type="number" id="valor_matricula" name="valor_matricula"
        value="<?php echo htmlspecialchars($row['valor_matricula'] ?? ''); ?>">

      <label for="cantidad_letras">Cantidad Letras:</label>
      <input type="number" id="cantidad_letras" name="cantidad_letras"
        value="<?php echo htmlspecialchars($row['cantidad_letras'] ?? ''); ?>">

      <label for="cantidad_cuotas">Cantidad Cuotas:</label>
      <input type="number" id="cantidad_cuotas" name="cantidad_cuotas"
        value="<?php echo htmlspecialchars($row['cantidad_cuotas'] ?? ''); ?>">

      <label for="id_formapago">ID Forma de Pago:</label>
      <input type="number" id="id_formapago" name="id_formapago"
        value="<?php echo htmlspecialchars($row['id_formapago'] ?? ''); ?>">

      <label for="id_empresa_sence">ID Empresa Sence:</label>
      <input type="number" id="id_empresa_sence" name="id_empresa_sence"
        value="<?php echo htmlspecialchars($row['id_empresa_sence'] ?? ''); ?>">

      <label for="id_tipocontrato">ID Tipo Contrato:</label>
      <input type="text" id="	id_tipocontrato" name="	id_tipocontrato"
        value="<?php echo htmlspecialchars($row['	id_tipocontrato'] ?? ''); ?>">

      <label for="contacto">Contacto:</label>
      <input type="text" id="contacto" name="contacto" value="<?php echo htmlspecialchars($row['contacto'] ?? ''); ?>">

      <label for="tel_contacto">Telefono Contacto:</label>
      <input type="tel" id="tel_contacto" name="tel_contacto"
        value="<?php echo htmlspecialchars($row['tel_contacto'] ?? ''); ?>">

      <label for="id_publicidad">ID Publicidad:</label>
      <input type="text" id="	id_publicidad" name="	id_publicidad"
        value="<?php echo htmlspecialchars($row['	id_publicidad'] ?? ''); ?>">

      <label for="id_tipo_alumno"> ID Tipo Alumno:</label>
      <input type="number" id="id_tipo_alumno" name="id_tipo_alumno"
        value="<?php echo htmlspecialchars($row['id_tipo_alumno'] ?? ''); ?>">

      <label for="password">Password:</label>
      <input type="text" id="password" name="password"
        value="<?php echo htmlspecialchars($row['fono_cobranza'] ?? ''); ?>">

      <label for="sesion">Sesión:</label>
      <input type="text" id="sesion" name="sesion" value="<?php echo htmlspecialchars($row['sesion'] ?? ''); ?>">

      <label for="id_accion">ID Accion:</label>
      <input type="number" id="id_accion" name="id_accion"
        value="<?php echo htmlspecialchars($row['id_accion'] ?? ''); ?>">

      <label for="recargo">Recargo:</label>
      <input type="number" id="recargo" name="recargo" value="<?php echo htmlspecialchars($row['recargo'] ?? ''); ?>">

      <label for="cuota_inicio_recargo" class="cuota_inicio_recargo">Cuota de inicio cargo</label>
      <input type="number" id="cuota_inicio_recargo" name="cuota_inicio_recargo"
        value="<?php echo htmlspecialchars($row['cuota_inicio_recargo'] ?? ''); ?>" required>

      <label for="antiguedad_laboral">Antiguedad Laboral:</label>
      <input type="number" id="antiguedad_laboral" name="antiguedad_laboral"
        value="<?php echo htmlspecialchars($row['antiguedad_laboral'] ?? ''); ?>">

      <label for="estudios">Estudios:</label>
      <input type="text" id="estudios" name="estudios" value="<?php echo htmlspecialchars($row['estudios'] ?? ''); ?>">

      <label for="link_imagen_alumno">Link Imagen Alumno:</label>
      <input type="text" id="link_imagen_alumno" name="link_imagen_alumno"
        value="<?php echo htmlspecialchars($row['link_imagen_alumno	'] ?? ''); ?>">

      <label for="link_scan_matricula">Link Scan Matrícula:</label>
      <input type="text" id="link_scan_matricula" name="link_scan_matricula"
        value="<?php echo htmlspecialchars($row['link_scan_matricula'] ?? ''); ?>">

      <label for="switch_imbloqueable">Switch Imbloqueable:</label>
      <input type="number" id="switch_imbloqueable" name="switch_imbloqueable"
        value="<?php echo htmlspecialchars($row['switch_imbloqueable'] ?? ''); ?>">

      <label for="sw_cobranza">SW Cobranza:</label>
      <input type="number" id="sw_cobranza" name="sw_cobranza"
        value="<?php echo htmlspecialchars($row['sw_cobranza'] ?? ''); ?>">

      <label for="traido_por">Traido Por:</label>
      <input type="text" id="traido_por" name="traido_por"
        value="<?php echo htmlspecialchars($row['traido_por'] ?? ''); ?>">

      <label for="sexo">Sexo:</label>
      <input type="text" id="sexo" name="sexo" value="<?php echo htmlspecialchars($row['sexo'] ?? ''); ?>">

      <label for="nro_serie">Nro Serie:</label>
      <input type="number" id="nro_serie" name="nro_serie"
        value="<?php echo htmlspecialchars($row['nro_serie'] ?? ''); ?>">

      <label for="modalidad">Modalidad:</label>
      <input type="number" id="modalidad" name="modalidad"
        value="<?php echo htmlspecialchars($row['modalidad'] ?? ''); ?>">

      <label for="confirma">Confirma:</label>
      <input type="number" id="confirma" name="confirma"
        value="<?php echo htmlspecialchars($row['confirma'] ?? ''); ?>">

      <label for="codigo_referido">Codigo Referido:</label>
      <input type="text" id="codigo_referido" name="codigo_referido"
        value="<?php echo htmlspecialchars($row['codigo_referido'] ?? ''); ?>">

      <label for="codigo_campagna">Codigo Campagna:</label>
      <input type="text" id="codigo_campagna" name="codigo_campagna"
        value="<?php echo htmlspecialchars($row['codigo_campagna'] ?? ''); ?>">

      <label for="codigo_wsp">Codigo WhatsApp:</label>
      <input type="text" id="codigo_wsp" name="codigo_wsp"
        value="<?php echo htmlspecialchars($row['codigo_wsp'] ?? ''); ?>">

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>


  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>