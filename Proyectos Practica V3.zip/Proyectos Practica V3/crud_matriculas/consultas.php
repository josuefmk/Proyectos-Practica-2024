<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$search_id_especialidad = isset($_GET['search_id_especialidad']) ? $_GET['search_id_especialidad'] : '';
$search_id_curso = isset($_GET['search_id_curso']) ? $_GET['search_id_curso'] : '';

$centroOptions = "<option value=''>Seleccione Especialidad</option>";
$cursoOptions = "<option value=''>Seleccione Curso</option>";

$centrosQuery = "SELECT id_centroingreso, nombre FROM tbl_centrosdeingreso";
$centrosResult = mysqli_query($conn, $centrosQuery);

if ($centrosResult) {
    while ($row = mysqli_fetch_assoc($centrosResult)) {

        $centroOptions .= "<option value='" . htmlspecialchars($row['id_centroingreso']) . "'>" . htmlspecialchars($row['nombre']) . "</option>";
    }
} else {

    echo "Error al cargar centros: " . mysqli_error($conn);
}

$query = "
    SELECT
      id_curso,
        fecha_inicio,
        hora_desde,
        hora_hasta,
        id_centroingreso,
        nombre
    FROM
        tbl_cursos
    JOIN
        tbl_centrosdeingreso
    WHERE
        id_centronegocio = id_centroingreso
        ";







$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$resultados = array();
while ($row = mysqli_fetch_assoc($result)) {
    $resultados[] = $row;
}


mysqli_close($conn);
?>