<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$search_nombre_alumno = isset($_GET['search_nombre_alumno']) ? $_GET['search_nombre_alumno'] : '';
$search_rut_alumno = isset($_GET['search_rut_alumno']) ? $_GET['search_rut_alumno'] : '';
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';

$query = "SELECT * FROM tbl_matriculas WHERE 1=1";
$params = [];
$types = '';


if (!empty($search_nombre_alumno)) {
  $query .= " AND nombre_alumno LIKE ?";
  $params[] = "%" . $search_nombre_alumno . "%";
  $types .= 's';
}
if (!empty($search_rut_alumno)) {
  $query .= " AND rut_alumno LIKE ?";
  $params[] = "%" . $search_rut_alumno . "%";
  $types .= 's';
}
if (!empty($search_codigo_matricula)) {
  $query .= " AND codigo_matricula LIKE ?";
  $params[] = "%" . $search_codigo_matricula . "%";
  $types .= 's';
}

if (!empty($search_id_curso )) {
  $query .= " AND id_curso  = ?";
  $params[] = "$search_id_curso";
  $types .= 's';
}


if (!empty($search_id_especialidad )) {
  $query .= " AND id_especialidad  = ?";
  $params[] = "$search_id_especialidad";
  $types .= 's';
}




$stmt = $conn->prepare($query);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}
$tipo_contrato = [
  '1' => 'Plan A: Con rebaja especial',
  '2' => 'Plan B: Contrato anual con letras',
  '3' => 'Plan C: Plan libre',
  '4' => 'Plan D: Pago efectivo dcto'
];

$tipo_alumno = [
  '1' => 'Particular',
  '2' => 'Aval',
  '3' => 'Sence OTIC',
  '4' => 'Beca',
  '5' => 'Empresa NO Sence',
  '6' => 'Sence OTEC',
];

$modalidad = [
  '0' => 'Presencial',
  '1' => 'SemiPresencial',
  '2' => 'Virtual',
];
if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

function safe_htmlspecialchars($value)
{
  return htmlspecialchars($value ?? '');
}

if ($result->num_rows > 0) {
  echo '<div class="carta-container">';
  while ($row = $result->fetch_assoc()) {
    # Cambio de INT a Palabra "TIPO CONTRATO"
    $tipo_contrato_view = [];
    $tipo_con = str_split($row['id_tipocontrato']);
    foreach ($tipo_con as $nom) {
      $tip_cli = (int) $nom;
      if (isset($tipo_contrato[$tip_cli])) {
        $tipo_contrato_view[] = $tipo_contrato[$tip_cli];
      }
    }
    $nombre_tipo_contrato_texto = implode(', ', $tipo_contrato_view);

    # Cambio de INT a palabra "TIPO ALUMNO"
    $tipo_alumno_view = [];
    $tipo_alum = str_split($row['id_tipo_alumno']);
    foreach ($tipo_alum as $nom) {
      $tip_alum = (int) $nom;
      if (isset($tipo_alumno[$tip_alum])) {
        $tipo_alumno_view[] = $tipo_alumno[$tip_alum];
      }
    }
    $nombre_tipo_alumno_texto = implode(', ', $tipo_alumno_view);



    #Cambio de INT a palabram "MODALIDAD"
    $tipo_modalidad_view = [];
    $tipo_moda = isset($row['modalidad']) ? str_split($row['modalidad']) : [];

    if (empty($tipo_moda)) {
      $tipo_modalidad_view[] = $modalidad['0'];
    } else {
      foreach ($tipo_moda as $nom) {
        $moda = (int) $nom;
        if (isset($modalidad[$moda])) {
          $tipo_modalidad_view[] = $modalidad[$moda];
        }
      }
    }
    $nombre_tipo_modalidad_texto = implode(', ', $tipo_modalidad_view);

    echo '<div class="carta">';
    echo '<div class="carta-header">';
    echo '<h3>Nombre Alumno: ' . safe_htmlspecialchars($row['nombre_alumno']) . '</h3>';
    echo '</div>';
    echo '<div class="carta-body">';
    echo '<p><strong>Tiempo de Creación:</strong> ' . safe_htmlspecialchars($row['time_creacion']) . '</p>';
    echo '<p><strong>Usuario Creación:</strong> ' . safe_htmlspecialchars($row['usuario_creacion']) . '</p>';
    echo '<p><strong>ID Especialidad:</strong> ' . safe_htmlspecialchars($row['id_especialidad']) . '</p>';
    echo '<p><strong>ID Curso:</strong> ' . safe_htmlspecialchars($row['id_curso']) . '</p>';
    echo '<p><strong>Tipo Plan:</strong> ' . safe_htmlspecialchars($row['tipo_plan']) . '</p>';
    echo '<p><strong>Codigo Matrícula:</strong> ' . safe_htmlspecialchars($row['codigo_matricula']) . '</p>';
    echo '<p><strong>Fecha Matrícula:</strong> ' . safe_htmlspecialchars($row['fecha_matricula']) . '</p>';
    echo '<p><strong>Tiempo Matrícula:</strong> ' . safe_htmlspecialchars($row['time_matricula']) . '</p>';
    echo '<p><strong>RUT Alumna:</strong> ' . safe_htmlspecialchars($row['rut_alumno']) . '</p>';
    echo '<p><strong>RUT Apoderado:</strong> ' . safe_htmlspecialchars($row['rut_apoderado']) . '</p>';
    echo '<p><strong>Nombre Alumno:</strong> ' . safe_htmlspecialchars($row['nombre_alumno']) . '</p>';
    echo '<p><strong>Nombre Apoderado:</strong> ' . safe_htmlspecialchars($row['nombre_apoderado']) . '</p>';
    echo '<p><strong>Valor Curso:</strong> ' . safe_htmlspecialchars($row['valor_curso']) . '</p>';
    echo '<p><strong>Valor Matrícula:</strong> ' . safe_htmlspecialchars($row['valor_matricula']) . '</p>';
    echo '<p><strong>Cantidad Letras:</strong> ' . safe_htmlspecialchars($row['cantidad_letras']) . '</p>';
    echo '<p><strong>Cantidad Cuotas:</strong> ' . safe_htmlspecialchars($row['cantidad_cuotas']) . '</p>';
    echo '<p><strong>ID de Forma Pago:</strong> ' . safe_htmlspecialchars($row['id_formapago']) . '</p>';
    echo '<p><strong>ID Empresa Sence:</strong> ' . safe_htmlspecialchars($row['id_empresa_sence']) . '</p>';
    echo '<p><strong>Tipo Contrato:</strong> ' . safe_htmlspecialchars($nombre_tipo_contrato_texto) . '</p>';
    echo '<p><strong>ID Publicidad:</strong> ' . safe_htmlspecialchars($row['id_publicidad']) . '</p>';
    echo '<p><strong>Tipo Alumno:</strong> ' . safe_htmlspecialchars($nombre_tipo_alumno_texto) . '</p>';
    echo '<p><strong>Password:</strong> ' . safe_htmlspecialchars($row['password']) . '</p>';
    echo '<p><strong>Sesión:</strong> ' . safe_htmlspecialchars($row['sesion']) . '</p>';
    echo '<p><strong>ID Acción:</strong> ' . safe_htmlspecialchars($row['id_accion']) . '</p>';
    echo '<p><strong>Recargo:</strong> ' . safe_htmlspecialchars($row['recargo']) . '</p>';
    echo '<p><strong>Cuota Inicio Recargo:</strong> ' . safe_htmlspecialchars($row['cuota_inicio_recargo']) . '</p>';
    echo '<p><strong>Antiguedad Laboral:</strong> ' . safe_htmlspecialchars($row['antiguedad_laboral']) . '</p>';
    echo '<p><strong>Estudios:</strong> ' . safe_htmlspecialchars($row['estudios']) . '</p>';
    echo '<p><strong>Link Imagen Alumno:</strong> ' . safe_htmlspecialchars($row['link_imagen_alumno']) . '</p>';
    echo '<p><strong>Link Scan Matricula:</strong> ' . safe_htmlspecialchars($row['link_scan_matricula']) . '</p>';
    echo '<p><strong>Switch Imbloqueable:</strong> ' . safe_htmlspecialchars($row['switch_imbloqueable']) . '</p>';
    echo '<p><strong>SW Cobranza:</strong> ' . safe_htmlspecialchars($row['sw_cobranza']) . '</p>';
    echo '<p><strong>Traido Por:</strong> ' . safe_htmlspecialchars($row['traido_por']) . '</p>';
    echo '<p><strong>Sexo:</strong> ' . safe_htmlspecialchars($row['sexo']) . '</p>';
    echo '<p><strong>Número de Serie:</strong> ' . safe_htmlspecialchars($row['nro_serie']) . '</p>';
    echo '<p><strong>Modalidad:</strong> ' . safe_htmlspecialchars($nombre_tipo_modalidad_texto) . '</p>';
    echo '<p><strong>Confirma:</strong> ' . safe_htmlspecialchars($row['confirma']) . '</p>';
    echo '<p><strong>Código Referido:</strong> ' . safe_htmlspecialchars($row['codigo_referido']) . '</p>';
    echo '<p><strong>Código Campagna:</strong> ' . safe_htmlspecialchars($row['codigo_campagna']) . '</p>';
    echo '<p><strong>Código WhatsApp:</strong> ' . safe_htmlspecialchars($row['codigo_wsp']) . '</p>';
    echo '<div class="acciones">';
    echo '<a href="update.php?id_matricula=' . safe_htmlspecialchars($row['id_matricula']) . '" class="btn btn-sm btn-warning">Editar</a>';
    echo '<a href="javascript:void(0);" onclick="confirmDelete(' . safe_htmlspecialchars($row['id_matricula']) . ');" class="btn btn-sm btn-danger">Eliminar</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
  }
  echo '</div>';
} else {
  echo "<p>No se encontraron resultados.</p>";
}


$stmt->close();
$conn->close();
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_matricula: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('.carta').filter(function() {
            return $(this).find('a[href*="' + id + '"]').length > 0;
          }).fadeOut(500, function() {
            $(this).remove();
          });
        } else {
          alert('Error al eliminar el registro: ' + response);
        }
      }
    });
  }
}
</script>
