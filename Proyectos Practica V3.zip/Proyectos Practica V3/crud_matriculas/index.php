<?php
include 'conexion.php';
require 'consultas.php';

?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Matrícula</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Matrícula</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
       <input type='hidden' name='accion' value='nessuno'>     
      <h2>Agregar Nueva Matrícula</h2>
      <label for="time_creacion">Tiempo Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion" required>

      <label for="usuario_creacion">Usuario Creación:</label>
      <input type="number" id="usuario_creacion" name="usuario_creacion" required>

      <label for="id_especialidad">Nombre de Especialidad</label>
      <select id="especialidadSelect" name="id_especialidad" Onchange="this.form.submit();">
        <option value=''>Seleccione una Especialidad</option>
        <?php

        $previo_value = '';
        foreach ($resultados as $rsl) {
          if ($rsl['id_centroingreso'] != $previo_value) {
            echo "<option value='" . $rsl['id_centroingreso'] . "' ";
            if ($search_id_especialidad == $rsl['id_centroingreso']) {
              echo " selected='selected' ";
            }
            echo ">" . $rsl['nombre'] . "</option>";
            $previo_value = $rsl['id_centroingreso'];
          }
        }
        ?>
      </select>

      <label for="id_curso">Curso:</label>
      <select id="cursoSelect" name="id_curso">
        <option value=''>Seleccione un Curso</option>
        <?php
        if (!empty($search_id_especialidad)) {
          foreach ($resultados as $rsl) {
            if ($search_id_especialidad == $rsl['id_centroingreso']) {
              echo "<option value='" . $rsl['id_curso'] . "' ";
              if ($search_id_curso == $rsl['id_curso']) {
                echo " selected='selected' ";
              }
              echo ">" . $rsl['nombre'] . " " . $rsl['fecha_inicio'] . " " . $rsl['hora_desde'] . "-" . $rsl['hora_hasta'] . "</option>";
            }
          }
        }
        ?>
      </select>

      <label for="tipo_plan">Tipo Plan:</label>
      <select id="tipo_plan" name="tipo_plan" class="form-control" required>
        <option value=""> Seleccionar un Plan</option>
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="C">C</option>
        <option value="D">D</option>
      </select>

      <label for="codigo_matricula">Codigo Matrícula:</label>
      <input type="text" id="codigo_matricula" name="codigo_matricula" required>

      <label for="time_matricula">Tiempo Creación Matrícula:</label>
      <input type="number" id="time_matricula" name="time_matricula" required>

      <label for="rut_alumno">RUT Alumno:</label>
      <input type="text" id="rut_alumno" name="rut_alumno" required>

      <label for="rut_apoderado">RUT Apoderado:</label>
      <input type="text" id="rut_apoderado" name="rut_apoderado" required>

      <label for="nombre_alumno">Nombre Alumno:</label>
      <input type="text" id="nombre_alumno" name="nombre_alumno" required>

      <label for="nombre_apoderado">Nombre Apoderado:</label>
      <input type="text" id="nombre_apoderado" name="nombre_apoderado" required>

      <label for="valor_curso">Valor Curso:</label>
      <input type="number" id="valor_curso" name="valor_curso" required>

      <label for="valor_matricula">Valor Matrícula:</label>
      <input type="number" id="valor_matricula" name="valor_matricula" required>

      <label for="cantidad_letras">Cantidad Letras:</label>
      <input type="number" id="cantidad_letras" name="cantidad_letras" required>

      <label for="cantidad_cuotas">Cantidad Cuotas:</label>
      <input type="number" id="cantidad_cuotas" name="cantidad_cuotas" required>

      <label for="id_formapago">ID Forma de Pago:</label>
      <input type="number" id="id_formapago" name="id_formapago" required>

      <label for="id_empresa_sence">ID de Empresa Sence:</label>
      <input type="number" id="id_empresa_sence" name="id_empresa_sence" required>

      <label for="id_tipocontrato">ID Tipo de contrato</label>
      <select id="id_tipocontrato" name="id_tipocontrato" class="form-control" required>
        <option value=""> Seleccionar un Tipo De Contrato</option>
        <option value="1">Plan A: Con rebaja especial</option>
        <option value="2">Plan B: Contrato anual con letras</option>
        <option value="3">Plan C: Plan libre</option>
        <option value="4">Plan D: Pago efectivo dcto</option>
      </select>

      <label for="id_publicidad">ID Publicidad:</label>
      <input type="text" id="id_publicidad" name="id_publicidad" required>

      <label for="id_tipo_alumno">ID Tipo Alumno</label>
      <select id="id_tipo_alumno" name="id_tipo_alumno" class="form-control" required>
        <option value=""> Seleccionar un Tipo de Alumno</option>
        <option value="1">Particular</option>
        <option value="2">Aval</option>
        <option value="3">Sence OTIC</option>
        <option value="4">Beca</option>
        <option value="5">Empresa - NO Sence</option>
        <option value="6">Senece OTEC</option>
      </select>

      <label for="password">Contraseña:</label>
      <input type="password" id="password" name="password" required>

      <label for="sesion">Sesión:</label>
      <input type="text" id="sesion" name="sesion" required>

      <label for="id_sesion">ID Sesión:</label>
      <input type="number" id="id_sesion" name="id_sesion" required>

      <label for="recargo">Recargo:</label>
      <input type="text" id="recargo" name="recargo" required>

      <label for="cuota_inicio_recargo">Cuota De Incio Recargo:</label>
      <input type="number" id="cuota_inicio_recargo" name="cuota_inicio_recargo" required>

      <label for="antiguedad_laboral">Antiguedad Laboral:</label>
      <input type="number" id="antiguedad_laboral" name="antiguedad_laboral" required>

      <label for="estudios">Estudios:</label>
      <input type="text" id="estudios" name="estudios" required>

      <label for="link_imagen_alumno">Link Imagen Alumno:</label>
      <input type="text" id="link_imagen_alumno" name="link_imagen_alumno" required>

      <label for="link_scan_matricula">Link Scan Matrícula:</label>
      <input type="text" id="link_scan_matricula" name="link_scan_matricula" required>

      <label for="switch_imbloqueable">Switch Imbloqueable:</label>
      <input type="number" id="switch_imbloqueable" name="switch_imbloqueable" required>

      <label for="sw_cobranza">SW Cobranza:</label>
      <input type="number" id="sw_cobranza" name="sw_cobranza" required>

      <label for="traido_por">Traido Por:</label>
      <input type="text" id="traido_por" name="traido_por" required>

      <label for="sexo">Sexo:</label>
      <input type="text" id="sexo" name="sexo" required>

      <label for="nro_serie">Numero de Serie:</label>
      <input type="number" id="nro_serie" name="nro_serie" required>

      <label for="modalidad">Modalidad:</label>
      <select id="modalidad" name="modalidad" class="form-control" required>
        <option value=""> Seleccionar una modalidad</option>
        <option value="0">Presencial</option>
        <option value="1">SemiPresencial</option>
        <option value="2">Virtual</option>
      </select>

      <label for="confirma">Confirma:</label>
      <input type="number" id="confirma" name="confirma" required>

      <label for="codigo_referido">Codigo Referido:</label>
      <input type="text" id="codigo_referido" name="codigo_referido" required>

      <label for="codigo_campagna">Codigo Campagna:</label>
      <input type="text" id="codigo_campagna" name="codigo_campagna" required>

      <label for="codigo_wsp">Codigo WhatsApp:</label>
      <input type="text" id="codigo_wsp" name="codigo_wsp" required>

      <!--<input type="submit" name="accion" value="Agregar Matrícula" class="btn">-->
      
      <button name='accion' value="Agregar Matrícula" class="btn">AGREGAR</button>
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Horario</h3>
    <label for="search_id_especialidad">Nombre de Especialidad</label>
    <select id="especialidadSelect" name="search_id_especialidad" Onchange="this.form.submit();">
      <option value=''>Seleccione una Especialidad</option>
      <?php

      $previo_value = '';
      foreach ($resultados as $rsl) {
        if ($rsl['id_centroingreso'] != $previo_value) {
          echo "<option value='" . $rsl['id_centroingreso'] . "' ";
          if ($search_id_especialidad == $rsl['id_centroingreso']) {
            echo " selected='selected' ";
          }
          echo ">" . $rsl['nombre'] . "</option>";
          $previo_value = $rsl['id_centroingreso'];
        }
      }
      ?>
    </select>

    <label for="search_id_curso">Curso:</label>
    <select id="cursoSelect" name="search_id_curso" Onchange="this.form.submit();">
      <option value=''>Seleccione un Curso</option>
      <?php
      if (!empty($search_id_especialidad)) {
        foreach ($resultados as $rsl) {
          if ($search_id_especialidad == $rsl['id_centroingreso']) {
            echo "<option value='" . $rsl['id_curso'] . "' ";
            if ($search_id_curso == $rsl['id_curso']) {
              echo " selected='selected' ";
            }
            echo ">" . $rsl['nombre'] . " " . $rsl['fecha_inicio'] . " " . $rsl['hora_desde'] . "-" . $rsl['hora_hasta'] . "</option>";
          }
        }
      }
      ?>
    </select>

    <label for="search_nombre_alumno">Nombre Alumno:</label>
    <input type="text" id="search_nombre_alumno" name="search_nombre_alumno">

    <label for="search_rut_alumno">RUT Alumno:</label>
    <input type="text" id="search_rut_alumno" name="search_rut_alumno">

    <label for="search_codigo_matricula">Codigo Matrícula:</label>
    <input type="number" id="search_codigo_matricula" name="search_codigo_matricula">

    <input type="submit" value="Buscar" class="btn">

  </form>
  <a href='index.php'>LIMPIAR FILTROS</a>

  <div id="searchResult"></div>
  <h2>Lista de Matriculas</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>
  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
    });
  });
  document.getElementById('especialidadSelect').addEventListener('change', function() {
    const selectedEspecialidad = this.value;

  });
  </script>

</body>
