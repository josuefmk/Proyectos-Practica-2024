<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

#var_dump($_POST);


$time_creacion = uniqid('', true) . bin2hex(random_bytes(10));
$time_creacion = substr($time_creacion, 0, 24);
echo $time_creacion;

if ($_POST['accion'] == 'Agregar Matrícula') {
  $time_creacion = $_POST['time_creacion'] ?? null;
  $usuario_creacion = $_POST['usuario_creacion'] ?? null;
  $id_especialidad = $_POST['id_especialidad'];
  $id_curso = $_POST['id_curso'];
  $tipo_plan = $_POST['tipo_plan'] ?? null;
  $codigo_matricula = $_POST['codigo_matricula'] ?? null;
  $fecha_matricula = $_POST['fecha_matricula'] ?? date("Y-m-d");
  $time_matricula = $_POST['time_matricula'] ?? null;
  $rut_alumno = $_POST['rut_alumno'] ?? null;
  $rut_apoderado = $_POST['rut_apoderado'] ?? null;
  $nombre_alumno = $_POST['nombre_alumno'] ?? null;
  $nombre_apoderado = $_POST['nombre_apoderado'] ?? null;
  $valor_curso = $_POST['valor_curso'] ?? 0;
  $valor_matricula = $_POST['valor_matricula'] ?? 0;
  $cantidad_letras = $_POST['cantidad_letras'] ?? null;
  $cantidad_cuotas = $_POST['cantidad_cuotas'] ?? 1;
  $id_formapago = $_POST['id_formapago'] ?? null;
  $id_empresa_sence = $_POST['id_empresa_sence'] ?? null;
  $id_tipocontrato = $_POST['id_tipocontrato'] ?? null;
  $id_publicidad = $_POST['id_publicidad'] ?? null;
  $id_tipo_alumno = $_POST['id_tipo_alumno'] ?? null;
  $password = $_POST['password'] ?? null;
  $sesion = $_POST['sesion'] ?? null;
  $id_accion = $_POST['id_accion'] ?? 0;
  $recargo = $_POST['recargo'] ?? 0;
  $cuota_inicio_recargo = $_POST['cuota_inicio_recargo'] ?? 0;
  $antiguedad_laboral = $_POST['antiguedad_laboral'] ?? null;
  $estudios = $_POST['estudios'] ?? null;
  $link_imagen_alumno = $_POST['link_imagen_alumno'] ?? null;
  $link_scan_matricula = $_POST['link_scan_matricula'] ?? null;
  $switch_imbloqueable = $_POST['switch_imbloqueable'] ?? null;
  $sw_cobranza = $_POST['sw_cobranza'] ?? null;
  $traido_por = $_POST['traido_por'] ?? null;
  $sexo = $_POST['sexo'] ?? null;
  $nro_serie = $_POST['nro_serie'] ?? null;
  $modalidad = $_POST['modalidad'] ?? null;
  $confirma = $_POST['confirma'] ?? null;
  $codigo_referido = $_POST['codigo_referido'] ?? null;
  $codigo_campagna = $_POST['codigo_campagna'] ?? null;
  $codigo_wsp = $_POST['codigo_wsp'] ?? null;





  $stmt = $conn->prepare("INSERT INTO tbl_matriculas
    (time_creacion, usuario_creacion, id_especialidad, id_curso, tipo_plan, codigo_matricula, fecha_matricula,
    time_matricula, rut_alumno, rut_apoderado, nombre_alumno, nombre_apoderado, valor_curso, valor_matricula,
    cantidad_letras, cantidad_cuotas, id_formapago, id_empresa_sence, id_tipocontrato, id_publicidad,
    id_tipo_alumno, password, sesion, id_accion, recargo, cuota_inicio_recargo, antiguedad_laboral,
    estudios, link_imagen_alumno, link_scan_matricula, switch_imbloqueable, sw_cobranza, traido_por,
    sexo, nro_serie, modalidad, confirma, codigo_referido, codigo_campagna, codigo_wsp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  $stmt->bind_param(
    "iiiiississssiiiiiiiiissiiiisssiissiiisss",

    $time_creacion,
    $usuario_creacion,
    $id_especialidad,
    $id_curso,
    $tipo_plan,
    $codigo_matricula,
    $fecha_matricula,
    $time_matricula,
    $rut_alumno,
    $rut_apoderado,
    $nombre_alumno,
    $nombre_apoderado,
    $valor_curso,
    $valor_matricula,
    $cantidad_letras,
    $cantidad_cuotas,
    $id_formapago,
    $id_empresa_sence,
    $id_tipocontrato,
    $id_publicidad,
    $id_tipo_alumno,
    $password,
    $sesion,
    $id_accion,
    $recargo,
    $cuota_inicio_recargo,
    $antiguedad_laboral,
    $estudios,
    $link_imagen_alumno,
    $link_scan_matricula,
    $switch_imbloqueable,
    $sw_cobranza,
    $traido_por,
    $sexo,
    $nro_serie,
    $modalidad,
    $confirma,
    $codigo_referido,
    $codigo_campagna,
    $codigo_wsp
  );

  if ($stmt->execute()) {
    header('Location: index.php');
    exit;
  } else {
    header('Location: index.php?error=1');
    exit;
  }

  $stmt->close();
  $conn->close();
} else {
  header('Location: index.php');
  exit;
}
?>