<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id_matricula = isset($_POST['id_matricula']) ? $_POST['id_matricula'] : '';

  if (!empty($id_matricula)) {
    $stmt = $conn->prepare("DELETE FROM tbl_matriculas WHERE id_matricula = ?");
    if ($stmt === false) {
      die("Error en la preparación de la consulta: " . $conn->error);
    }

    $stmt->bind_param('s', $id_matricula);
    if ($stmt->execute()) {
      echo 'success';
    } else {
      echo 'Error: ' . $conn->error;
    }

    $stmt->close();
  } else {
    echo 'ID de empresa no válido.';
  }
}

$conn->close();
?>