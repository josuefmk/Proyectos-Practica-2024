<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_inventario = $conn->real_escape_string($_POST['id_inventario']);
    $operacion = $conn->real_escape_string($_POST['operacion']);
    $fecha_operacion = $conn->real_escape_string($_POST['fecha_operacion']);
    $comentarios = $conn->real_escape_string($_POST['comentarios']);
    $id_usuario = $conn->real_escape_string($_POST['id_usuario']);


    $sql = "UPDATE tbl_operacion_inventario SET  id_inventario='$id_inventario',
            operacion='$operacion', fecha_operacion='$fecha_operacion',comentarios='$comentarios',id_usuario='$id_usuario' WHERE id_operacion=$id";


    if ($conn->query($sql)) {
      echo "<p class='success'>Producto actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_operacion_inventario WHERE id_operacion=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Operación</h1>
    <form method="POST">
      <label for="id_inventario">Nombre:</label>
      <input type="number" id="id_inventario" name="id_inventario"
        value="<?php echo htmlspecialchars($row['id_inventario']); ?>" required>
      <label for="operacion">Operación:</label>
      <select id="operacion" name="operacion" class="form-control" required>
        value="<?php echo htmlspecialchars($row['operacion']); ?>
        <option value="0">Ingreso</option>
        <option value="1">Egreso</option>
      </select>

      <label for="fecha_operacion">Fecha Creación:</label>
      <input type="date" id="fecha_operacion" name="fecha_operacion"
        value="<?php echo htmlspecialchars($row['fecha_operacion']); ?>" required>

      <label for="comentarios">Comentario:</label>
      <input type="text" id="comentarios" name="comentarios"
        value="<?php echo htmlspecialchars($row['comentarios']); ?>" required>

      <label for="id_usuario">ID Usuario:</label>
      <input type="number" id="id_usuario" name="id_usuario" value="<?php echo htmlspecialchars($row['id_usuario']); ?>"
        required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>