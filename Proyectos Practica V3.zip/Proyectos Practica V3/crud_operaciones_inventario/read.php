<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inicializar variables de búsqueda
$search_id_inventario = isset($_GET['search_id_inventario']) ? trim($_GET['search_id_inventario']) : '';
$search_nombre = isset($_GET['search_nombre']) ? trim($_GET['search_nombre']) : '';
$search_operacion = isset($_GET['search_operacion']) ? trim($_GET['search_operacion']) : '';
$search_id_usuario = isset($_GET['search_id_usuario']) ? trim($_GET['search_id_usuario']) : '';
$search_comentarios = isset($_GET['search_comentarios']) ? trim($_GET['search_comentarios']) : '';

$query = "SELECT op.id_operacion, op.id_inventario, op.operacion, op.fecha_operacion, op.comentarios, op.id_usuario, inv.nombre
          FROM tbl_operacion_inventario op
          LEFT JOIN tbl_inventario inv ON op.id_inventario = inv.id_inventario
          WHERE 1=1";

$types = '';
$params = [];

// Filtros de búsqueda
if (!empty($search_id_inventario)) {
  $query .= " AND op.id_inventario = ?";
  $types .= 'i';
  $params[] = $search_id_inventario;
}

if (!empty($search_nombre)) {
  $query .= " AND op.id_inventario = ?";
  $types .= 'i';
  $params[] = $search_nombre;
}

if (!empty($search_operacion)) {
  $query .= " AND op.operacion LIKE ?";
  $types .= 's';
  $params[] = "%" . $search_operacion . "%";
}

if (!empty($search_id_usuario)) {
  $query .= " AND op.id_usuario = ?";
  $types .= 'i';
  $params[] = $search_id_usuario;
}

if (!empty($search_comentarios)) {
  $query .= " AND op.comentarios LIKE ?";
  $types .= 's';
  $params[] = "%" . $search_comentarios . "%";
}

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$stock_total = 0;
$no_stock = false; // Verificar si hay stock

if ($result->num_rows > 0) {
  // Verifica el stock total
  while ($row = $result->fetch_assoc()) {
    $operacion = (int) $row['operacion'];

    if ($operacion === 0) {
      $stock_total++;
    } else if ($operacion === 1) {
      $stock_total--;
    }
  }

  if ($stock_total <= 0) {
    $no_stock = true;
  }

  $result->data_seek(0);

  $table_style = $no_stock ? "style='border: 2px solid red; background-color: #f8d7da;'" : "";

  echo "<table border='1' $table_style>
            <tr>
                <th>Nombre</th>
                <th>Operación</th>
                <th>Fecha operación</th>
                <th>Comentarios</th>
                <th>ID Usuario</th>
                <th>Opciones</th>
            </tr>";

  while ($row = $result->fetch_assoc()) {
    $operacion = (int) $row['operacion'];
    $row_style = ($stock_total <= 0 && $operacion === 0) ? "style='border: 2px solid red;'" : "";

    echo "<tr $row_style>
              <td>" . htmlspecialchars($row['nombre'] ?? '') . "</td>
              <td>" . htmlspecialchars($row['operacion'] ?? '') . "</td>
              <td>" . htmlspecialchars($row['fecha_operacion'] ?? '') . "</td>
              <td>" . htmlspecialchars($row['comentarios'] ?? '') . "</td>
              <td>" . htmlspecialchars($row['id_usuario'] ?? '') . "</td>
              <td>
                  <a href='update.php?id=" . urlencode($row['id_operacion']) . "' class='btn btn-sm btn-warning'>Editar</a>
                  <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_operacion'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
              </td>
          </tr>";
  }

  echo "<tr>
            <td colspan='5'><strong>Stock Total:</strong></td>
            <td><strong>" . $stock_total . "</strong></td>
          </tr>";

  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_operacion: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>