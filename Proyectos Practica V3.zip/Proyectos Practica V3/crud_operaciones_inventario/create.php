<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_inventario = $_POST['id_inventario'];
  $operacion = $_POST['operacion'];
  $fecha_operacion = $_POST['fecha_operacion'];
  $comentarios = $_POST['comentarios'];
  $id_usuario = $_POST['id_usuario'];

  $stmt = $conn->prepare("INSERT INTO tbl_operacion_inventario (id_inventario, operacion, fecha_operacion,comentarios,id_usuario) VALUES (?, ?, ?,?,?)");
  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sssss", $id_inventario, $operacion, $fecha_operacion, $comentarios, $id_usuario);

  if ($stmt->execute()) {
    echo "Producto guardado correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>