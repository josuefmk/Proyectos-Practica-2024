<?php
include 'conexion.php';
?>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Operacion Inventario</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <h1>Gestión de Operaciones de invententario</h1>

  <button id="toggleAddFormBtn" class="btn">Agregar Operación</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nueva Operación</h2>


      <label for="id_inventario">ID Inventario:</label>
      <select id="id_inventario" name="id_inventario">
        <option value="">-- Seleccionar ID --</option>
        <?php
        $query = "SELECT id_inventario FROM tbl_inventario";
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
            echo "<option value='" . htmlspecialchars($row['id_inventario']) . "'>" . htmlspecialchars($row['id_inventario']) . "</option>";
          }
        }
        ?>
      </select>



      <label for="operacion">Operación:</label>
      <select id="operacion" name="operacion" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="1">Ingreso</option>
        <option value="2">Egreso</option>
      </select>

      <label for="fecha_operacion">Fecha Operación:</label>
      <input type="date" id="fecha_operacion" name="fecha_operacion" required>

      <label for="comentarios">Comentarios:</label>
      <input type="text" id="comentarios" name="comentarios" required>

      <label for="id_usuario">ID Usuario:</label>
      <input type="number" id="id_usuario" name="id_usuario" required>
      <input type="submit" value="Agregar Producto" class="btn">

    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Producto</h3>
    <label for="search_nombre">Nombre Inventario:</label>
    <select id="search_nombre" name="search_nombre">
      <option value="">-- Seleccionar Nombre --</option>
      <?php
      $query = "SELECT id_inventario, nombre FROM tbl_inventario";
      $result = $conn->query($query);
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo "<option value='" . htmlspecialchars($row['id_inventario']) . "'>" . htmlspecialchars($row['nombre']) . "</option>";
        }
      }
      ?>
    </select>

    <label for="search_operacion">Operación:</label>
    <select id="search_operacion" name="search_operacion">
      <option value="">-- Seleccionar --</option>
      <?php
      $query = "SELECT operacion FROM tbl_operacion_inventario";
      $result = $conn->query($query);
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo "<option value='" . htmlspecialchars($row['id_inventario']) . "'>" . htmlspecialchars($row['operacion']) . "</option>";
        }
      }
      ?>
    </select>

    <label for="search_id_usuario">ID Usuario:</label>
    <input type="text" id="search_id_usuario" name="search_id_usuario">

    <label for="search_comentarios">Comentarios:</label>
    <input type="text" id="search_comentarios" name="search_comentarios">

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Productos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>

</html>