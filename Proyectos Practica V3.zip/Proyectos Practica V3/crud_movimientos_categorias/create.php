<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $categoria = $_POST['categoria'];
  $tipo = $_POST['tipo'];


  $stmt = $conn->prepare("INSERT INTO tbl_movimientos_categorias( categoria, tipo) VALUES ( ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ss", $categoria, $tipo);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el Movimiento: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>