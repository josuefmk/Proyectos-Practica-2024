<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Movimiento</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_categoria'])) {
    $id = $_GET['id_categoria'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $categoria = $conn->real_escape_string($_POST['categoria']);
    $tipo = $conn->real_escape_string($_POST['tipo']);


    $sql = "UPDATE tbl_movimientos_categorias
        SET categoria='$categoria', tipo='$tipo'
        WHERE id_categoria='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_movimientos_categorias WHERE id_categoria=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Movimiento</h1>
    <form method="POST">

      <label for="categoria">Categoria:</label>
      <input type="text" id="categoria" name="categoria"
        value="<?php echo htmlspecialchars($row['categoria'] ?? ''); ?>" required>

      <label for="tipo">Tipo:</label>
      <input type="text" id="tipo" name="tipo" value="<?php echo htmlspecialchars($row['tipo'] ?? ''); ?>" required>





      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>