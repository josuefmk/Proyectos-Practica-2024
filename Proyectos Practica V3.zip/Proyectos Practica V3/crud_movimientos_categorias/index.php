<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$tipoOptions = '';
$categoriaOptions = '';

$result_tipo = $conn->query("SELECT DISTINCT tipo FROM tbl_movimientos_categorias");
while ($row = $result_tipo->fetch_assoc()) {
  $tipoOptions .= "<option value='{$row['tipo']}'>{$row['tipo']}</option>";
}


?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Movimientos Categorias</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Movimiento</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Movimiento</h2>

      <label for="categoria">Categoria:</label>
      <input type="text" id="categoria" name="categoria" required>

      <label for="tipo">Tipo:</label>
      <select id="tipo" name="tipo" class="form-control" required>
        <option value=""> Seleccione Opción</option>
        <option value="Ingreso">Ingreso</option>
        <option value="Egreso">Egreso</option>
      </select>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_categoria">Categoría:</label>
    <input type="text" id="search_categoria" name="search_categoria" placeholder="Buscar por Categoría">

    <label for="search_tipo">Tipo :</label>
    <select id="search_tipo" name="search_tipo">
      <option value="">Seleccione un Tipo </option>
      <?php echo $tipoOptions; ?>
    </select>

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>