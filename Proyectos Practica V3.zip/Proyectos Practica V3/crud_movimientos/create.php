<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
var_dump($_POST);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_creador = $_POST['id_creador'];
  $fecha_movimiento = $_POST['fecha_movimiento'];
  $fecha_ingreso = date("Y-m-d H:i:s");
  $monto = $_POST['monto'];
  $tipo = $_POST['tipo'];
  $medio_pago = isset($_POST['medio_pago']) ? trim($_POST['medio_pago']) : null;
  $categoria = $_POST['categoria'];

  $stmt = $conn->prepare("INSERT INTO tbl_movimiento( id_creador, fecha_movimiento,fecha_ingreso, monto, tipo, medio_pago,categoria) VALUES ( ?, ?, ?,?, ?, ?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("issisii", $id_creador, $fecha_movimiento, $fecha_ingreso, $monto, $tipo, $medio_pago, $categoria);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>