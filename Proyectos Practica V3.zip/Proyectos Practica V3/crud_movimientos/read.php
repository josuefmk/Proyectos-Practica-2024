<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$search_fecha_inicio = isset($_GET['search_fecha_inicio']) ? $_GET['search_fecha_inicio'] : '';
$search_fecha_fin = isset($_GET['search_fecha_fin']) ? $_GET['search_fecha_fin'] : '';
$search_ingreso = isset($_GET['search_ingreso']) ? $_GET['search_ingreso'] : '';
$search_tipo = isset($_GET['search_tipo']) ? $_GET['search_tipo'] : '';
$search_categoria = isset($_GET['search_categoria']) ? $_GET['search_categoria'] : '';


$query = "SELECT * FROM tbl_movimiento WHERE 1=1";
$types = '';
$params = [];

if (!empty($search_fecha_inicio) && !empty($search_fecha_fin)) {
  $query .= " AND fecha_movimiento BETWEEN ? AND ?";
  $types .= 'ss';
  $params[] = $search_fecha_inicio;
  $params[] = $search_fecha_fin;
} elseif (!empty($search_fecha_inicio)) {
  $query .= " AND fecha_movimiento >= ?";
  $types .= 's';
  $params[] = $search_fecha_inicio;
} elseif (!empty($search_fecha_fin)) {
  $query .= " AND fecha_movimiento <= ?";
  $types .= 's';
  $params[] = $search_fecha_fin;
}
if (!empty($search_ingreso)) {
  $query .= " AND fecha_ingreso = ?";
  $types .= 's';
  $params[] = $search_ingreso;
}
if (!empty($search_tipo)) {
  $query .= " AND tipo = ?";
  $types .= 's';
  $params[] = $search_tipo;
}

if (!empty($search_categoria)) {
  $query .= " AND categoria = ?";
  $types .= 's';
  $params[] = $search_categoria;
}

$stmt = $conn->prepare($query);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>ID Creador</th>
                <th>Fecha de Movimiento</th>
                <th>Monto</th>
                <th>Tipo</th>
                <th>Medio de Pago</th>
                <th>Categoria</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";
  $total = 0;

  while ($row = $result->fetch_assoc()) {
    $monto = $row['monto'];

    if ($row['tipo'] === 'ingreso') {
      $total += $monto;
    } else {
      $total -= $monto;
    }

    echo "<tr>
           <td>" . htmlspecialchars($row['id_creador']) . "</td>
           <td>" . htmlspecialchars($row['fecha_movimiento']) . "</td>
           <td>" . htmlspecialchars(number_format($row['monto'], 0, ',', '.')) . " CLP</td>
           <td>" . htmlspecialchars($row['tipo']) . "</td>
           <td>" . htmlspecialchars($row['medio_pago']) . "</td>
           <td>" . htmlspecialchars($row['categoria']) . "</td>
           <td>
              <a href='update.php?id_movimiento=" . urlencode($row['id_movimiento']) . "' class='btn btn-sm btn-warning'>Editar</a>
           </td>
           <td>
              <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_movimiento'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
           </td>
          </tr>";
  }
  echo "</table>";

  echo "<p><strong>Total: </strong>" . htmlspecialchars(number_format($total, 0, ',', '.')) . " CLP</p>";

} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();


?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_movimiento: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>