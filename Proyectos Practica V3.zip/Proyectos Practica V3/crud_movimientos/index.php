<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$tipoOptions = '';
$categoriaOptions = '';
$categoriaOptions1 = '';
$metodopagoOptions = '';

$result_tipo = $conn->query("SELECT DISTINCT tipo FROM tbl_movimiento");
while ($row = $result_tipo->fetch_assoc()) {
  $tipoOptions .= "<option value='{$row['tipo']}'>{$row['tipo']}</option>";
}
$result_categoria = $conn->query("SELECT DISTINCT categoria FROM tbl_movimientos_categorias");
while ($row = $result_categoria->fetch_assoc()) {
  $categoriaOptions .= "<option value='{$row['categoria']}'>{$row['categoria']}</option>";
}
$result_categoria1 = $conn->query("SELECT DISTINCT categoria FROM tbl_movimiento");
while ($row = $result_categoria1->fetch_assoc()) {
  $categoriaOptions1 .= "<option value='{$row['categoria']}'>{$row['categoria']}</option>";
}
$result_metodopago = $conn->query("SELECT DISTINCT nombre FROM tbl_medio_pago");
while ($row = $result_metodopago->fetch_assoc()) {
  $metodopagoOptions .= "<option value='{$row['nombre']}'>{$row['nombre']}</option>";
}


?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Movimientos</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Movimiento</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Movimiento</h2>


      <label for="id_creador">ID Creador:</label>
      <input type="number" id="id_creador" name="id_creador" required>

      <label for="fecha_movimiento">Fecha de Movimiento:</label>
      <input type="date" id="fecha_movimiento" name="fecha_movimiento" required>



      <label for="monto">Monto:</label>
      <input type="number" id="monto" name="monto" required>

      <label for="tipo">Tipo:</label>
      <select id="tipo" name="tipo" class="form-control" required>
        <option value=""> Seleccione Tipo</option>
        <option value="Ingreso">Ingreso</option>
        <option value="Egreso">Egreso</option>
      </select>

      <label for="medio_pago">Metdio de pago:</label>
      <select id="medio_pago" name="medio_pago">
        <option value="">Seleccione un Medio de pago </option>
        <?php echo $metodopagoOptions; ?>
      </select>


      <label for="categoria">Categoria:</label>
      <select id="categoria" name="categoria">
        <option value="">Seleccione una Categoria </option>
        <?php echo $categoriaOptions; ?>
      </select>


      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_fecha_inicio">Fecha de Inicio:</label>
    <input type="date" id="search_fecha_inicio" name="search_fecha_inicio">

    <label for="search_fecha_fin">Fecha de Fin:</label>
    <input type="date" id="search_fecha_fin" name="search_fecha_fin">


    <label for="search_tipo">Tipo :</label>
    <select id="search_tipo" name="search_tipo">
      <option value="">Seleccione un Tipo </option>
      <?php echo $tipoOptions; ?>
    </select>

    <label for="search_categoria">Categoria :</label>
    <select id="search_categoria" name="search_categoria">
      <option value="">Seleccione una Categoria </option>
      <?php echo $categoriaOptions1; ?>
    </select>


    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });
    });
  </script>
</body>