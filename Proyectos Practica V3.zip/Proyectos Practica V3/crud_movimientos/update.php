<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Movimiento</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_movimiento'])) {
    $id = $_GET['id_movimiento'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_creador = $conn->real_escape_string($_POST['id_creador']);
    $fecha_movimiento = $conn->real_escape_string($_POST['fecha_movimiento']);

    $monto = $conn->real_escape_string($_POST['monto']);
    $tipo = $conn->real_escape_string($_POST['tipo']);
    $medio_pago = $conn->real_escape_string($_POST['medio_pago']);
    $categoria = $conn->real_escape_string($_POST['categoria']);


    $sql = "UPDATE tbl_movimiento
        SET id_creador='$id_creador', fecha_movimiento='$fecha_movimiento' monto='$monto', tipo='$tipo', medio_pago='$medio_pago', categoria='$categoria'
        WHERE id_movimiento='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_movimiento WHERE id_movimiento=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Atraso</h1>
    <form method="POST">
      <label for="id_creador">ID creador:</label>
      <input type="number" id="id_creador" name="id_creador"
        value="<?php echo htmlspecialchars($row['id_creador'] ?? ''); ?>" required>

      <label for="fecha_movimiento">Fecha de Movimiento:</label>
      <input type="date" id="fecha_movimiento" name="fecha_movimiento"
        value="<?php echo htmlspecialchars($row['minutos_atraso'] ?? ''); ?>" required>

      <label for="monto">Monto:</label>
      <input type="number" id="monto" name="monto" value="<?php echo htmlspecialchars($row['monto'] ?? ''); ?>"
        required>

      <label for="tipo">Monto:</label>
      <input type="text" id="tipo" name="tipo" value="<?php echo htmlspecialchars($row['tipo'] ?? ''); ?>" required>

      <label for="medio_pago">Medio de Pago:</label>
      <input type="number" id="medio_pago" name="medio_pago"
        value="<?php echo htmlspecialchars($row['medio_pago'] ?? ''); ?>" required>

      <label for="categoria">Categoria:</label>
      <input type="number" id="categoria" name="categoria"
        value="<?php echo htmlspecialchars($row['categoria'] ?? ''); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>