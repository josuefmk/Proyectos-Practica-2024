<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Registro</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $folio_boleta = $conn->real_escape_string($_POST['folio_boleta']);
    $codigo_matricula = $conn->real_escape_string($_POST['codigo_matricula']);
    $id_creador = $conn->real_escape_string($_POST['id_creador']);
    $time_creacion = $conn->real_escape_string($_POST['time_creacion']);
    $fecha_pago = $conn->real_escape_string($_POST['fecha_pago']);
    $forma_pago = $conn->real_escape_string($_POST['forma_pago']);
    $tipo_pago = $conn->real_escape_string($_POST['tipo_pago']);
    $tipo_documento = $conn->real_escape_string($_POST['tipo_documento']);
    $total_pago = $conn->real_escape_string($_POST['total_pago']);
    $estado = $conn->real_escape_string($_POST['estado']);

    $sql = "UPDATE tbl_pagos SET folio_boleta='$folio_boleta', codigo_matricula='$codigo_matricula',
    id_creador='$id_creador', time_creacion='$time_creacion', fecha_pago='$fecha_pago',
    forma_pago='$forma_pago', tipo_pago='$tipo_pago', tipo_documento='$tipo_documento',
    total_pago='$total_pago', estado='$estado' WHERE id_pago=$id";

    if ($conn->query($sql)) {
      echo "<p class='success'>Pago actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_pagos WHERE id_pago=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Registro de Pagos</h1>
    <form method="POST">
      <label for="folio_boleta">Folio Boleta</label>
      <input type="text" id="folio_boleta" name="folio_boleta"
        value="<?php echo htmlspecialchars($row['folio_boleta']); ?>" required readonly>

      <label for="codigo_matricula">Código Matrícula:</label>
      <input type="number" id="codigo_matricula" name="codigo_matricula"
        value="<?php echo htmlspecialchars($row['codigo_matricula']); ?>" required>

      <label for="id_creador">ID Creador:</label>
      <input type="number" id="id_creador" name="id_creador" value="<?php echo htmlspecialchars($row['id_creador']); ?>"
        required>

      <label for="time_creacion">Tiempo Creación:</label>
      <input type="datetime-local" id="time_creacion" name="time_creacion"
        value="<?php echo htmlspecialchars($row['time_creacion']); ?>" required>

      <label for="fecha_pago">Fecha Pago:</label>
      <input type="date" id="fecha_pago" name="fecha_pago" value="<?php echo htmlspecialchars($row['fecha_pago']); ?>"
        required>

      <label for="forma_pago">Forma Pago:</label>
      <input type="number" id="forma_pago" name="forma_pago" value="<?php echo htmlspecialchars($row['forma_pago']); ?>"
        required>

      <label for="tipo_pago">Tipo Pago:</label>
      <input type="number" id="tipo_pago" name="tipo_pago" value="<?php echo htmlspecialchars($row['tipo_pago']); ?>"
        required>

      <label for="tipo_documento">Tipo Documento:</label>
      <input type="number" id="tipo_documento" name="tipo_documento"
        value="<?php echo htmlspecialchars($row['tipo_documento']); ?>" required>

      <label for="total_pago">Total Pago:</label>
      <input type="number" id="total_pago" name="total_pago" value="<?php echo htmlspecialchars($row['total_pago']); ?>"
        required>

      <label for="estado">Estado:</label>
      <input type="number" id="estado" name="estado" value="<?php echo htmlspecialchars($row['estado']); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>