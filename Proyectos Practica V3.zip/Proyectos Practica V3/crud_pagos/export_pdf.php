<?php
require __DIR__ . '/vendor/autoload.php';

include 'conexion.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('defaultFont', 'DejaVu Sans');
$dompdf = new Dompdf($options);

$search_folio_boleta = isset($_GET['search_folio_boleta']) ? $_GET['search_folio_boleta'] : '';
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';
$search_fecha_pago = isset($_GET['search_fecha_pago']) ? $_GET['search_fecha_pago'] : '';
$search_forma_pago = isset($_GET['search_forma_pago']) ? $_GET['search_forma_pago'] : '';
$search_tipo_pago = isset($_GET['search_tipo_pago']) ? $_GET['search_tipo_pago'] : '';
$search_tipo_documento = isset($_GET['search_tipo_documento']) ? $_GET['search_tipo_documento'] : '';
$search_total_pago_min = isset($_GET['search_total_pago_min']) ? $_GET['search_total_pago_min'] : '';
$search_total_pago_max = isset($_GET['search_total_pago_max']) ? $_GET['search_total_pago_max'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';

$sql = "SELECT folio_boleta, codigo_matricula, id_creador, time_creacion, fecha_pago, forma_pago, tipo_pago, tipo_documento, total_pago, estado
        FROM tbl_pagos
        WHERE 1=1";
$params = [];
$types = "";

if (!empty($search_folio_boleta)) {
  $sql .= " AND folio_boleta LIKE ?";
  $params[] = "%" . $search_folio_boleta . "%";
  $types .= "s";
}
if (!empty($search_codigo_matricula)) {
  $sql .= " AND codigo_matricula LIKE ?";
  $params[] = "%" . $search_codigo_matricula . "%";
  $types .= "s";
}
if (!empty($search_fecha_pago)) {
  $sql .= " AND fecha_pago = ?";
  $params[] = $search_fecha_pago;
  $types .= "s";
}
if (!empty($search_forma_pago)) {
  $sql .= " AND forma_pago = ?";
  $params[] = $search_forma_pago;
  $types .= "i";
}
if (!empty($search_tipo_pago)) {
  $sql .= " AND tipo_pago = ?";
  $params[] = $search_tipo_pago;
  $types .= "i";
}
if (!empty($search_tipo_documento)) {
  $sql .= " AND tipo_documento = ?";
  $params[] = $search_tipo_documento;
  $types .= "i";
}
if (!empty($search_total_pago_min) && !empty($search_total_pago_max)) {
  $sql .= " AND total_pago BETWEEN ? AND ?";
  $params[] = $search_total_pago_min;
  $params[] = $search_total_pago_max;
  $types .= "dd";
} elseif (!empty($search_total_pago_min)) {
  $sql .= " AND total_pago >= ?";
  $params[] = $search_total_pago_min;
  $types .= "d";
} elseif (!empty($search_total_pago_max)) {
  $sql .= " AND total_pago <= ?";
  $params[] = $search_total_pago_max;
  $types .= "d";
}
if (!empty($search_estado)) {
  $sql .= " AND estado = ?";
  $params[] = $search_estado;
  $types .= "i";
}


$stmt = $conn->prepare($sql);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
  die("Error en la ejecución de la consulta: " . $stmt->error);
}

$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Informe de Pagos</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h1 { text-align: center; color: #333; }
        table { width: 100%; border-collapse: collapse; background-color: #fff; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .no-data { text-align: center; padding: 20px; }
    </style>
</head>
<body>
    <h1>Informe de Pagos</h1>
    <table>
        <thead>
            <tr>
                <th>Folio Boleta</th>
                <th>Código Matrícula</th>
                <th>ID Creador</th>
                <th>Tiempo Creación</th>
                <th>Fecha Pago</th>
                <th>Forma Pago</th>
                <th>Tipo Pago</th>
                <th>Tipo Documento</th>
                <th>Total Pago</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>';

if ($result->num_rows > 0) {
  while ($data = $result->fetch_assoc()) {
    $html .= '<tr>
                    <td>' . htmlspecialchars($data['folio_boleta']) . '</td>
                    <td>' . htmlspecialchars($data['codigo_matricula']) . '</td>
                    <td>' . htmlspecialchars($data['id_creador']) . '</td>
                    <td>' . htmlspecialchars($data['time_creacion']) . '</td>
                    <td>' . htmlspecialchars($data['fecha_pago']) . '</td>
                    <td>' . htmlspecialchars($data['forma_pago']) . '</td>
                    <td>' . htmlspecialchars($data['tipo_pago']) . '</td>
                    <td>' . htmlspecialchars($data['tipo_documento']) . '</td>
                    <td>' . htmlspecialchars(number_format($data['total_pago'], 2)) . '</td>
                    <td>' . htmlspecialchars($data['estado']) . '</td>
                  </tr>';
  }
} else {
  $html .= '<tr><td colspan="10" class="no-data">No hay registros que coincidan con la búsqueda.</td></tr>';
}

$html .= '</tbody>
    </table>
</body>
</html>';

$dompdf->loadHtml($html);

$dompdf->setPaper('A4', 'landscape');


$dompdf->render();

$dompdf->stream('Informe_Pagos.pdf', ['Attachment' => false]);


$stmt->close();
$conn->close();
?>