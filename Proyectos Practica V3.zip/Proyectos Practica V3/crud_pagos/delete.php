<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['id'];


  if (!empty($id)) {
    $stmt = $conn->prepare("DELETE FROM tbl_pagos WHERE id_pago = ?");

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
      echo 'success';
    } else {
      echo 'error: ' . $stmt->error;
    }

    $stmt->close();
  } else {
    echo 'error: ID no proporcionado';
  }
}

$conn->close();
?>