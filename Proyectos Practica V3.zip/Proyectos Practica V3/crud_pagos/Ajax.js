
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('PagosForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('create.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.text())
      .then(data => {
        document.getElementById('result').innerHTML = data;
        this.reset();
        loadRecords();
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });

  function loadRecords() {
    fetch('read.php')
      .then(response => response.text())
      .then(data => {
        document.getElementById('tableContainer').innerHTML = data;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }


  loadRecords();


  document.getElementById("toggleFormBtn").addEventListener("click", function () {
    const formContainer = document.getElementById("PagosFormContainer");

    if (formContainer.style.display === "none" || formContainer.style.display === "") {
      formContainer.style.display = "block";
    } else {
      formContainer.style.display = "none";
    }

  })
});
  $(document).ready(function() {
    // Limpiar los filtros de búsqueda
    $('#clearFilterBtn').on('click', function() {
      $('#search_folio_boleta').val('');
      $('#search_codigo_matricula').val('');
      $('#search_fecha_pago').val('');
      $('#search_forma_pago').val('');
      $('#search_tipo_pago').val('');
      $('#search_tipo_documento').val('');
      $('#search_total_pago_min').val('');
      $('#search_total_pago_max').val('');
      $('#search_estado').val('');
      $('#searchForm').submit();
    });


  });