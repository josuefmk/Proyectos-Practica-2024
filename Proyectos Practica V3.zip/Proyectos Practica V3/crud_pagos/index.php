<?php
include 'conexion.php';


$search_folio_boleta = isset($_GET['search_folio_boleta']) ? $_GET['search_folio_boleta'] : '';
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';
$search_fecha_pago = isset($_GET['search_fecha_pago']) ? $_GET['search_fecha_pago'] : '';
$search_forma_pago = isset($_GET['search_forma_pago']) ? $_GET['search_forma_pago'] : '';
$search_tipo_pago = isset($_GET['search_tipo_pago']) ? $_GET['search_tipo_pago'] : '';
$search_tipo_documento = isset($_GET['search_tipo_documento']) ? $_GET['search_tipo_documento'] : '';
$search_total_pago_min = isset($_GET['search_total_pago_min']) ? $_GET['search_total_pago_min'] : '';
$search_total_pago_max = isset($_GET['search_total_pago_max']) ? $_GET['search_total_pago_max'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Pagos</title>
  <link rel="stylesheet" href="styles.css">

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="Ajax.js"></script>
</head>

<body>

  <div class="container mt-5">
    <h1 class="mb-4">Gestión de Pagos</h1>


    <button id="toggleFormBtn" class="btn btn-primary mb-3">Agregar Pagos</button>
    <div class="form-container-add" id="PagosFormContainer" style="display: none;">
      <form id="PagosForm" method="post" action="create.php">
        <h2>Nuevo Pago</h2>
        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="folio_boleta">Folio Boleta:</label>
            <input type="text" id="folio_boleta" name="folio_boleta" class="form-control" required>
          </div>

          <div class="form-group col-md-4">
            <label for="codigo_matricula">Código Matrícula:</label>
            <input type="number" id="codigo_matricula" name="codigo_matricula" class="form-control" required>
          </div>

          <div class="form-group col-md-4">
            <label for="id_creador">ID Creador:</label>
            <input type="number" id="id_creador" name="id_creador" class="form-control" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="time_creacion">Tiempo Creación:</label>
            <input type="datetime-local" id="time_creacion" name="time_creacion" class="form-control" required>
          </div>

          <div class="form-group col-md-4">
            <label for="fecha_pago">Fecha Pago:</label>
            <input type="date" id="fecha_pago" name="fecha_pago" class="form-control" required>
          </div>

          <div class="form-group col-md-4">
            <label for="forma_pago">Forma Pago:</label>
            <select id="forma_pago" name="forma_pago" class="form-control" required>
              <option value="">-- Seleccionar --</option>
              <option value="1">Efectivo</option>
              <option value="2">Cheque</option>
              <option value="3">Transferencia</option>
              <option value="4">Tarjeta de Crédito</option>
              <option value="5">Tarjeta de Débito</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="tipo_pago">Tipo Pago:</label>
            <select id="tipo_pago" name="tipo_pago" class="form-control" required>
              <option value="">-- Seleccionar --</option>
              <option value="1">Mensualidad</option>
              <option value="2">Matrícula</option>
              <option value="3">Diploma</option>
              <option value="4">Abono</option>
            </select>
          </div>

          <div class="form-group col-md-4">
            <label for="tipo_documento">Tipo Documento:</label>
            <select id="tipo_documento" name="tipo_documento" class="form-control" required>
              <option value="">-- Seleccionar --</option>
              <option value="1">Boleta</option>
              <option value="2">Factura</option>
              <option value="3">Nota de Crédito</option>
            </select>
          </div>

          <div class="form-group col-md-4">
            <label for="total_pago">Total Pago:</label>
            <input type="number" step="0.01" id="total_pago" name="total_pago" class="form-control" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="estado">Estado:</label>
            <select id="estado" name="estado" class="form-control" required>
              <option value="">-- Seleccionar --</option>
              <option value="1">Confirmado</option>
              <option value="2">Pendiente</option>
            </select>
          </div>
        </div>

        <button type="submit" class="btn ">Agregar Pago</button>
      </form>
    </div>


    <form id="searchForm" method="GET" class="mb-4">
      <h3>Buscar Pagos</h3>
      <div class="form-row">
        <div class="form-group col-md-3">
          <label for="search_folio_boleta">Folio Boleta:</label>
          <input type="text" id="search_folio_boleta" name="search_folio_boleta" class="form-control"
            value="<?php echo htmlspecialchars($search_folio_boleta); ?>">
        </div>
        <div class="form-group col-md-3">
          <label for="search_codigo_matricula">Código Matrícula:</label>
          <input type="text" id="search_codigo_matricula" name="search_codigo_matricula" class="form-control"
            value="<?php echo htmlspecialchars($search_codigo_matricula); ?>">
        </div>
        <div class="form-group col-md-3">
          <label for="search_fecha_pago">Fecha Pago:</label>
          <input type="date" id="search_fecha_pago" name="search_fecha_pago" class="form-control"
            value="<?php echo htmlspecialchars($search_fecha_pago); ?>">
        </div>
        <div class="form-group col-md-3">
          <label for="search_forma_pago">Forma Pago:</label>
          <select id="search_forma_pago" name="search_forma_pago" class="form-control">
            <option value="">-- Seleccionar Forma de Pago --</option>
            <option value="1" <?php if ($search_forma_pago == '1')
              echo 'selected'; ?>>Efectivo</option>
            <option value="2" <?php if ($search_forma_pago == '2')
              echo 'selected'; ?>>Cheque</option>
            <option value="3" <?php if ($search_forma_pago == '3')
              echo 'selected'; ?>>Transferencia</option>
            <option value="4" <?php if ($search_forma_pago == '4')
              echo 'selected'; ?>>Tarjeta de Crédito</option>
            <option value="5" <?php if ($search_forma_pago == '5')
              echo 'selected'; ?>>Tarjeta de Débito</option>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-3">
          <label for="search_tipo_pago">Tipo Pago:</label>
          <select id="search_tipo_pago" name="search_tipo_pago" class="form-control">
            <option value="">-- Seleccionar Tipo de Pago --</option>
            <option value="1" <?php if ($search_tipo_pago == '1')
              echo 'selected'; ?>>Mensualidad</option>
            <option value="2" <?php if ($search_tipo_pago == '2')
              echo 'selected'; ?>>Matrícula</option>
            <option value="3" <?php if ($search_tipo_pago == '3')
              echo 'selected'; ?>>Diploma</option>
            <option value="4" <?php if ($search_tipo_pago == '4')
              echo 'selected'; ?>>Abono</option>
          </select>
        </div>

        <div class="form-group col-md-3">
          <label for="search_tipo_documento">Tipo Documento:</label>
          <select id="search_tipo_documento" name="search_tipo_documento" class="form-control">
            <option value="">-- Seleccionar Tipo de Documento --</option>
            <option value="1" <?php if ($search_tipo_documento == '1')
              echo 'selected'; ?>>Boleta</option>
            <option value="2" <?php if ($search_tipo_documento == '2')
              echo 'selected'; ?>>Factura</option>
            <option value="3" <?php if ($search_tipo_documento == '3')
              echo 'selected'; ?>>Nota de Crédito</option>
          </select>
        </div>

        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="search_total_pago_min">Total Pago Mínimo:</label>
            <input type="number" step="0.01" id="search_total_pago_min" name="search_total_pago_min"
              class="form-control"
              value="<?php echo isset($_GET['search_total_pago_min']) ? htmlspecialchars($_GET['search_total_pago_min']) : ''; ?>">
          </div>

          <div class="form-group col-md-4">
            <label for="search_total_pago_max">Total Pago Máximo:</label>
            <input type="number" step="0.01" id="search_total_pago_max" name="search_total_pago_max"
              class="form-control"
              value="<?php echo isset($_GET['search_total_pago_max']) ? htmlspecialchars($_GET['search_total_pago_max']) : ''; ?>">
          </div>
        </div>

        <div class="form-group col-md-3">
          <label for="search_estado">Estado:</label>
          <select id="search_estado" name="search_estado" class="form-control">
            <option value="">-- Seleccionar Estado --</option>
            <option value="1" <?php if ($search_estado == '1')
              echo 'selected'; ?>>Confirmado</option>
            <option value="2" <?php if ($search_estado == '2')
              echo 'selected'; ?>>Pendiente</option>
          </select>
        </div>
      </div>

      <button type="submit" class="btn ">Buscar</button>
      <button type="button" id="clearFilterBtn" class="btn ">Quitar Filtro</button>
    </form>


    <h2>Lista de Pagos Registrados</h2>
    <div id="result">
      <?php include 'read.php'; ?>
    </div>
  </div>
</body>

</html>