<?php
require 'vendor/autoload.php';
include 'conexion.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$search_folio_boleta = isset($_GET['search_folio_boleta']) ? $_GET['search_folio_boleta'] : '';
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';
$search_fecha_pago = isset($_GET['search_fecha_pago']) ? $_GET['search_fecha_pago'] : '';
$search_forma_pago = isset($_GET['search_forma_pago']) ? $_GET['search_forma_pago'] : '';
$search_tipo_pago = isset($_GET['search_tipo_pago']) ? $_GET['search_tipo_pago'] : '';
$search_tipo_documento = isset($_GET['search_tipo_documento']) ? $_GET['search_tipo_documento'] : '';
$search_total_pago_min = isset($_GET['search_total_pago_min']) ? $_GET['search_total_pago_min'] : '';
$search_total_pago_max = isset($_GET['search_total_pago_max']) ? $_GET['search_total_pago_max'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';

$sql = "SELECT folio_boleta, codigo_matricula, id_creador, time_creacion, fecha_pago, forma_pago, tipo_pago, tipo_documento, total_pago, estado FROM tbl_pagos WHERE 1=1";
$params = [];
$types = "";

if (!empty($search_folio_boleta)) {
  $sql .= " AND folio_boleta LIKE ?";
  $params[] = "%" . $search_folio_boleta . "%";
  $types .= "s";
}
if (!empty($search_codigo_matricula)) {
  $sql .= " AND codigo_matricula LIKE ?";
  $params[] = "%" . $search_codigo_matricula . "%";
  $types .= "s";
}
if (!empty($search_fecha_pago)) {
  $sql .= " AND fecha_pago = ?";
  $params[] = $search_fecha_pago;
  $types .= "s";
}
if (!empty($search_forma_pago)) {
  $sql .= " AND forma_pago = ?";
  $params[] = $search_forma_pago;
  $types .= "i";
}
if (!empty($search_tipo_pago)) {
  $sql .= " AND tipo_pago = ?";
  $params[] = $search_tipo_pago;
  $types .= "i";
}
if (!empty($search_tipo_documento)) {
  $sql .= " AND tipo_documento = ?";
  $params[] = $search_tipo_documento;
  $types .= "i";
}
if (!empty($search_total_pago_min) && !empty($search_total_pago_max)) {
  $sql .= " AND total_pago BETWEEN ? AND ?";
  $params[] = $search_total_pago_min;
  $params[] = $search_total_pago_max;
  $types .= "dd";
} elseif (!empty($search_total_pago_min)) {
  $sql .= " AND total_pago >= ?";
  $params[] = $search_total_pago_min;
  $types .= "d";
} elseif (!empty($search_total_pago_max)) {
  $sql .= " AND total_pago <= ?";
  $params[] = $search_total_pago_max;
  $types .= "d";
}
if (!empty($search_estado)) {
  $sql .= " AND estado = ?";
  $params[] = $search_estado;
  $types .= "i";
}

$stmt = $conn->prepare($sql);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}


if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
  die("Error en la consulta: " . $conn->error);
}

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$headers = ['Folio Boleta', 'Código Matrícula', 'ID Creador', 'Tiempo Creación', 'Fecha Pago', 'Forma Pago', 'Tipo Pago', 'Tipo Documento', 'Total Pago', 'Estado'];
$column = 'A';
foreach ($headers as $header) {
  $sheet->setCellValue($column . '1', $header);
  $column++;
}

$row = 2;
while ($data = $result->fetch_assoc()) {
  $sheet->setCellValue('A' . $row, $data['folio_boleta']);
  $sheet->setCellValue('B' . $row, $data['codigo_matricula']);
  $sheet->setCellValue('C' . $row, $data['id_creador']);
  $sheet->setCellValue('D' . $row, $data['time_creacion']);
  $sheet->setCellValue('E' . $row, $data['fecha_pago']);
  $sheet->setCellValue('F' . $row, $data['forma_pago']);
  $sheet->setCellValue('G' . $row, $data['tipo_pago']);
  $sheet->setCellValue('H' . $row, $data['tipo_documento']);
  $sheet->setCellValue('I' . $row, number_format($data['total_pago'], 2));
  $sheet->setCellValue('J' . $row, $data['estado']);
  $row++;
}

foreach (range('A', 'J') as $columnID) {
  $sheet->getColumnDimension($columnID)->setAutoSize(true);
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Pagos.xlsx"');


$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

$stmt->close();
$conn->close();
?>