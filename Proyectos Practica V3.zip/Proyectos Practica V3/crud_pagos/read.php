<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inicialización de las variables de búsqueda
$search_folio_boleta = isset($_GET['search_folio_boleta']) ? $_GET['search_folio_boleta'] : '';
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';
$search_fecha_pago = isset($_GET['search_fecha_pago']) ? $_GET['search_fecha_pago'] : '';
$search_forma_pago = isset($_GET['search_forma_pago']) ? $_GET['search_forma_pago'] : '';
$search_tipo_pago = isset($_GET['search_tipo_pago']) ? $_GET['search_tipo_pago'] : '';
$search_tipo_documento = isset($_GET['search_tipo_documento']) ? $_GET['search_tipo_documento'] : '';
$search_total_pago_min = isset($_GET['search_total_pago_min']) ? $_GET['search_total_pago_min'] : '';
$search_total_pago_max = isset($_GET['search_total_pago_max']) ? $_GET['search_total_pago_max'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';

$sql = "SELECT id_pago, folio_boleta, codigo_matricula, id_creador, time_creacion, fecha_pago, forma_pago, tipo_pago, tipo_documento, total_pago, estado FROM tbl_pagos WHERE 1=1";
$params = [];
$types = "";

// Filtros de búsqueda
if (!empty($search_folio_boleta)) {
  $sql .= " AND folio_boleta LIKE ?";
  $params[] = "%" . $search_folio_boleta . "%";
  $types .= "s";
}
if (!empty($search_codigo_matricula)) {
  $sql .= " AND codigo_matricula LIKE ?";
  $params[] = "%" . $search_codigo_matricula . "%";
  $types .= "s";
}
if (!empty($search_fecha_pago)) {
  $sql .= " AND fecha_pago = ?";
  $params[] = $search_fecha_pago;
  $types .= "s";
}
if (!empty($search_forma_pago)) {
  $sql .= " AND forma_pago = ?";
  $params[] = $search_forma_pago;
  $types .= "i";
}
if (!empty($search_tipo_pago)) {
  $sql .= " AND tipo_pago = ?";
  $params[] = $search_tipo_pago;
  $types .= "i";
}
if (!empty($search_tipo_documento)) {
  $sql .= " AND tipo_documento = ?";
  $params[] = $search_tipo_documento;
  $types .= "i";
}

if (!empty($search_total_pago_min) && !empty($search_total_pago_max)) {
  $sql .= " AND total_pago BETWEEN ? AND ?";
  $params[] = $search_total_pago_min;
  $params[] = $search_total_pago_max;
  $types .= "dd";
} elseif (!empty($search_total_pago_min)) {
  $sql .= " AND total_pago >= ?";
  $params[] = $search_total_pago_min;
  $types .= "d";
} elseif (!empty($search_total_pago_max)) {
  $sql .= " AND total_pago <= ?";
  $params[] = $search_total_pago_max;
  $types .= "d";
}

if (!empty($search_estado)) {
  $sql .= " AND estado = ?";
  $params[] = $search_estado;
  $types .= "i";
}

$stmt = $conn->prepare($sql);
if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
  echo "Error en la consulta: " . $conn->error;
} elseif ($result->num_rows > 0) {
  echo "<div style='margin-bottom: 10px;'>
            <a href='export_xls.php?" . http_build_query([
      'search_folio_boleta' => $search_folio_boleta,
      'search_codigo_matricula' => $search_codigo_matricula,
      'search_fecha_pago' => $search_fecha_pago,
      'search_forma_pago' => $search_forma_pago,
      'search_tipo_pago' => $search_tipo_pago,
      'search_tipo_documento' => $search_tipo_documento,
      'search_total_pago_min' => $search_total_pago_min,
      'search_total_pago_max' => $search_total_pago_max,
      'search_estado' => $search_estado,
    ]) . "' class='btn btn-success'>Exportar a Excel</a>
            <a href='export_pdf.php?" . http_build_query([
      'search_folio_boleta' => $search_folio_boleta,
      'search_codigo_matricula' => $search_codigo_matricula,
      'search_fecha_pago' => $search_fecha_pago,
      'search_forma_pago' => $search_forma_pago,
      'search_tipo_pago' => $search_tipo_pago,
      'search_tipo_documento' => $search_tipo_documento,
      'search_total_pago_min' => $search_total_pago_min,
      'search_total_pago_max' => $search_total_pago_max,
      'search_estado' => $search_estado,
    ]) . "' class='btn btn-danger'>Exportar a PDF</a>
          </div>";

  echo "<table class='table table-bordered'>
            <thead class='thead-dark'>
                <tr>
                    <th>Folio Boleta</th>
                    <th>Código Matrícula</th>
                    <th>ID Creador</th>
                    <th>Tiempo Creación</th>
                    <th>Fecha Pago</th>
                    <th>Forma Pago</th>
                    <th>Tipo Pago</th>
                    <th>Tipo Documento</th>
                    <th>Total Pago</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                </tr>
            </thead>
            <tbody>";

  $total_sum = 0;
  while ($row = $result->fetch_assoc()) {
    $total_sum += $row['total_pago'];
    echo "<tr>
                <td>" . htmlspecialchars($row['folio_boleta']) . "</td>
                <td>" . htmlspecialchars($row['codigo_matricula']) . "</td>
                <td>" . htmlspecialchars($row['id_creador']) . "</td>
                <td>" . htmlspecialchars($row['time_creacion']) . "</td>
                <td>" . htmlspecialchars($row['fecha_pago']) . "</td>
                <td>" . htmlspecialchars($row['forma_pago']) . "</td>
                <td>" . htmlspecialchars($row['tipo_pago']) . "</td>
                <td>" . htmlspecialchars($row['tipo_documento']) . "</td>
                <td>" . htmlspecialchars(number_format($row['total_pago'])) . " CLP</td>
                <td>" . htmlspecialchars($row['estado']) . "</td>
                <td>
                    <a href='update.php?id=" . urlencode($row['id_pago']) . "' class='btn btn-sm btn-warning'>Editar</a>
                    <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_pago'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
                </td>
              </tr>";
  }

  echo "<tr>
            <td colspan='8' class='text-right'><strong>Total:</strong></td>
            <td colspan='2'><strong>" . htmlspecialchars(number_format($total_sum)) . " CLP </strong></td>
            <td></td>
          </tr>";
  echo "</tbody></table>";
} else {
  echo "<div class='alert alert-info'>No hay registros de pago que coincidan con la búsqueda.</div>";
}

$stmt->close();
$conn->close();
?>

<script>
// Confirmación de eliminación de un registro
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        console.log(response);
        if (response === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro.');
        }
      },
      error: function(xhr, status, error) {
        console.log(xhr.responseText);
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>