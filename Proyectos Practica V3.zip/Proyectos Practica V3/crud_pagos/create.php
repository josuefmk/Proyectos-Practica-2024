<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $folio_boleta = $_POST['folio_boleta'];
  $codigo_matricula = $_POST['codigo_matricula'];
  $id_creador = $_POST['id_creador'];
  $time_creacion = $_POST['time_creacion'];
  $fecha_pago = $_POST['fecha_pago'];
  $forma_pago = $_POST['forma_pago'];
  $tipo_pago = $_POST['tipo_pago'];
  $tipo_documento = $_POST['tipo_documento'];
  $total_pago = $_POST['total_pago'];
  $estado = $_POST['estado'];




  $stmt = $conn->prepare("INSERT INTO tbl_pagos (folio_boleta,codigo_matricula, id_creador,time_creacion, fecha_pago,forma_pago,tipo_pago,tipo_documento,total_pago,estado) VALUES (?, ?, ?, ?, ?,?, ?, ?, ?, ?)");
  $stmt->bind_param("ssssssssss", $folio_boleta, $codigo_matricula, $id_creador, $time_creacion, $fecha_pago, $forma_pago, $tipo_pago, $tipo_documento, $total_pago, $estado);


  if ($stmt->execute()) {
    echo "Pago guardado correctamente";
  } else {
    echo "Error al guardar el Pago: " . $stmt->error;
  }
  $stmt->close();
}