<?php
include 'select.php';
function getNombreObjeto($conn)
{
  $sql = "SELECT id_icono, nombre_objeto FROM tbl_iconos_objetos";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // Generar las opciones para el select
    while ($row = $result->fetch_assoc()) {
      echo "<option value='" . $row['id_icono'] . "'>" . $row['nombre_objeto'] . "</option>";
    }
  } else {
    echo "<option value=''>No hay objetos disponibles</option>";
  }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>CRUD Categoria Objeto</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleFormBtn">Agregar Iconos Objeto</button>

  <div class="form-container-add" id="ObjetoFormContainer">
    <form id="ObjetoForm" method="post" action="create.php" enctype="multipart/form-data">
      <h2>Nuevo Objeto</h2>
      <label for="id_icono">ID Icono:</label>
      <input type="text" id="id_icono" name="id_icono" required>

      <label for="nombre_objeto">Nombre Objeto:</label>
      <input type="text" id="nombre_objeto" name="nombre_objeto" required>

      <label for="descripcion_objeto">Descripción Objeto:</label>
      <input type="text" id="descripcion_objeto" name="descripcion_objeto" required>

      <label for="categoria_objeto">Categoría Objeto:</label>
      <select id="categoria_objeto" name="id_categoria_objeto" required>
        <?php
        echo getCategorias($conn);
        ?>
      </select>

      <label for="link_objeto">Subir archivo (PNG o SVG):</label>
      <input type="file" id="link_objeto" name="link_objeto" accept=".png, .svg" required>

      <input type="submit" value="Agregar Objeto" class="submit-btn">
    </form>
  </div>
  <br>
  <br>
  <label for="id_icono">Nombbe Objeto:</label>
  <select id="id_icono" name="id_icono" onchange="updateDescripcion(this.value)">
    <option value="">Selecciona un objeto</option>
    <?php getNombreObjeto($conn); ?>
  </select>
  <br><br>
  <label for="search_nombre_categoria">Nombre de la categoría:</label>
  <input type="text" id="search_nombre_categoria" name="search_nombre_categoria" readonly>

  <br><br>

  <label for="search_descripcion_objeto">Descripción del objeto:</label>
  <input type="text" id="search_descripcion_objeto" name="search_descripcion_objeto" readonly>


  <div id="searchResult"></div>
  <h1>Lista de Categoria</h1>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>
</body>

</html>