<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_icono = $_POST['id_icono'];
  $nombre_objeto = $_POST['nombre_objeto'];
  $descripcion_objeto = $_POST['descripcion_objeto'];
  $id_categoria_objeto = $_POST['id_categoria_objeto'];

  // Validar la subida de archivos
  if (isset($_FILES['link_objeto']) && $_FILES['link_objeto']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['link_objeto']['tmp_name'];
    $fileName = $_FILES['link_objeto']['name'];
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    $allowedExtensions = ['png', 'svg'];
    if (in_array($fileExtension, $allowedExtensions)) {
      $uploadFileDir = 'uploads/';
      $dest_path = $uploadFileDir . $fileName;

      if (move_uploaded_file($fileTmpPath, $dest_path)) {
        $link_objeto = $dest_path;
      } else {
        echo "Error al mover el archivo.";
        exit;
      }
    } else {
      echo "Solo se permiten archivos PNG o SVG.";
      exit;
    }
  } else {
    echo "Error al subir el archivo.";
    exit;
  }

  $stmt = $conn->prepare("INSERT INTO tbl_iconos_objetos (id_icono, nombre_objeto, descripcion_objeto, id_categoria_objeto, link_objeto) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssis", $id_icono, $nombre_objeto, $descripcion_objeto, $id_categoria_objeto, $link_objeto);

  if ($stmt->execute()) {
    echo "Registro guardado correctamente";
  } else {
    echo "Error al guardar el registro: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>