<?php
include 'conexion.php';

if (isset($_GET['id_icono'])) {
  $id_icono = $conn->real_escape_string($_GET['id_icono']);


  $sql = "SELECT ico.descripcion_objeto, cat.nombre_categoria
            FROM tbl_iconos_objetos ico
            LEFT JOIN tbl_categoria_objetos cat ON ico.id_categoria_objeto = cat.id_categoria_objeto
            WHERE ico.id_icono = '$id_icono'";

  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // Obtener los datos
    $row = $result->fetch_assoc();
    echo json_encode($row);
  } else {

    echo json_encode([]);
  }
} else {
  echo json_encode(['error' => 'ID de icono no proporcionado']);
}

$conn->close();