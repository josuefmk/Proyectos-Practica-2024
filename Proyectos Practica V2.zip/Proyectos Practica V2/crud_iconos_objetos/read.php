<?php
include 'conexion.php';

// Obtener parámetros de búsqueda
$search_descripcion_objeto = isset($_GET['search_descripcion_objeto']) ? $_GET['search_descripcion_objeto'] : '';
$search_id_categoria_objeto = isset($_GET['search_id_categoria_objeto']) ? $_GET['search_id_categoria_objeto'] : '';
$search_nombre_objeto = isset($_GET['search_nombre_objeto']) ? $_GET['search_nombre_objeto'] : '';

// Consulta para mostrar la tabla
$sql = "SELECT ico.id_icono, ico.nombre_objeto, ico.descripcion_objeto, ico.id_categoria_objeto, ico.link_objeto, cat.nombre_categoria
        FROM tbl_iconos_objetos ico
        LEFT JOIN tbl_categoria_objetos cat ON ico.id_categoria_objeto = cat.id_categoria_objeto
        WHERE 1=1";

// Añadir condiciones de búsqueda
if ($search_descripcion_objeto !== '') {
  $sql .= " AND ico.descripcion_objeto LIKE '%" . $conn->real_escape_string($search_descripcion_objeto) . "%'";
}
if ($search_nombre_objeto !== '') {
  $sql .= " AND ico.nombre_objeto LIKE '%" . $conn->real_escape_string($search_nombre_objeto) . "%'";
}
if ($search_id_categoria_objeto !== '') {
  $sql .= " AND ico.id_categoria_objeto = '" . $conn->real_escape_string($search_id_categoria_objeto) . "'";
}

// Ejecutar la consulta
$result = $conn->query($sql);

// Mostrar resultados
if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Nombre Objeto</th>
                <th>Descripción Objeto</th>
                <th>ID Categoría Objeto</th>
                <th>Nombre Categoría</th>
                <th>Link Objeto</th>
                <th>Opciones</th>
            </tr>";

  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_icono']}'>
                <td>{$row['nombre_objeto']}</td>
                <td>{$row['descripcion_objeto']}</td>
                <td>{$row['id_categoria_objeto']}</td>
                <td>{$row['nombre_categoria']}</td>
                <td>{$row['link_objeto']}</td>
                <td>
                    <a href='update.php?id={$row['id_icono']}'>Editar</a>
                    <a href='javascript:void(0);' onclick='confirmDelete({$row['id_icono']});'>Eliminar</a>
                </td>
              </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$conn->close();
?>

<script>
// Confirmación de eliminación de un registro
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        console.log(response);
        if (response === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro.');
        }
      },
      error: function(xhr, status, error) {
        console.log(xhr.responseText);
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>