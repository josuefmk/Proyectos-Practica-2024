<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Categoría</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_icono = $conn->real_escape_string($_POST['id_icono']);
    $nombre_objeto = $conn->real_escape_string($_POST['nombre_objeto']);
    $descripcion_objeto = $conn->real_escape_string($_POST['descripcion_objeto']);
    if (isset($_FILES['link_objeto']) && $_FILES['link_objeto']['error'] == 0) {
      $target_dir = "uploads/";
      $target_file = $target_dir . basename($_FILES['link_objeto']['name']);
      $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

      // Comprobaciones de archivo
      $check = getimagesize($_FILES['link_objeto']['tmp_name']);
      if ($check !== false) {
        // Mover el archivo al directorio de destino
        if (move_uploaded_file($_FILES['link_objeto']['tmp_name'], $target_file)) {

          $link_objeto = $conn->real_escape_string($target_file);
          $sql = "UPDATE tbl_iconos_objetos SET id_icono='$id_icono', nombre_objeto='$nombre_objeto', descripcion_objeto='$descripcion_objeto', link_objeto='$link_objeto' WHERE id_icono=$id";

          if ($conn->query($sql)) {
            echo "<p class='success'>Registro actualizado correctamente.</p>";
          } else {
            echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
          }
        } else {
          echo "<p class='error'>Error al subir la imagen.</p>";
        }
      } else {
        echo "<p class='error'>El archivo no es una imagen.</p>";
      }
    } else {
      $sql = "UPDATE tbl_iconos_objetos SET id_icono='$id_icono', nombre_objeto='$nombre_objeto', descripcion_objeto='$descripcion_objeto' WHERE id_icono=$id";

      if ($conn->query($sql)) {
        echo "<p class='success'>Registro actualizado correctamente.</p>";
      } else {
        echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
      }
    }
  } else {
    $result = $conn->query("SELECT * FROM tbl_iconos_objetos WHERE id_icono=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Categoría</h1>
    <form method="POST" enctype="multipart/form-data">
      <label for="id_icono">ID Icono:</label>
      <input type="text" id="id_icono" name="id_icono" value="<?php echo htmlspecialchars($row['id_icono']); ?>"
        required>

      <label for="nombre_objeto">Nombre Objeto:</label>
      <input type="text" id="nombre_objeto" name="nombre_objeto"
        value="<?php echo htmlspecialchars($row['nombre_objeto']); ?>" required>

      <label for="descripcion_objeto">Descripción Objeto:</label>
      <input type="text" id="descripcion_objeto" name="descripcion_objeto"
        value="<?php echo htmlspecialchars($row['descripcion_objeto']); ?>" required>

      <label for="link_objeto">Cargar Objeto (Imagen/SVG):</label>
      <input type="file" id="link_objeto" name="link_objeto" accept="image/*">




      <input type="submit" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>