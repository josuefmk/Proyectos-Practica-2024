
$(document).ready(function () {

    function loadRecords() {
        fetch('read.php')
            .then(response => response.text())
            .then(data => {
                document.getElementById('result').innerHTML = data;
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }


    $('#ObjetoForm').submit(function (e) {
        e.preventDefault();

        const formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                $('#result').html('<p class="success">Objeto agregado exitosamente.</p>');
                loadRecords();
                $('#ObjetoForm')[0].reset();
            },
            error: function () {
                $('#result').html('<p class="error">Error al agregar objeto.</p>');
            }
        });
    });
    $('#toggleFormBtn').click(function () {
        $('#ObjetoFormContainer').toggle();
    });


    loadRecords();
});


//Formulario agregar
   $(document).ready(function () {
      $('#ObjetoForm').submit(function (e) {
        e.preventDefault();

        $.ajax({
          type: $(this).attr('method'),
          url: $(this).attr('action'),
          data: $(this).serialize(),
          success: function (response) {
            $('#result').html('<p class="success">Categoria  agregado exitosamente.</p>');
            location.reload();
          },
          error: function () {
            $('#result').html('<p class="error">Error al agregar Categoria.</p>');
          }
        });
      });

      $('#searchForm').submit(function (e) {
        e.preventDefault();
        if (validarBusqueda()) {
          $.ajax({
            type: 'GET',
            url: 'read.php',
            data: $(this).serialize(),
            success: function (response) {
              $('#searchResult').html(response);
            },
            error: function () {
              $('#searchResult').html('<p class="error">Error al buscar Categoria.</p>');
            }
          });
        } else {
          alert('Por favor, ingresa al menos un dato para buscar.');
        }
      });

     // Validar Busqueda
      function validarBusqueda() {
        const NombreObjeto = $('#search_nombre_objeto').val().trim();
        const NombreCategoria = $('#search_nombre_categoria').val().trim();
        const IDIcono = $('#search_id_icono').val().trim();
        const IDCategoria = $('#search_id_categoria_objeto').val().trim();
        return NombreObjeto !== '' || NombreCategoria !== '' || IDIcono !== '' || IDCategoria !== ''



      }

      $('#searchDateForm').submit(function (e) {
        e.preventDefault();
        if (validarFecha()) {
          $.ajax({
            type: 'GET',
            url: 'read.php',
            data: $(this).serialize(),
            success: function (response) {
              $('#searchResult').html(response);
            },
            error: function () {
              $('#searchResult').html('<p class="error">Error al buscar Categoria.</p>');
            }
          });
        } else {
          alert('Por favor, selecciona una fecha para buscar.');
        }
      });



      //Formulario Agregar para que se oculte y aparezca
      document.getElementById("toggleFormBtn").addEventListener("click", function () {
        const formContainer = document.getElementById("CategoriaFormContainer");

        if (formContainer.style.display === "none" || formContainer.style.display === "") {
          formContainer.style.display = "block";
        } else {
          formContainer.style.display = "none";
        }
      });


   });

function updateDescripcion(id_icono) {
    if (id_icono === "") {

        $('#search_nombre_categoria').val('');
        $('#search_descripcion_objeto').val('');
        return;
    }

    $.ajax({
        url: 'get_objeto_data.php',
        type: 'GET',
        data: { id_icono: id_icono },
        success: function(response) {

            var data = JSON.parse(response);

            if (data.nombre_categoria && data.descripcion_objeto) {

                $('#search_nombre_categoria').val(data.nombre_categoria);
                $('#search_descripcion_objeto').val(data.descripcion_objeto);
            } else {

                $('#search_nombre_categoria').val('');
                $('#search_descripcion_objeto').val('');
            }
        },
        error: function(xhr, status, error) {
            console.error('Error en la solicitud:', error);
        }
    });
}


