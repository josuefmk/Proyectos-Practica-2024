<?php
include 'conexion.php';



// Función para obtener las opciones de categorías
function getCategorias($conn)
{
  $sql = "SELECT id_categoria_objeto, nombre_categoria FROM tbl_categoria_objetos";
  $result = $conn->query($sql);
  $options = '';

  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $options .= "<option value='" . $row['id_categoria_objeto'] . "'>" . $row['nombre_categoria'] . "</option>";
    }
  } else {
    $options .= "<option value=''>No hay categorías disponibles</option>";
  }

  return $options;
}


function getObjetoData($id_icono, $conn)
{

  $id_icono = $conn->real_escape_string($id_icono);


  $sql = "SELECT ico.descripcion_objeto, cat.nombre_categoria
            FROM tbl_iconos_objetos ico
            LEFT JOIN tbl_categoria_objetos cat ON ico.id_categoria_objeto = cat.id_categoria_objeto
            WHERE ico.id_icono = '$id_icono'";


  $result = $conn->query($sql);


  if ($result->num_rows > 0) {

    return $result->fetch_assoc();
  } else {

    return [];
  }
}