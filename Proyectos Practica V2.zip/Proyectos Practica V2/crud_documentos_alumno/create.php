<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = $_POST['nombre'];
  $id_usuario = $_POST['id_usuario'];

  // Manejo de archivo
  $file = $_FILES['documento'];
  $tipoArchivo = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

  $timestamp = time();
  $nombreArchivo = $timestamp . '_' . basename($file['name']);
  $rutaArchivo = 'uploads/' . $nombreArchivo;

  $tiposPermitidos = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf'];
  if (!in_array($tipoArchivo, $tiposPermitidos)) {
    echo json_encode(["success" => false, "message" => "Tipo de archivo no permitido."]);
    exit;
  }

  if (file_exists($rutaArchivo)) {
    echo json_encode(["success" => false, "message" => "El archivo ya existe. Por favor, sube otro archivo."]);
    exit;
  }

  $tamañoArchivo = $file['size'];

  $identificador = bin2hex(random_bytes(16));

  if (move_uploaded_file($file['tmp_name'], $rutaArchivo)) {

    $stmt = $conn->prepare("INSERT INTO tbl_documentos_alumno (nombre, type, size, identificador, id_usuario, fecha_creacion) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssisi", $nombre, $tipoArchivo, $tamañoArchivo, $identificador, $id_usuario);

    if ($stmt->execute()) {
      echo json_encode(["success" => true, "message" => "Documento subido exitosamente."]);
    } else {
      echo json_encode(["success" => false, "message" => "Error al insertar el documento en la base de datos."]);
    }
    $stmt->close();
  } else {
    echo json_encode(["success" => false, "message" => "Error al subir el archivo."]);
  }
}
?>