<?php
include 'conexion.php';

// Consulta para obtener los documentos con su identificador
$sql = "SELECT nombre, link FROM tbl_documentos_alumno";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <script src="Ajax.js" defer></script>
  <title>CRUD Documentos Alumno</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>

  <button id="toggleFormBtn">Agregar Documento Alumno</button>
  <div class="form-container-add" id="DAlumnoFormContainer">
    <form id="DAlumnoForm" method="post" action="create.php" enctype="multipart/form-data">
      <h2>Subir Documento</h2>
      <label for="nombre">Nombre:</label>
      <input type="text" name="nombre" required><br><br>
      <label for="id_usuario">ID Usuario:</label>
      <input type="number" name="id_usuario" required><br><br>
      <label for="documento">Documento:</label>
      <input type="file" name="documento" accept=".doc,.docx,.xls,.xlsx,.ppt,.pptx,.pdf" required><br><br>
      <input type="submit" value="Subir Documento">
    </form>
  </div>
  <br><br>

  <label for="search_nombre">Nombre:</label>
  <select id="search_nombre" name="search_nombre" onchange="updateLink()">
    <option value="">Selecciona un documento</option>
    <?php
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<option value='" . htmlspecialchars($row['link']) . "'>" . htmlspecialchars($row['nombre']) . "</option>";
      }
    }
    ?>
  </select>
  <br><br>

  <label for="search_link">Link:</label>
  <input type="text" id="search_link" name="search_link" readonly onclick="openLink()"
    style="cursor: pointer; color: blue; text-decoration: underline;">

  <?php
  if (isset($_GET['error'])) {
    if ($_GET['error'] === 'tipo_archivo_no_permitido') {
      echo "<div class='error'>Tipo de archivo no permitido.</div>";
    } else {
      echo "<div class='error'>Error al subir el documento. Inténtalo de nuevo.</div>";
    }
  }
  ?>

  <div id="result"></div>

  <?php include 'read.php'; ?>



</body>

</html>