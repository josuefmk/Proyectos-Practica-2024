<?php
include 'conexion.php';

$sql = "SELECT * FROM tbl_documentos_alumno";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
  echo "<h2>Documentos Subidos</h2>";
  echo "<table>";
  echo "<thead>
            <tr>
              <th>Nombre</th>
              <th>Tipo</th>
              <th>Tamaño (KB)</th>
              <th>Enlace</th>
              <th>Fecha</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>";

  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-" . $row['id_documento'] . "'>";
    echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
    echo "<td>" . htmlspecialchars($row['type']) . "</td>";
    echo "<td>" . round($row['size'] / 1024, 2) . "</td>";
    echo "<td><a href='" . htmlspecialchars($row['link']) . "' target='_blank'>Ver Documento</a></td>";
    echo "<td>" . htmlspecialchars($row['fecha_creacion']) . "</td>";
    echo "<td class='actions'><a href='update.php?id=" . $row['id_documento'] . "'>Editar</a></td>";
    echo "<td class='actions'> <a href='javascript:void(0);' onclick='confirmDelete(" . $row['id_documento'] . ");'>Eliminar</a></td>";
    echo "</tr>";
  }
  echo "</tbody></table>";
} else {
  echo "<tr><td colspan='5'>No hay documentos subidos.</td></tr>";
}
?>
<script>
  // Confirmación de eliminación de un registro
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id: id
        },
        success: function (response) {
          if (response === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('El registro ha sido eliminado exitosamente.');
          } else {
            alert('Error al eliminar el registro: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }
</script>