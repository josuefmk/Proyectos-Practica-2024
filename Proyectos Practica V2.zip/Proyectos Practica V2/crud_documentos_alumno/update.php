<?php
// Archivo: update.php
include 'conexion.php'; // Incluir conexión a la base de datos

$id_documento = $_GET['id'];
$sql = "SELECT * FROM tbl_documentos_alumno WHERE id_documento = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_documento);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = $_POST['nombre'];
  $id_usuario = $_POST['id_usuario'];

  // Manejo del archivo subido
  $archivo_subido = $_FILES['archivo']['name'];
  $ruta_destino = "uploads/" . basename($archivo_subido);

  if (move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta_destino)) {

    $sql = "UPDATE tbl_documentos_alumno SET nombre=?, id_usuario=?, archivo=? WHERE id_documento=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $nombre, $id_usuario, $archivo_subido, $id_documento);

    if ($stmt->execute()) {
      echo "<script>alert('Documento actualizado exitosamente.'); window.location.href='index.php';</script>";
    } else {
      echo "Error: " . $stmt->error;
    }
  } else {
    echo "Error al subir el archivo.";
  }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Documento</title>
</head>

<body>
  <div class="form-container">
    <h1>Actualizar Documento</h1>
    <form method="POST" action="update.php?id=<?php echo $id_documento; ?>" enctype="multipart/form-data">
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($row['nombre']); ?>" required>

      <label for="id_usuario">ID Usuario:</label>
      <input type="number" id="id_usuario" name="id_usuario" value="<?php echo htmlspecialchars($row['id_usuario']); ?>"
        required>

      <label for="archivo">Archivo a Modificar:</label>
      <input type="file" id="archivo" name="archivo" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
      <br>

      <input type="submit" value="Actualizar Documento">
    </form>
  </div>
  <br>
  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>