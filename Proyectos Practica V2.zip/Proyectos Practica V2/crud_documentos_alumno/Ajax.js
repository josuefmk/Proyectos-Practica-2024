// Función para cargar registros
function loadRecords() {
    fetch('read.php')
        .then(response => response.text())
        .then(data => {
            document.getElementById('tableContainer').innerHTML = data;
        })
        .catch(error => {
            console.error('Error al cargar los registros:', error);
        });
}

// Manejo del formulario de carga de documentos
document.getElementById('DAlumnoForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('create.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('result');
        resultDiv.innerHTML = data.message;

        if (data.success) {
            document.getElementById('DAlumnoForm').reset();
            loadRecords();
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});


document.addEventListener('DOMContentLoaded', loadRecords);




  // Manejador para mostrar/ocultar el formulario
  document.getElementById("toggleFormBtn").addEventListener("click", function () {
    const formContainer = document.getElementById("DAlumnoFormContainer");
    formContainer.style.display = formContainer.style.display === "none" || formContainer.style.display === "" ? "block" : "none";
  });

  function updateLink() {
  const select = document.getElementById('search_nombre');
  const linkInput = document.getElementById('search_link');
  linkInput.value = select.value;

  // Mostrar el botón solo si hay un enlace
  const viewDocBtn = document.getElementById('viewDocBtn');
  viewDocBtn.style.display = select.value ? 'inline' : 'none';
}

function openLink() {
  const linkInput = document.getElementById('search_link');
  const link = linkInput.value;
  if (link) {
    window.open(link, '_blank');
  }
}

