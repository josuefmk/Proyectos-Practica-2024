<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['fecha_inicio']) && isset($_GET['fecha_inicio'])) {
  $fecha_inicio = $_GET['fecha_inicio'];

} else {
  $fecha_inicio = "";
}
$id_centroingreso = isset($_GET['id_centroingreso']) ? $_GET['id_centroingreso'] : "";
$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : "";

$sql = "
    SELECT
        ci.id_centroingreso,
        ci.nombre
    FROM
        tbl_centrosdeingreso ci
    JOIN
        tbl_cursos c ON c.id_centronegocio = ci.id_centroingreso
";

$result = $conn->query($sql);
$centros = [];
if ($result) {
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $centros[] = $row;
    }
  }
}
$fecha_inicioOptions = '';
$rut_profesorOptions = '';
$centronegocioOptions = '';


$result_fecha_inicio = $conn->query("SELECT DISTINCT fecha_inicio FROM tbl_cursos");
while ($row = $result_fecha_inicio->fetch_assoc()) {
  $fecha_inicioOptions .= "<option value='{$row['fecha_inicio']}'>{$row['fecha_inicio']}</option>";
}

$result_rut_profesor = $conn->query("SELECT DISTINCT rut_profesor FROM tbl_cursos");
while ($row = $result_rut_profesor->fetch_assoc()) {
  $rut_profesorOptions .= "<option value='{$row['rut_profesor']}'>{$row['rut_profesor']}</option>";
}

$result_id_centronegocio = $conn->query("SELECT DISTINCT id_centronegocio FROM tbl_cursos");
while ($row = $result_id_centronegocio->fetch_assoc()) {
  $centronegocioOptions .= "<option value='{$row['id_centronegocio']}'>{$row['id_centronegocio']}</option>";
}


?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Cursos</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Curso</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Curso</h2>

      <label for="id_curso">ID Curso:</label>
      <input type="number" id="id_curso" name="id_curso" required>

      <label for="id_centronegocio">Centro Ingreso:</label>
      <select id="id_centronegocio" name="id_centronegocio" required>
        <option value="">Seleccione un Centro</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_centroingreso'] == $id_centroingreso) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_centroingreso']) . "' $selected>" . htmlspecialchars($centro['nombre']) . "</option>";
        }
        ?>
      </select>


      <label for="rut_profesor">Rut Profesor:</label>
      <input type="text" id="rut_profesor" name="rut_profesor" required>

      <label for="codigo">Código:</label>
      <input type="text" id="codigo" name="codigo" required>

      <label for="modalidad">Modalidad:</label>
      <select id="modalidad" name="modalidad" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="0">Presencial</option>
        <option value="1">SemiPresencial</option>
        <option value="2">Virtual</option>
      </select>
      <label for="dias_clases">Dia de Clases:</label>
      <div class="dias-frecuencia">
        <label><input type="checkbox" name="dias_clases[]" value="1"> Lunes</label>
        <label><input type="checkbox" name="dias_clases[]" value="2"> Martes</label>
        <label><input type="checkbox" name="dias_clases[]" value="3"> Miércoles</label>
        <label><input type="checkbox" name="dias_clases[]" value="4"> Jueves</label>
        <label><input type="checkbox" name="dias_clases[]" value="5"> Viernes</label>
        <label><input type="checkbox" name="dias_clases[]" value="6"> Sábado</label>
      </div>


      <label for="hora_desde" class="label-hora">Hora Desde:</label>
      <input type="time" id="hora_desde" name="hora_desde" class="input-time" required>

      <label for="hora_hasta" class="label-hora">Hora Hasta:</label>
      <input type="time" id="hora_hasta" name="hora_hasta" class="input-time" required>

      <label for="fecha_inicio">Fecha Inicio:</label>
      <input type="date" id="fecha_inicio" name="fecha_inicio" class="input-time"
        value="<?php echo htmlspecialchars($fecha_inicio); ?>" required>
      <label for="sw_matriculas">Sw Matrículas:</label>
      <input type="number" id="sw_matriculas" name="sw_matriculas" required>

      <label for="precio">Precio:</label>
      <input type="number" id="precio" name="precio" required>

      <label for="valor_matricula">Valor Matrícula:</label>
      <input type="number" id="valor_matricula" name="valor_matricula" required>

      <label for="precio_sabado">Precio Sábado:</label>
      <input type="number" id="precio_sabado" name="precio_sabado" required>

      <label for="horas_totales">Horas Totales:</label>
      <input type="number" id="horas_totales" name="horas_totales" required>

      <label for="estado">Estado:</label>
      <input type="text" id="estado" name="estado" required>

      <label for="empresa">Empresa:</label>
      <input type="text" id="empresa" name="empresa">

      <label for="contacto">Contacto:</label>
      <input type="text" id="contacto" name="contacto">

      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo">

      <label for="rut_empresa">Rut Empresa:</label>
      <input type="text" id="rut_empresa" name="rut_empresa">

      <label for="telefono_empresa">Teléfono Empresa:</label>
      <input type="text" id="telefono_empresa" name="telefono_empresa">

      <label for="rut_supervisor">Rut Supervisor:</label>
      <input type="text" id="rut_supervisor" name="rut_supervisor">

      <label for="telefono_supervisor">Teléfono Supervisor:</label>
      <input type="text" id="telefono_supervisor" name="telefono_supervisor">

      <label for="valor_hora_relator">Valor Hora Relator:</label>
      <input type="number" id="valor_hora_relator" name="valor_hora_relator">

      <label for="max_alumnos">Máx Alumnos:</label>
      <input type="number" id="max_alumnos" name="max_alumnos" required>

      <label for="tipo_curso">Tipo Curso:</label>
      <select id="tipo_curso" name="tipo_curso" class="form-control" required>
        <option value="">-- Seleccionar --</option>
        <option value="0">Abierto</option>
        <option value="1">Cerrado</option>
      </select>

      <label for="ultima_modificacion">Última Modificación:</label>
      <input type="datetime-local" id="ultima_modificacion" name="ultima_modificacion" required>

      <label for="imagen">Imagen:</label>
      <input type="text" id="imagen" name="imagen">

      <label for="color">Color:</label>
      <input type="text" id="color" name="color">

      <label for="alias">Alias:</label>
      <input type="text" id="alias" name="alias">

      <label for="pass_unico">Pass Único:</label>
      <input type="text" id="pass_unico" name="pass_unico">

      <label for="curso_online">Curso Online:</label>
      <input type="text" id="curso_online" name="curso_online">

      <label for="sala">Sala:</label>
      <input type="text" id="sala" name="sala">

      <input type="submit" value="Agregar Operación" class="btn" onclick="showModal()">
      <div id="successModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <p>¡Matrícula agregado exitosamente!</p>
        </div>
      </div>
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_dias_clases">Días de Clase:</label>
    <select id="search_dias_clases" name="search_dias_clases">
      <option value="">Seleccionar un Día</option>
      <option value="1">Lunes</option>
      <option value="2">Martes</option>
      <option value="3">Miércoles</option>
      <option value="4">Jueves</option>
      <option value="5">Viernes</option>
      <option value="6">Sábado</option>
    </select>

    <label for="search_fecha_inicio">Fecha Inicio:</label>
    <select id="search_fecha_inicio" name="search_fecha_inicio">
      <option value="">Seleccione Fecha</option>
      <?php echo $fecha_inicioOptions; ?>
    </select>

    <label for="search_rut_profesor">RUT Profesor:</label>
    <select id="search_rut_profesor" name="search_rut_profesor">
      <option value="">Seleccione un RUT</option>
      <?php echo $rut_profesorOptions; ?>
    </select>

    <label for="search_id_centronegocio">Código:</label>
    <select id="search_id_centronegocio" name="search_id_centronegocio">
      <option value="">Seleccione un Centro</option>
      <?php echo $centronegocioOptions; ?>
    </select>

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });

      // Limpiar filtros
      $('#clearFilterBtn').click(function () {
        $('#searchForm')[0].reset();
        $('#result').empty();
      });
    });

    function showModal() {
      document.getElementById('successModal').style.display = 'block';
    }

    function closeModal() {
      document.getElementById('successModal').style.display = 'none';
    }
    window.onclick = function (event) {
      const modal = document.getElementById('successModal');
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    }
  </script>
</body>