<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Recoger los datos desde el formulario
  $id_centronegocio = $_POST['id_centronegocio'];
  $rut_profesor = $_POST['rut_profesor'];
  $codigo = $_POST['codigo'];
  $modalidad = $_POST['modalidad'];

  $hora_desde = $_POST['hora_desde'];
  $hora_hasta = $_POST['hora_hasta'];
  $fecha_inicio = $_POST['fecha_inicio'];
  $sw_matriculas = $_POST['sw_matriculas'];
  $precio = $_POST['precio'];
  $valor_matricula = $_POST['valor_matricula'];
  $precio_sabado = $_POST['precio_sabado'];
  $horas_totales = $_POST['horas_totales'];
  $estado = $_POST['estado'];
  $empresa = !empty($_POST['empresa']) ? $_POST['empresa'] : null;
  $contacto = !empty($_POST['contacto']) ? $_POST['contacto'] : null;
  $correo = !empty($_POST['correo']) ? $_POST['correo'] : null;
  $rut_empresa = !empty($_POST['rut_empresa']) ? $_POST['rut_empresa'] : null;
  $telefono_empresa = !empty($_POST['telefono_empresa']) ? $_POST['telefono_empresa'] : null;
  $rut_supervisor = !empty($_POST['rut_supervisor']) ? $_POST['rut_supervisor'] : null;
  $telefono_supervisor = !empty($_POST['telefono_supervisor']) ? $_POST['telefono_supervisor'] : null;
  $codigo_sence = !empty($_POST['codigo_sence']) ? $_POST['codigo_sence'] : null;
  $valor_hora_relator = !empty($_POST['valor_hora_relator']) ? $_POST['valor_hora_relator'] : null;
  $max_alumnos = $_POST['max_alumnos'];
  $tipo_curso = $_POST['tipo_curso'];
  $ultima_modificacion = $_POST['ultima_modificacion'];
  $imagen = !empty($_POST['imagen']) ? $_POST['imagen'] : null;
  $color = !empty($_POST['color']) ? $_POST['color'] : null;
  $alias = !empty($_POST['alias']) ? $_POST['alias'] : null;
  $pass_unico = !empty($_POST['pass_unico']) ? $_POST['pass_unico'] : null;
  $curso_online = !empty($_POST['curso_online']) ? $_POST['curso_online'] : null;
  $sala = !empty($_POST['sala']) ? $_POST['sala'] : null;

  if (isset($_POST['dias_clases'])) {
    $dias_clases = implode(',', $_POST['dias_clases']);
  } else {
    $dias_clases = '';
  }

  $stmt = $conn->prepare("INSERT INTO tbl_cursos(id_centronegocio, rut_profesor, codigo, modalidad, dias_clases, hora_desde, hora_hasta, fecha_inicio, sw_matriculas, precio, valor_matricula, precio_sabado, horas_totales, estado, empresa, contacto, correo, rut_empresa, telefono_empresa, rut_supervisor, telefono_supervisor, codigo_sence, valor_hora_relator, max_alumnos, tipo_curso, ultima_modificacion, imagen, color, alias, pass_unico, curso_online, sala) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param(
    "sssssssssssssssssssssssssssssssssss",
    $id_centronegocio,
    $rut_profesor,
    $codigo,
    $modalidad,
    $dias_clases,
    $hora_desde,
    $hora_hasta,
    $fecha_inicio,
    $sw_matriculas,
    $precio,
    $valor_matricula,
    $precio_sabado,
    $horas_totales,
    $estado,
    $empresa,
    $contacto,
    $correo,
    $rut_empresa,
    $telefono_empresa,
    $rut_supervisor,
    $telefono_supervisor,
    $codigo_sence,
    $valor_hora_relator,
    $max_alumnos,
    $tipo_curso,
    $ultima_modificacion,
    $imagen,
    $color,
    $alias,
    $pass_unico,
    $curso_online,
    $sala
  );

  // Ejecutar la consulta
  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el curso: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>