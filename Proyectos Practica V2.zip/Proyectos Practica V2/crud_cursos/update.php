<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Operación</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_curso'])) {
    $id = $_GET['id_curso'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $id_centronegocio = $conn->real_escape_string($_POST['id_centronegocio']);
    $rut_profesor = $conn->real_escape_string($_POST['rut_profesor']);
    $codigo = $conn->real_escape_string($_POST['codigo']);
    $modalidad = $conn->real_escape_string($_POST['modalidad']);
    $dias_clases = $conn->real_escape_string($_POST['dias_clases']);
    $hora_desde = $conn->real_escape_string($_POST['hora_desde']);
    $hora_hasta = $conn->real_escape_string($_POST['hora_hasta']);
    $fecha_inicio = $conn->real_escape_string($_POST['fecha_inicio']);
    $sw_matriculas = $conn->real_escape_string($_POST['sw_matriculas']);
    $precio = $conn->real_escape_string($_POST['precio']);
    $valor_matricula = $conn->real_escape_string($_POST['valor_matricula']);
    $precio_sabado = $conn->real_escape_string($_POST['precio_sabado']);
    $horas_totales = $conn->real_escape_string($_POST['horas_totales']);
    $estado = $conn->real_escape_string($_POST['estado']);
    $empresa = $conn->real_escape_string($_POST['empresa']);
    $contacto = $conn->real_escape_string($_POST['contacto']);
    $codicorreogo = $conn->real_escape_string($_POST['correo']);
    $rut_empresa = $conn->real_escape_string($_POST['rut_empresa']);
    $telefono_empresa = $conn->real_escape_string($_POST['telefono_empresa']);
    $rut_supervisor = $conn->real_escape_string($_POST['rut_supervisor']);
    $telefono_supervisor = $conn->real_escape_string($_POST['telefono_supervisor']);
    $codigo_sence = $conn->real_escape_string($_POST['codigo_sence']);
    $valor_hora_relator = $conn->real_escape_string($_POST['valor_hora_relator']);
    $max_alumnos = $conn->real_escape_string($_POST['max_alumnos']);
    $tipo_curso = $conn->real_escape_string($_POST['tipo_curso']);
    $ultima_modificacion = $conn->real_escape_string($_POST['ultima_modificacion']);
    $imagen = $conn->real_escape_string($_POST['imagen']);
    $color = $conn->real_escape_string($_POST['color']);
    $alias = $conn->real_escape_string($_POST['alias']);
    $pass_unico = $conn->real_escape_string($_POST['pass_unico']);
    $curso_online = $conn->real_escape_string($_POST['curso_online']);
    $sala = $conn->real_escape_string($_POST['sala']);

    // Consulta para actualizar el registro
    $sql = "UPDATE tbl_cursos
        SET id_subclase='$id_subclase',
            estado='$estado',
            usuario_creacion='$usuario_creacion',
            time_creacion='$time_creacion',
            codigo='$codigo',
            modalidad='$modalidad',
            dias_clases='$dias_clases',
            hora_desde='$hora_desde',
            hora_hasta='$hora_hasta',
            fecha_inicio='$fecha_inicio',
            sw_matriculas='$sw_matriculas',
            precio='$precio',
            valor_matricula='$valor_matricula',
            precio_sabado='$precio_sabado',
            horas_totales='$horas_totales',
            empresa='$empresa',
            contacto='$contacto',
            codicorreogo='$codicorreogo',
            rut_empresa='$rut_empresa',
            telefono_empresa='$telefono_empresa',
            rut_supervisor='$rut_supervisor',
            telefono_supervisor='$telefono_supervisor',
            codigo_sence='$codigo_sence',
            valor_hora_relator='$valor_hora_relator',
            max_alumnos='$max_alumnos',
            tipo_curso='$tipo_curso',
            ultima_modificacion='$ultima_modificacion',
            imagen='$imagen',
            color='$color',
            alias='$alias',
            pass_unico='$pass_unico',
            curso_online='$curso_online',
            sala='$sala'
        WHERE id_curso='$id'";
    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_cursos WHERE id_curso=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Centro de Ingreso</h1>
    <form method="POST">
      <label for="id_subclase">ID Subclase:</label>
      <input type="number" id="id_subclase" name="id_subclase"
        value="<?php echo htmlspecialchars($row['id_subclase'] ?? ''); ?>" required>

      <label for="estado">Estado:</label>
      <input type="number" id="estado" name="estado" value="<?php echo htmlspecialchars($row['estado'] ?? ''); ?>"
        required>

      <label for="usuario_creacion">Usuario Creación:</label>
      <input type="number" id="usuario_creacion" name="usuario_creacion"
        value="<?php echo htmlspecialchars($row['usuario_creacion'] ?? ''); ?>" required>

      <label for="time_creacion">Time Creación:</label>
      <input type="number" id="time_creacion" name="time_creacion"
        value="<?php echo htmlspecialchars($row['time_creacion'] ?? ''); ?>" required>

      <label for="codigo">Código:</label>
      <input type="text" id="codigo" name="codigo" value="<?php echo htmlspecialchars($row['codigo'] ?? ''); ?>"
        required>

      <label for="modalidad">Modalidad:</label>
      <input type="text" id="modalidad" name="modalidad"
        value="<?php echo htmlspecialchars($row['modalidad'] ?? ''); ?>" required>

      <label for="dias_clases">Días Clases:</label>
      <input type="text" id="dias_clases" name="dias_clases"
        value="<?php echo htmlspecialchars($row['dias_clases'] ?? ''); ?>" required>

      <label for="hora_desde " class="label-hora">Hora Desde:</label>
      <input type="time" id="hora_desde" name="hora_desde" class="input-time"
        value="<?php echo htmlspecialchars($row['hora_desde'] ?? ''); ?>" required>

      <label for="hora_hasta" class="label-hora">Hora Hasta:</label>
      <input type="time" id="hora_hasta" name="hora_hasta" class="input-time"
        value="<?php echo htmlspecialchars($row['hora_hasta'] ?? ''); ?>" required>

      <label for="fecha_inicio">Fecha Inicio:</label>
      <input type="date" id="fecha_inicio" name="fecha_inicio" class="input-time"
        value="<?php echo htmlspecialchars($row['fecha_inicio'] ?? ''); ?>" required>

      <label for="sw_matriculas">SW Matrículas:</label>
      <input type="text" id="sw_matriculas" name="sw_matriculas"
        value="<?php echo htmlspecialchars($row['sw_matriculas'] ?? ''); ?>">

      <label for="precio">Precio:</label>
      <input type="number" id="precio" name="precio" value="<?php echo htmlspecialchars($row['precio'] ?? ''); ?>">

      <label for="valor_matricula">Valor Matrícula:</label>
      <input type="number" id="valor_matricula" name="valor_matricula"
        value="<?php echo htmlspecialchars($row['valor_matricula'] ?? ''); ?>">

      <label for="precio_sabado">Precio Sábado:</label>
      <input type="number" id="precio_sabado" name="precio_sabado"
        value="<?php echo htmlspecialchars($row['precio_sabado'] ?? ''); ?>">

      <label for="horas_totales">Horas Totales:</label>
      <input type="number" id="horas_totales" name="horas_totales"
        value="<?php echo htmlspecialchars($row['horas_totales'] ?? ''); ?>">

      <label for="empresa">Empresa:</label>
      <input type="text" id="empresa" name="empresa" value="<?php echo htmlspecialchars($row['empresa'] ?? ''); ?>">

      <label for="contacto">Contacto:</label>
      <input type="text" id="contacto" name="contacto" value="<?php echo htmlspecialchars($row['contacto'] ?? ''); ?>">

      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($row['codicorreogo'] ?? ''); ?>">

      <label for="rut_empresa">RUT Empresa:</label>
      <input type="text" id="rut_empresa" name="rut_empresa"
        value="<?php echo htmlspecialchars($row['rut_empresa'] ?? ''); ?>">

      <label for="telefono_empresa">Teléfono Empresa:</label>
      <input type="tel" id="telefono_empresa" name="telefono_empresa"
        value="<?php echo htmlspecialchars($row['telefono_empresa'] ?? ''); ?>">

      <label for="rut_supervisor">RUT Supervisor:</label>
      <input type="text" id="rut_supervisor" name="rut_supervisor"
        value="<?php echo htmlspecialchars($row['rut_supervisor'] ?? ''); ?>">

      <label for="telefono_supervisor">Teléfono Supervisor:</label>
      <input type="tel" id="telefono_supervisor" name="telefono_supervisor"
        value="<?php echo htmlspecialchars($row['telefono_supervisor'] ?? ''); ?>">

      <label for="valor_hora_relator">Valor Hora Relator:</label>
      <input type="number" id="valor_hora_relator" name="valor_hora_relator"
        value="<?php echo htmlspecialchars($row['valor_hora_relator'] ?? ''); ?>">

      <label for="max_alumnos">Máx. Alumnos:</label>
      <input type="number" id="max_alumnos" name="max_alumnos"
        value="<?php echo htmlspecialchars($row['max_alumnos'] ?? ''); ?>">

      <label for="tipo_curso">Tipo Curso:</label>
      <input type="text" id="tipo_curso" name="tipo_curso"
        value="<?php echo htmlspecialchars($row['tipo_curso'] ?? ''); ?>">

      <label for="ultima_modificacion">Última Modificación:</label>
      <input type="text" id="ultima_modificacion" name="ultima_modificacion"
        value="<?php echo htmlspecialchars($row['ultima_modificacion'] ?? ''); ?>">

      <label for="imagen">Imagen:</label>
      <input type="text" id="imagen" name="imagen" value="<?php echo htmlspecialchars($row['imagen'] ?? ''); ?>">

      <label for="color">Color:</label>
      <input type="text" id="color" name="color" value="<?php echo htmlspecialchars($row['color'] ?? ''); ?>">

      <label for="alias">Alias:</label>
      <input type="text" id="alias" name="alias" value="<?php echo htmlspecialchars($row['alias'] ?? ''); ?>">

      <label for="pass_unico">Pass Único:</label>
      <input type="text" id="pass_unico" name="pass_unico"
        value="<?php echo htmlspecialchars($row['pass_unico'] ?? ''); ?>">

      <label for="curso_online">Curso Online:</label>
      <input type="text" id="curso_online" name="curso_online"
        value="<?php echo htmlspecialchars($row['curso_online'] ?? ''); ?>">

      <label for="sala">Sala:</label>
      <input type="text" id="sala" name="sala" value="<?php echo htmlspecialchars($row['sala'] ?? ''); ?>">

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>