<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['id_centroingreso'])) {
    $id = $_POST['id_curso'];

    $stmt = $conn->prepare("DELETE FROM tbl_cursos WHERE id_curso = ?");
    if ($stmt === false) {
      echo "Error en la preparación de la consulta: " . $conn->error;
      exit;
    }
    $stmt->bind_param("i", $id);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
      echo "success";
    } else {
      echo "Error al eliminar : " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
  } else {
    echo "ID no está.";
  }
} else {
  echo "Método de solicitud no válido.";
}
?>