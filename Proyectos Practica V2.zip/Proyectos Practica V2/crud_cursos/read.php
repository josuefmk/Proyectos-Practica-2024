<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_dias_clases = isset($_GET['search_dias_clases']) ? $_GET['search_dias_clases'] : '';
$search_fecha_inicio = isset($_GET['search_fecha_inicio']) ? $_GET['search_fecha_inicio'] : '';
$search_rut_profesor = isset($_GET['search_rut_profesor']) ? $_GET['search_rut_profesor'] : '';
$search_id_centronegocio = isset($_GET['search_id_centronegocio']) ? $_GET['search_id_centronegocio'] : '';

// Configuración de días de la semana
$dias_semana = [
  1 => 'Lunes',
  2 => 'Martes',
  3 => 'Miércoles',
  4 => 'Jueves',
  5 => 'Viernes',
  6 => 'Sábado',
];

$query = "SELECT id_curso, id_centronegocio, rut_profesor, codigo, modalidad, dias_clases, hora_desde, hora_hasta, fecha_inicio, sw_matriculas, precio, valor_matricula, precio_sabado, horas_totales, estado, empresa, contacto, correo, rut_empresa, telefono_empresa, rut_supervisor, telefono_supervisor, codigo_sence, valor_hora_relator, max_alumnos, tipo_curso, ultima_modificacion, imagen, color, alias, pass_unico, curso_online, sala FROM tbl_cursos WHERE 1=1";

$types = '';
$params = [];

// Agregar filtros de búsqueda
if (!empty($search_dias_clases)) {
  $query .= " AND FIND_IN_SET(?, dias_clases) > 0";
  $types .= 'i';
  $params[] = $search_dias_clases;
}

if (!empty($search_fecha_inicio)) {
  $query .= " AND fecha_inicio = ?";
  $types .= 's';
  $params[] = $search_fecha_inicio;
}

if (!empty($search_rut_profesor)) {
  $query .= " AND rut_profesor = ?";
  $types .= 's';
  $params[] = $search_rut_profesor;
}

if (!empty($search_id_centronegocio)) {
  $query .= " AND id_centronegocio = ?";
  $types .= 'i';
  $params[] = $search_id_centronegocio;
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

function safe_htmlspecialchars($value)
{
  return htmlspecialchars($value ?? '');
}

if ($result->num_rows > 0) {
  echo '<div class="carta-container">';
  while ($row = $result->fetch_assoc()) {
    $dias_frecuencia_nombres = [];
    $dias_clases = str_split($row['dias_clases']);
    foreach ($dias_clases as $dia) {
      $dia_num = (int) $dia;
      if (isset($dias_semana[$dia_num])) {
        $dias_frecuencia_nombres[] = $dias_semana[$dia_num];
      }
    }
    $dias_frecuencia_texto = implode(', ', $dias_frecuencia_nombres);

    echo '<div class="carta">';
    echo '<div class="carta-header">';
    echo '</div>';
    echo '<div class="carta-body">';
    echo '<p><strong>ID Centro Negocio:</strong> ' . safe_htmlspecialchars($row['id_centronegocio']) . '</p>';
    echo '<p><strong>Rut Profesor:</strong> ' . safe_htmlspecialchars($row['rut_profesor']) . '</p>';
    echo '<p><strong>Código:</strong> ' . safe_htmlspecialchars($row['codigo']) . '</p>';
    echo '<p><strong>Modalidad:</strong> ' . safe_htmlspecialchars($row['modalidad']) . '</p>';
    echo '<p><strong>Días Clases:</strong> ' . safe_htmlspecialchars($dias_frecuencia_texto) . '</p>';
    echo '<p><strong>Hora Desde:</strong> ' . safe_htmlspecialchars($row['hora_desde']) . '</p>';
    echo '<p><strong>Hora Hasta:</strong> ' . safe_htmlspecialchars($row['hora_hasta']) . '</p>';
    echo '<p><strong>Fecha Inicio:</strong> ' . safe_htmlspecialchars($row['fecha_inicio']) . '</p>';
    echo '<p><strong>Sw Matriculas:</strong> ' . safe_htmlspecialchars($row['sw_matriculas']) . '</p>';
    echo '<p><strong>Precio:</strong> ' . safe_htmlspecialchars($row['precio']) . '</p>';
    echo '<p><strong>Valor Matricula:</strong> ' . safe_htmlspecialchars($row['valor_matricula']) . '</p>';
    echo '<p><strong>Precio Sábado:</strong> ' . safe_htmlspecialchars($row['precio_sabado']) . '</p>';
    echo '<p><strong>Horas Totales:</strong> ' . safe_htmlspecialchars($row['horas_totales']) . '</p>';
    echo '<p><strong>Estado:</strong> ' . safe_htmlspecialchars($row['estado']) . '</p>';
    echo '<p><strong>Empresa:</strong> ' . safe_htmlspecialchars($row['empresa']) . '</p>';
    echo '<p><strong>Contacto:</strong> ' . safe_htmlspecialchars($row['contacto']) . '</p>';
    echo '<p><strong>Correo:</strong> ' . safe_htmlspecialchars($row['correo']) . '</p>';
    echo '<p><strong>RUT Empresa:</strong> ' . safe_htmlspecialchars($row['rut_empresa']) . '</p>';
    echo '<p><strong>Telefono Empresa:</strong> ' . safe_htmlspecialchars($row['telefono_empresa']) . '</p>';
    echo '<p><strong>RUT Supervisor:</strong> ' . safe_htmlspecialchars($row['rut_supervisor']) . '</p>';
    echo '<p><strong>Telefono Supervisor:</strong> ' . safe_htmlspecialchars($row['telefono_supervisor']) . '</p>';
    echo '<p><strong>Codigo Sence:</strong> ' . safe_htmlspecialchars($row['codigo_sence']) . '</p>';
    echo '<p><strong>Valor HOra de Relator:</strong> ' . safe_htmlspecialchars($row['valor_hora_relator']) . '</p>';
    echo '<p><strong>Maximo Alumno:</strong> ' . safe_htmlspecialchars($row['max_alumnos']) . '</p>';
    echo '<p><strong>Tipo Curso:</strong> ' . safe_htmlspecialchars($row['tipo_curso']) . '</p>';
    echo '<p><strong>Última Modificación:</strong> ' . safe_htmlspecialchars($row['ultima_modificacion']) . '</p>';
    echo '<p><strong>Imagen:</strong> ' . safe_htmlspecialchars($row['imagen']) . '</p>';
    echo '<p><strong>Color:</strong> ' . safe_htmlspecialchars($row['color']) . '</p>';
    echo '<p><strong>Alias:</strong> ' . safe_htmlspecialchars($row['alias']) . '</p>';
    echo '<p><strong>Pass Único:</strong> ' . safe_htmlspecialchars($row['pass_unico']) . '</p>';
    echo '<p><strong>Curso Online:</strong> ' . safe_htmlspecialchars($row['curso_online']) . '</p>';
    echo '<p><strong>Sala:</strong> ' . safe_htmlspecialchars($row['sala']) . '</p>';
    echo '<div class="acciones">';
    echo '<a href="update.php?id_curso=' . safe_htmlspecialchars($row['id_curso']) . '" class="btn btn-sm btn-warning">Editar</a>';
    echo '<a href="javascript:void(0);" onclick="confirmDelete(' . safe_htmlspecialchars($row['id_curso']) . ');" class="btn btn-sm btn-danger">Eliminar</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
  }
  echo '</div>';
}
$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }
</script>