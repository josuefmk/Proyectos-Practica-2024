<?php
include 'conexion.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha = $_POST['fecha'];
  $descripcion = $_POST['descripcion'];
  $sw_repeticion = $_POST['sw_repeticion'];

  $stmt = $conn->prepare("INSERT INTO tbl_feriados(fecha, descripcion, sw_repeticion) VALUES (?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssi", $fecha, $descripcion, $sw_repeticion);

  if ($stmt->execute()) {
    echo "Fecha guardada correctamente";
  } else {
    header('Location: index.php?error=1');
  }

  $stmt->close();
  $conn->close();
} else {
  header('Location: index.php');
  exit;
}
?>