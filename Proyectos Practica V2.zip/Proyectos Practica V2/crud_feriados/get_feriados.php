<?php
include 'conexion.php';

function getFeriados($conn)
{
  $result = $conn->query("SELECT fecha FROM tbl_feriados");
  $feriados = [];
  while ($row = $result->fetch_assoc()) {
    $feriados[] = date("Y-m-d", strtotime($row['fecha']));
  }
  return $feriados;
}

$feriados = getFeriados($conn);
$feriados = array_filter($feriados);
$feriados = array_unique($feriados);

$month = isset($_GET['month']) ? (int) $_GET['month'] : date('n');
$year = isset($_GET['year']) ? (int) $_GET['year'] : date('Y');

$calendar = generateCalendar($month, $year, $feriados);

function generateCalendar($month, $year, $feriados)
{
  $dias = ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'];
  $meses = [
    'longhand' => ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
  ];

  $calendar = "<div class='calendar-header'>";
  $calendar .= "<select name='month' onchange='changeMonthYear()'>";
  foreach ($meses['longhand'] as $index => $mes) {
    $selected = ($index + 1 == $month) ? 'selected' : '';
    $calendar .= "<option value='" . ($index + 1) . "' $selected>$mes</option>";
  }
  $calendar .= "</select>";

  $calendar .= "<select name='year' onchange='changeMonthYear()'>";
  for ($i = date('Y') - 5; $i <= date('Y') + 5; $i++) {
    $selected = ($i == $year) ? 'selected' : '';
    $calendar .= "<option value='$i' $selected>$i</option>";
  }
  $calendar .= "</select>";

  $calendar .= "<span class='month-year'>" . $meses['longhand'][$month - 1] . " $year</span>";
  $calendar .= "</div>";

  $calendar .= "<table class='calendar'>";
  $calendar .= "<tr>";
  foreach ($dias as $dia) {
    $calendar .= "<th>$dia</th>";
  }
  $calendar .= "</tr><tr>";

  $firstDay = mktime(0, 0, 0, $month, 1, $year);
  $dayOfWeek = date('w', $firstDay);
  $daysInMonth = date('t', $firstDay);

  for ($i = 0; $i < $dayOfWeek; $i++) {
    $calendar .= "<td></td>";
  }

  for ($day = 1; $day <= $daysInMonth; $day++) {
    $date = date("Y-m-d", strtotime("$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT)));
    $isFeriado = in_array($date, $feriados) ? " class='flatpickr-day feriado'" : " class='flatpickr-day'";
    $calendar .= "<td$isFeriado data-date='$date' onclick='selectDate(\"$date\")'>$day</td>";

    if (($day + $dayOfWeek) % 7 == 0) {
      $calendar .= "</tr><tr>";
    }
  }

  $calendar .= "</tr></table>";

  return $calendar;
}

if (isset($_GET['action']) && $_GET['action'] == 'getCalendar') {
  $month = isset($_GET['month']) ? (int) $_GET['month'] : date('n');
  $year = isset($_GET['year']) ? (int) $_GET['year'] : date('Y');
  $calendar = generateCalendar($month, $year, $feriados);
  echo $calendar;
  exit;
}
?>