<?php
include 'get_feriados.php';

?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Feriado</title>
  <link rel="stylesheet" href="styles.css">
  <script src="Ajax.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Feriado</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Feriado</h2>
      <label for="fecha">Fecha:</label>
      <div id="calendarContainer">
        <?php echo $calendar; ?>
      </div>
      <p id="selectedDateMessage"></p>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion" required>

      <label for="sw_repeticion">SW Repetición:</label>
      <input type="text" id="sw_repeticion" name="sw_repeticion" required>

      <input type="hidden" id="fecha" name="fecha" required>
      <input type="submit" value="Agregar Operación" class="btn" onclick="showModal()">
      <div id="successModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <p>¡Feriado agregado exitosamente!</p>
        </div>
      </div>

    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar por Fecha y Descripción</h3>
    <label for="search_fecha_feriado">Fechas Feriados:</label>
    <input type="date" id="search_fecha_feriado" name="search_fecha_feriado">

    <label for="search_desc">Descripción:</label>
    <input type="text" id="search_desc" name="search_desc">

    <input type="submit" class="btn">
    <a href="index.php" class="btn">Quitar Filtro</a>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Feriados</h2>


  <?php include 'read.php'; ?>

  <script>
    function changeMonthYear() {
      const month = document.querySelector('select[name="month"]').value;
      const year = document.querySelector('select[name="year"]').value;

      $.ajax({
        url: 'index.php',
        type: 'GET',
        data: {
          action: 'getCalendar',
          month: month,
          year: year
        },
        success: function (response) {
          document.getElementById('calendarContainer').innerHTML = response;
        },
        error: function (xhr, status, error) {
          console.error('Error al cargar el calendario:', error);
        }
      });
    }

    function selectDate(date) {

      if (date) {
        document.getElementById('selectedDateMessage').innerText = 'Fecha seleccionada: ' + date;
        document.getElementById('selectedDateMessage').style.display = 'block';
        document.getElementById('fecha').value = date;
        document.getElementById('addFormContainer').style.display = 'block';
      } else {
        document.getElementById('selectedDateMessage').style.display = 'none';
      }
    }
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
        $('#editFormContainer').hide();
      });
    });


    function showModal() {
      document.getElementById('successModal').style.display = 'block';
    }

    function closeModal() {
      document.getElementById('successModal').style.display = 'none';
    }
    window.onclick = function (event) {
      const modal = document.getElementById('successModal');
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    }
  </script>
</body>

</html>