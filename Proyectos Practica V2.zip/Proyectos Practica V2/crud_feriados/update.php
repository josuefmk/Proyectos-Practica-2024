<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Feriado</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  $id = $_GET['id_feriado'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener y sanitizar datos del formulario
    $fecha = $conn->real_escape_string($_POST['fecha']);
    $sw_repeticion = $conn->real_escape_string($_POST['sw_repeticion']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);

    $sql = "UPDATE tbl_feriados SET fecha='$fecha', sw_repeticion='$sw_repeticion', descripcion='$descripcion' WHERE id_feriado=$id";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener los datos existentes
    $result = $conn->query("SELECT * FROM tbl_feriados WHERE id_feriado=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Feriado</h1>
    <form method="POST">

      <label for="fecha">Hora:</label>
      <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($row['fecha']); ?>" required>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion"
        value="<?php echo htmlspecialchars($row['descripcion']); ?>" required>

      <label for="sw_repeticion">SW Repetición:</label>
      <input type="text" id="sw_repeticion" name="sw_repeticion"
        value="<?php echo htmlspecialchars($row['sw_repeticion']); ?>" required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>