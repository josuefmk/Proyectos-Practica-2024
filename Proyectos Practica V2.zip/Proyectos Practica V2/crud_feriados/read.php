<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_fecha_feriado = isset($_GET['search_fecha_feriado']) ? $_GET['search_fecha_feriado'] : '';
$search_desc = isset($_GET['search_desc']) ? $_GET['search_desc'] : '';



$query = "SELECT * FROM tbl_feriados WHERE 1=1";

$types = '';
$params = [];

if (!empty($search_fecha_feriado)) {
  $query .= " AND fecha = ?";
  $types .= 's';
  $params[] = $search_fecha_feriado;
}
if (!empty($search_desc)) {
  $query .= " AND descripcion LIKE ?";
  $types .= 's';
  $params[] = "%" . $search_desc . "%";
}


$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Fecha</th>
                <th>Descripción</th>
                <th>SW Repetición</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['fecha']) . "</td>
           <td>" . htmlspecialchars($row['descripcion']) . "</td>
           <td>" . htmlspecialchars($row['sw_repeticion']) . "</td>
            <td>
              <a href='update.php?id_feriado=" . urlencode($row['id_feriado']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_feriado'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id_feriado: id
        },
        success: function (response) {
          if (response.trim() === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('Se ha eliminado exitosamente.');
          } else {
            alert('Error al eliminar Dato: ' + response);
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }

  $(document).ready(function () {
    $('.delete-btn').on('click', function () {
      var id = $(this).data('id');
      confirmDelete(id);
    });

    $('.edit-btn').on('click', function () {
      var id = $(this).data('id');
      window.location.href = 'update.php?id=' + id;
    });
  });
</script>