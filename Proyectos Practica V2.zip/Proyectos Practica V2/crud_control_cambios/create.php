<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $time_cambio = $_POST['time_cambio'];
  $descripcion = $_POST['descripcion'];
  $usuario_creador = $_POST['usuario_creador'];

  $stmt = $conn->prepare("INSERT INTO tbl_control_cambios( time_cambio, descripcion, usuario_creador) VALUES ( ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssi", $time_cambio, $descripcion, $usuario_creador);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>