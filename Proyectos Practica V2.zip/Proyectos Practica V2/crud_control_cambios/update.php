<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Control de Cambios</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  if (isset($_GET['id_control'])) {
    $id = $_GET['id_control'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $time_cambio = isset($_POST['time_cambio']) ? $conn->real_escape_string($_POST['time_cambio']) : null;
    $descripcion = isset($_POST['descripcion']) ? $conn->real_escape_string($_POST['descripcion']) : null;
    $usuario_creador = isset($_POST['usuario_creador']) && is_numeric($_POST['usuario_creador']) ? $conn->real_escape_string($_POST['usuario_creador']) : null;

    if ($time_cambio && $descripcion && $usuario_creador) {
      $sql = "UPDATE tbl_control_cambios
            SET time_cambio='$time_cambio', descripcion='$descripcion', usuario_creador='$usuario_creador'
            WHERE id_control='$id'";

      if ($conn->query($sql)) {
        header('Location: index.php');
        exit();
      } else {
        echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
      }
    } else {
      echo "<p class='error'>Error: Todos los campos son obligatorios.</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_control_cambios WHERE id_control=$id");
    $row = $result->fetch_assoc();
    $usuarioSeleccionado = $row['usuario_creador'];


    $UsuariosOptions = '';
    $result_usuario = $conn->query("SELECT DISTINCT id_usuario, nombres, apellidos FROM tbl_usuarios");

    while ($row_usuario = $result_usuario->fetch_assoc()) {
      $selected = ($row_usuario['id_usuario'] == $usuarioSeleccionado) ? 'selected' : '';
      $UsuariosOptions .= "<option value='{$row_usuario['id_usuario']}' $selected>{$row_usuario['nombres']} {$row_usuario['apellidos']}</option>";
    }
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Atraso</h1>
    <form method="POST">
      <label for="time_cambio">Fecha de Cambio:</label>
      <input type="datetime-local" id="time_cambio" name="time_cambio"
        value="<?php echo htmlspecialchars($row['time_cambio'] ?? ''); ?>" required>

      <label for="descripcion">Descripción:</label>
      <input type="text" id="descripcion" name="descripcion"
        value="<?php echo htmlspecialchars($row['descripcion'] ?? ''); ?>" required>

      <label for="usuario_creador">Usuario:</label>
      <select id="usuario_creador" name="usuario_creador">
        <option value="">Seleccione un Usuario</option>
        <?php echo $UsuariosOptions; ?>
      </select>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>