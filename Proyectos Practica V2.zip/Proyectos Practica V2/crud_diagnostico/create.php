<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_encuesta = $_POST['id_encuesta'];
  $nombre_empresa = $_POST['nombre_empresa'];
  $fecha = $_POST['fecha'];

  $sql = "INSERT INTO tbl_diagnostico (id_encuesta, nombre_empresa, fecha)
            VALUES ('$id_encuesta', '$nombre_empresa', '$fecha')";

  if ($conn->query($sql) === TRUE) {
    echo "Encuesta guardada correctamente";
  } else {
    echo "Error al guardar la encuesta: " . $sql . "<br>" . $conn->error;
  }


}
?>