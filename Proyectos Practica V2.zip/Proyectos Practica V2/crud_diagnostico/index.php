<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>CRUD Diagnóstico</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleFormBtn">Agregar Diagnóstico</button>
  <div class="form-container-add" id="diagnosticoFormContainer">
    <form id="diagnosticoForm" method="post" action="insert.php">
      <h2>Nuevo Diagnóstico</h2>
      <label for="id_encuesta">ID Encuesta:</label>
      <input type="text" id="id_encuesta" name="id_encuesta" required>
      <label for="nombre_empresa">Nombre Empresa:</label>
      <input type="text" id="nombre_empresa" name="nombre_empresa" required>
      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" required>
      <input type="submit" value="Agregar Diagnóstico" class="submit-btn">
    </form>
  </div>

  <form id="searchForm">
    <h3>Buscar por ID Encuesta y Nombre Empresa</h3>
    <label for="search_id_encuesta">ID Encuesta:</label>
    <input type="text" id="search_id_encuesta" name="search_id_encuesta">
    <label for="search_nombre_empresa">Nombre Empresa:</label>
    <input type="text" id="search_nombre_empresa" name="search_nombre_empresa">
    <input type="submit" value="Buscar">
  </form>

  <form id="searchDateForm">
    <h3>Buscar por Fecha</h3>
    <label for="search_fecha">Fecha:</label>
    <input type="date" id="search_fecha" name="search_fecha" required>
    <input type="submit" value="Buscar">
  </form>

  <div id="searchResult"></div>
  <h1>Lista de Diagnósticos</h1>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <script>
    // Código para copiar el link al portapapeles
    document.addEventListener("DOMContentLoaded", function () {
      console.log('DOM completamente cargado y analizado');

      document.querySelectorAll(".copy-link").forEach((copyLinkParent) => {
        const inputField = copyLinkParent.querySelector(".copy-link-input");
        const copyButton = copyLinkParent.querySelector(".copy-link-button");

        if (inputField && copyButton) {
          copyButton.addEventListener("click", () => {
            const originalValue = inputField.value;

            const textarea = document.createElement("textarea");
            textarea.value = originalValue;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);

            inputField.value = "¡Copiado!";
            setTimeout(() => {
              inputField.value = originalValue;
            }, 2000);
          });
        } else {
          console.error("No se encontró el input o botón de copia en el DOM.");
        }
      });
    });
  </script>

  <?php include 'read.php'; ?>

</body>

</html>