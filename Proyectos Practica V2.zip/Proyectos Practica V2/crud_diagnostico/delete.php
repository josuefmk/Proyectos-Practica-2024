<?php
include 'conexion.php';

if (isset($_POST['id'])) {
  $id = $_POST['id'];


  if (filter_var($id, FILTER_VALIDATE_INT) === false) {
    echo 'error';
    exit;
  }

  $sql = "DELETE FROM tbl_diagnostico WHERE id_diagnostico='$id'";

  if ($conn->query($sql) === TRUE) {
    echo 'success';
  } else {
    echo 'error';
  }
} else {
  echo 'error';
}

$conn->close();
?>