<?php
include 'conexion.php';

// Inicializar variables de búsqueda
$search_id_encuesta = isset($_GET['search_id_encuesta']) ? $_GET['search_id_encuesta'] : '';
$search_nombre_empresa = isset($_GET['search_nombre_empresa']) ? $_GET['search_nombre_empresa'] : '';
$search_fecha = isset($_GET['search_fecha']) ? $_GET['search_fecha'] : '';

// Consultas
$sql = "SELECT id_diagnostico, id_encuesta, nombre_empresa, fecha FROM tbl_diagnostico WHERE 1=1";

if ($search_id_encuesta !== '') {
  $sql .= " AND id_encuesta LIKE '%" . $conn->real_escape_string($search_id_encuesta) . "%'";
}

if ($search_nombre_empresa !== '') {
  $sql .= " AND nombre_empresa LIKE '%" . $conn->real_escape_string($search_nombre_empresa) . "%'";
}

if ($search_fecha !== '') {
  $sql .= " AND fecha = '" . $conn->real_escape_string($search_fecha) . "'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='1'>
    <tr>
        <th>ID Encuesta</th>
        <th>Nombre Empresa</th>
        <th>Fecha</th>
        <th>Link</th>
        <th>Acciones</th>
    </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    $re = base64_encode($row['nombre_empresa']);
    $ie = base64_encode($row['id_encuesta']);
    $link = "www.elc.cl/elcapp1/encuestas_c.php?re=$re&ie=$ie";

    echo "<tr id='row-{$row['id_diagnostico']}'>
            <td>{$row['id_encuesta']}</td>
            <td>{$row['nombre_empresa']}</td>
            <td>{$row['fecha']}</td>
            <td>
                <div class='copy-link'>
                    <input type='text' class='copy-link-input' value='$link' readonly>
                    <button type='button' class='copy-link-button'>
                        <img src='copiar.png' style='font-size: 20px ; width:130%;'></img>
                    </button>
                </div>
            </td>
            <td>
                <a href='update.php?id={$row['id_diagnostico']}'>Editar</a>
                <a href='javascript:void(0);' onclick='confirmDelete({$row['id_diagnostico']});'>Eliminar</a>
            </td>
            </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$conn->close();
?>

<script>
  // Confirmación de eliminación de un registro
  function confirmDelete(id) {
    if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
      $.ajax({
        url: 'delete.php',
        type: 'POST',
        data: {
          id: id
        },
        success: function (response) {
          if (response === 'success') {
            $('#row-' + id).fadeOut(500, function () {
              $(this).remove();
            });
            alert('El registro ha sido eliminado exitosamente.');
          } else {
            alert('Error al eliminar el registro.');
          }
        },
        error: function () {
          alert('Hubo un error en la solicitud.');
        }
      });
    }
  }
</script>