<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Diagnóstico</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_encuesta = $_POST['id_encuesta'];
    $nombre_empresa = $_POST['nombre_empresa'];
    $fecha = $_POST['fecha'];

    $sql = "UPDATE tbl_diagnostico SET nombre_empresa='$nombre_empresa', fecha='$fecha' WHERE id_diagnostico=$id";

    if ($conn->query($sql)) {
      echo "<p class='success'>Registro actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    $result = $conn->query("SELECT * FROM tbl_diagnostico WHERE id_diagnostico=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Diagnóstico</h1>
    <form method="POST">
      <label for="id_encuesta">ID Encuesta:</label>
      <input type="text" id="id_encuesta" name="id_encuesta"
        value="<?php echo htmlspecialchars($row['id_encuesta']); ?>" required>

      <label for="nombre_empresa">Nombre Empresa:</label>
      <input type="text" id="nombre_empresa" name="nombre_empresa"
        value="<?php echo htmlspecialchars($row['nombre_empresa']); ?>" required>

      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($row['fecha']); ?>" required>

      <input type="submit" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>