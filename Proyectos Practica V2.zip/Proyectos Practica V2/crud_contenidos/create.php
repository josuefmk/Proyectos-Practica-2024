<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $clase = $_POST['clase'];
  $fecha = $_POST['fecha'];
  $contenido_de_clase = $_POST['contenido_de_clase'];
  $tipo_clase = $_POST['tipo_clase'];
  $id_especialidad = $_POST['id_especialidad'];

  $stmt = $conn->prepare("INSERT INTO tbl_contenidos( clase, fecha, contenido_de_clase,tipo_clase,id_especialidad) VALUES ( ?, ?, ?,?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("isssi", $clase, $fecha, $contenido_de_clase, $tipo_clase, $id_especialidad);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>