<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$search_curso = isset($_GET['search_curso']) ? $_GET['search_curso'] : '';
$TipoClase = [
  1 => 'Teoria',
  2 => 'Práctica'
];

$TipoClaseOptions = '';
$result_tipoclase = $conn->query("SELECT DISTINCT tipo_clase FROM tbl_contenidos");
while ($row = $result_tipoclase->fetch_assoc()) {
  $tipoc_num = (int) $row['tipo_clase'];
  $estado_texto = isset($TipoClase[$tipoc_num]) ? $TipoClase[$tipoc_num] : 'No existe';
  $TipoClaseOptions .= "<option value='{$tipoc_num}'>{$estado_texto}</option>";
}


$id_centroingreso = isset($_GET['id_centroingreso']) ? $_GET['id_centroingreso'] : "";
$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : "";

$sql = "
SELECT
id_curso,
fecha_inicio,
hora_desde,
hora_hasta,
id_centroingreso,
nombre
FROM
tbl_cursos
JOIN
tbl_centrosdeingreso
WHERE
id_centronegocio = id_centroingreso
";
$result = $conn->query($sql);
$centros = [];
if ($result) {
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $centros[] = $row;
    }
  }
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Contenidos</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Conteido</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nueva Clase</h2>


      <label for="clase">Clase:</label>
      <input type="number" id="clase" name="clase" min="1" max="80" placeholder="Min 1 - Max 80" required>

      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" required>

      <label for="contenido_de_clase">Contenido de Clase:</label>
      <input type="text" id="contenido_de_clase" name="contenido_de_clase" required>

      <label for="tipo_clase">Tipo de Clase:</label>
      <select id="tipo_clase" name="tipo_clase" class="form-control" required>
        <option value=""> Seleccione Tipo de Clase</option>
        <option value="1">Teoria</option>
        <option value="2">Práctica</option>
      </select>

      <label for="id_especialidad">Curso:</label>
      <select id="id_especialidad" name="id_especialidad" required>
        <option value="">Seleccione un Curso</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_centroingreso'] == $id_centroingreso) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_centroingreso']) . "' $selected>" . htmlspecialchars($centro['nombre']) . " " . $centro['fecha_inicio'] . " " . $centro['hora_desde'] . "-" . $centro['hora_hasta'] . "</option>";
        }
        ?>
      </select>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Datos</h3>
    <label for="search_clase">Clase:</label>
    <input type="number" id="search_clase" name="search_clase">

    <label for="search_fecha">Fecha:</label>
    <input type="date" id="search_fecha" name="search_fecha">

    <label for="search_tipoclase">Tipo de Clase:</label>
    <select id="search_tipoclase" name="search_tipoclase">
      <option value="">Seleccione Tipo de Clase </option>
      <?php echo $TipoClaseOptions; ?>
    </select>

    <label for="search_curso">Curso:</label>
    <select id="especialidadSelect" name="search_curso" Onchange="this.form.submit();">
      <option value=''>Seleccione un Curso</option>
      <?php

      $previo_value = '';
      foreach ($centros as $rsl) {
        if ($rsl['id_centroingreso'] != $previo_value) {
          echo "<option value='" . $rsl['id_centroingreso'] . "' ";
          if ($search_curso == $rsl['id_centroingreso']) {
            echo " selected='selected' ";
          }
          echo ">" . $rsl['nombre'] . "</option>";
          $previo_value = $rsl['id_centroingreso'];
        }
      }
      ?>
    </select>


    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
    $(document).ready(function () {
      $('#toggleAddFormBtn').click(function () {
        $('#addFormContainer').toggle();
      });
    });
    document.getElementById('especialidadSelect').addEventListener('change', function () {
      const selectedEspecialidad = this.value;

    });
  </script>
</body>