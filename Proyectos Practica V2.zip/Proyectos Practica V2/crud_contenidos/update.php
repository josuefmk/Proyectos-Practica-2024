<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Contenidos</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  if (isset($_GET['id_contenido'])) {
    $id = $_GET['id_contenido'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $clase = $conn->real_escape_string($_POST['clase']);
    $fecha = $conn->real_escape_string($_POST['fecha']);
    $contenido_de_clase = $conn->real_escape_string($_POST['contenido_de_clase']);
    $tipo_clase = $conn->real_escape_string($_POST['tipo_clase']);
    $id_especialidad = $conn->real_escape_string($_POST['id_especialidad']);
    $sql = "UPDATE tbl_contenidos
            SET clase='$clase', fecha='$fecha', contenido_de_clase='$contenido_de_clase', tipo_clase='$tipo_clase', id_especialidad='$id_especialidad'
            WHERE id_contenido='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    $result = $conn->query("SELECT * FROM tbl_contenidos WHERE id_contenido='$id'");


    if ($result && $result->num_rows > 0) {
      $row = $result->fetch_assoc();

    } else {
      echo "<p class='error'>Error: Contenido no encontrado.</p>";
      exit();
    }

    $TipoClase = [
      1 => 'Teoria',
      2 => 'Práctica'
    ];

    $TipoClaseOptions = '';
    $result_tipoclase = $conn->query("SELECT DISTINCT tipo_clase FROM tbl_contenidos");
    while ($row_tipo_clase = $result_tipoclase->fetch_assoc()) {
      $tipoc_num = (int) $row_tipo_clase['tipo_clase'];
      $estado_texto = isset($TipoClase[$tipoc_num]) ? $TipoClase[$tipoc_num] : 'No existe';
      $selected = ($row_tipo_clase['tipo_clase'] == $tipoc_num) ? 'selected' : '';
      $TipoClaseOptions .= "<option value='{$tipoc_num}'{$selected}>{$estado_texto}</option>";
    }
  }

  ?>

  <div class="form-container">
    <h1>Actualizar Contenido</h1>
    <form method="POST">
      <label for="clase">Clase:</label>
      <input type="number" id="clase" name="clase" min="1" max="80" placeholder="Min 1 - Max 80"
        value="<?php echo htmlspecialchars($row['clase'] ?? ''); ?>" required>

      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($row['fecha'] ?? ''); ?>" required>

      <label for="contenido_de_clase">Contenido de Clase:</label>
      <input type="text" id="contenido_de_clase" name="contenido_de_clase"
        value="<?php echo htmlspecialchars($row['contenido_de_clase'] ?? ''); ?>" required>

      <label for="tipo_clase">TIpo de Clase:</label>
      <select id="tipo_clase" name="tipo_clase">
        <option value="">Seleccione un Tipo de Clase</option>
        <?php echo $TipoClaseOptions; ?>
      </select>



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>