<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Inasistencia</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_empleado'])) {
    $id = $_GET['id_empleado'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $fecha_inasistencia = $conn->real_escape_string($_POST['fecha_inasistencia']);
    $motivo = $conn->real_escape_string($_POST['motivo']);
    $id_empleado = $conn->real_escape_string($_POST['id_empleado']);


    $sql = "UPDATE tbl_inasistencias
        SET fecha_inasistencia='$fecha_inasistencia', motivo='$motivo', id_empleado='$id_empleado',
        WHERE tbl_inasistencias='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_inasistencias WHERE id_empleado=$id");
    $row = $result->fetch_assoc();

    $empladoOptions = "";

    $result_empleado = $conn->query("SELECT DISTINCT id_empleado, nombres,paterno,materno FROM tbl_empleados ");
    while ($row_relator = $result_empleado->fetch_assoc()) {
      $selected = ($row['id_empleado'] == $row_relator['id_empleado']) ? 'selected' : '';
      $empladoOptions .= "<option value='{$row_relator['id_empleado']}' {$selected}>{$row_relator['nombres']} {$row_relator['paterno']} {$row_relator['materno']}</option>";
    }


  }



  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Inasistencia</h1>
    <form method="POST">

      <encia for="fecha_inasistencia">Fecha de Inasistencia:</encia>
      <input type="date" id="fecha_inasistencia" name="fecha_inasistencia"
        value="<?php echo htmlspecialchars($row['fecha_inasistencia'] ?? ''); ?>" required>


      <label for="id_empleado">Nombre del Emmpleado :</label>
      <select id="id_empleado" name="id_empleado">
        <option value="">Seleccione un Nombre </option>
        <?php echo $empladoOptions; ?>
      </select>


      <label for="motivo">Motivo:</label>
      <input type="text" id="motivo" name="motivo" value="<?php echo htmlspecialchars($row['motivo'] ?? ''); ?>"
        required>


      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>