<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['id_empleado'])) {
    $id = $_POST['id_empleado'];

    $stmt = $conn->prepare("DELETE FROM tbl_inasistencias WHERE id_empleado = ?");
    if ($stmt === false) {
      echo "Error en la preparación de la consulta: " . $conn->error;
      exit;
    }
    $stmt->bind_param("i", $id);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
      echo "success";
    } else {
      echo "Error al eliminar el registro: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
  } else {
    echo "ID  no está.";
  }
} else {
  echo "Método de solicitud no válido.";
}
?>