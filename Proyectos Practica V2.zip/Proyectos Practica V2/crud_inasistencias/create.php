<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha_inasistencia = $_POST['fecha_inasistencia'];
  $id_empleado = $_POST['id_empleado'];
  $motivo = $_POST['motivo'];

  $stmt = $conn->prepare("INSERT INTO tbl_inasistencias( fecha_inasistencia, id_empleado, motivo) VALUES ( ?, ?, ?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sii", $fecha_inasistencia, $id_empleado, $motivo);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>