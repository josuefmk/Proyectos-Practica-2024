<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$empleadosOptions = '';


$result_empleados = $conn->query("SELECT DISTINCT id_empleado,nombres,paterno,materno FROM tbl_empleados");
while ($row = $result_empleados->fetch_assoc()) {
  $empleadosOptions .= "<option value='{$row['id_empleado']}'>{$row['nombres']} {$row['paterno']} {$row['materno']}</option>";
}

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Inasistencia</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>


      <label for="fecha_inasistencia">Fecha:</label>
      <input type="date" id="fecha_inasistencia" name="fecha_inasistencia" required>

      <label for="id_empleado">Nombre del Empleado:</label>
      <select id="id_empleado" name="id_empleado">
        <option value="">Seleccione un Empleado</option>
        <?php echo $empleadosOptions; ?>
      </select>

      <label for="motivo">Motivo:</label>
      <input type="text" id="motivo" name="motivo" required>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>
    <label for="search_fecha_inasistencia">Feche de Inasistencia:</label>
    <input type="date" id="search_fecha_inasistencia" name="search_fecha_inasistencia" required>

    <label for="search_idempleado">Nombre del Emmpleado :</label>
    <select id="search_idempleado" name="search_idempleado">
      <option value="">Seleccione un ID </option>
      <?php echo $empleadosOptions; ?>
    </select>



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>