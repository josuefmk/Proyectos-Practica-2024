<?php
include 'conexion.php';

// Las opciones para las listas desplegables
$salaOptions = '';
$claseOptions = '';
$eventoOptions = '';

$result_salas = $conn->query("SELECT DISTINCT sala FROM tbl_guiones");
while ($row = $result_salas->fetch_assoc()) {
  $salaOptions .= "<option value='{$row['sala']}'>{$row['sala']}</option>";
}

$result_clases = $conn->query("SELECT DISTINCT clase FROM tbl_guiones");
while ($row = $result_clases->fetch_assoc()) {
  $claseOptions .= "<option value='{$row['clase']}'>{$row['clase']}</option>";
}

$result_eventos = $conn->query("SELECT DISTINCT evento FROM tbl_guiones");
while ($row = $result_eventos->fetch_assoc()) {
  $eventoOptions .= "<option value='{$row['evento']}'>{$row['evento']}</option>";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>CRUD Guiones</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="Ajax.js" defer></script>
</head>

<body>
  <button id="toggleFormBtn">Agregar Objeto</button>
  <div class="form-container-add" id="CategoriaFormContainer">
    <form id="CategoriaForm" method="post" action="create.php">
      <h2>Nuevo Dato</h2>
      <label for="id_especialidad">ID especialidad:</label>
      <input type="number" id="id_especialidad" name="id_especialidad" required>

      <label for="sala">Sala:</label>
      <input type="number" id="sala" name="sala" required>

      <label for="clase">Clase:</label>
      <input type="number" id="clase" name="clase" required>

      <label for="tiempo">Tiempo:</label>
      <input type="time" id="tiempo" name="tiempo" required>

      <label for="evento">Evento:</label>
      <input type="text" id="evento" name="evento" required>

      <input type="submit" value="Agregar Objeto" class="submit-btn">
    </form>
  </div>





  <form id="searchForm">
    <h3>Buscar por Sala, Clase y Evento</h3>
    <label for="search_sala">Sala:</label>
    <select id="search_sala" name="search_sala">
      <option value="">Seleccione una sala</option>
      <?php echo $salaOptions; ?>
    </select>

    <label for="search_clase">Clase:</label>
    <select id="search_clase" name="search_clase">
      <option value="">Seleccione una clase</option>
      <?php echo $claseOptions; ?>
    </select>

    <label for="search_evento">Evento:</label>
    <select id="search_evento" name="search_evento">
      <option value="">Seleccione un evento</option>
      <?php echo $eventoOptions; ?>
    </select>

    <input type="submit" value="Buscar">
  </form>

  <div id="searchResult"></div>
  <h1>Lista de Datos Ingresados</h1>

  <?php include 'read.php'; ?>
  <script>
    $('#searchForm').submit(function (event) {
      event.preventDefault();

      const search_sala = $('#search_sala').val();
      const search_clase = $('#search_clase').val();
      const search_evento = $('#search_evento').val();

      $.ajax({
        url: 'read.php',
        type: 'GET',
        data: {
          search_sala: search_sala,
          search_clase: search_clase,
          search_evento: search_evento
        },
        success: function (data) {
          $('#searchResult').html(data).show();
        },
        error: function () {
          alert('Hubo un error al buscar los datos.');
        }
      });
    });
  </script>
</body>

</html>