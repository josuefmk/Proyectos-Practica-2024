<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$search_sala = isset($_GET['search_sala']) ? $_GET['search_sala'] : '';
$search_clase = isset($_GET['search_clase']) ? $_GET['search_clase'] : '';
$search_evento = isset($_GET['search_evento']) ? $_GET['search_evento'] : '';

// Construir la consulta SQL con los filtros seleccionados
$sql = "SELECT id_especialidad, sala, clase, tiempo, evento FROM tbl_guiones WHERE 1=1";

if ($search_sala !== '') {
  $sql .= " AND sala = '" . $conn->real_escape_string($search_sala) . "'";
}
if ($search_clase !== '') {
  $sql .= " AND clase = '" . $conn->real_escape_string($search_clase) . "'";
}
if ($search_evento !== '') {
  $sql .= " AND evento LIKE '%" . $conn->real_escape_string($search_evento) . "%'";
}

$result = $conn->query($sql);

// Mostrar los resultados de la búsqueda
if ($result === false) {
  echo "Error en la consulta: " . $conn->error;
} elseif ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Sala</th>
                <th>Clase</th>
                <th>Tiempo</th>
                <th>Evento</th>
                <th>Acciones</th>
            </tr>";

  while ($row = $result->fetch_assoc()) {
    echo "<tr id='row-{$row['id_especialidad']}'>
                <td>{$row['sala']}</td>
                <td>{$row['clase']}</td>
                <td>{$row['tiempo']}</td>
                <td>{$row['evento']}</td>
                <td>
                    <a href='update.php?id={$row['id_especialidad']}'>Editar</a>
                    <a href='javascript:void(0);' onclick='confirmDelete({$row['id_especialidad']});'>Eliminar</a>
                </td>
              </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros que coincidan con la búsqueda.";
}

$conn->close();
?>
<script>
// Confirmación de eliminación de un registro
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        console.log(response);
        if (response === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('El registro ha sido eliminado exitosamente.');
        } else {
          alert('Error al eliminar el registro.');
        }
      },
      error: function(xhr, status, error) {
        console.log(xhr.responseText);
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}
</script>