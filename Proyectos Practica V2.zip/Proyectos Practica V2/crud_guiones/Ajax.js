$(document).ready(function () {

    $('#searchForm').submit(function (e) {
        e.preventDefault();
        buscarRegistros();
    });


    function buscarRegistros() {
        const sala = $('#search_sala').val().trim();
        const clase = $('#search_clase').val().trim();
        const evento = $('#search_evento').val().trim();


        if (sala !== '' || clase !== '' || evento !== '') {
            $.ajax({
                type: 'GET',
                url: 'read.php',
                data: $(this).serialize(),
                success: function (response) {
                    $('#searchResult').html(response);
                },
                error: function () {
                    $('#searchResult').html('<p class="error">Error al buscar.</p>');
                }
            });
        } else {
            $('#searchResult').html('<p class="error">Por favor, ingresa al menos un dato para buscar.</p>');
        }
    }


    $('#search_sala, #search_clase, #search_evento').on('input', function () {
        buscarRegistros();
    });

    $('#CategoriaForm').submit(function (e) {
        e.preventDefault();

        $.ajax({
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function (response) {
                $('#result').html('<p class="success">Categoría agregada exitosamente.</p>');
                $('#CategoriaForm')[0].reset();
                loadRecords();
            },
            error: function () {
                $('#result').html('<p class="error">Error al agregar categoría.</p>');
            }
        });
    });


    loadRecords();
});

  document.getElementById("toggleFormBtn").addEventListener("click", function () {
        const formContainer = document.getElementById("CategoriaFormContainer");

        if (formContainer.style.display === "none" || formContainer.style.display === "") {
            formContainer.style.display = "block";
        } else {
            formContainer.style.display = "none";
        }
    });