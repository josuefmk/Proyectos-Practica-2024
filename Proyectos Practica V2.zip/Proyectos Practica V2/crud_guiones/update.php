<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Registro</title>
</head>

<body>

  <?php
  include 'conexion.php';

  $id = $_GET['id'];

  // Verificar si se ha enviado el formulario
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_especialidad = $conn->real_escape_string($_POST['id_especialidad']);
    $sala = $conn->real_escape_string($_POST['sala']);
    $clase = $conn->real_escape_string($_POST['clase']);
    $evento = $conn->real_escape_string($_POST['evento']);


    // Consulta para actualizar el registro
    $sql = "UPDATE tbl_guiones SET sala='$sala', clase='$clase', evento='$evento' WHERE id_especialidad=$id";

    if ($conn->query($sql)) {
      echo "<p class='success'>Registro actualizado correctamente.</p>";
    } else {
      echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    // Obtener el registro actual para mostrar en el formulario
    $result = $conn->query("SELECT * FROM tbl_guiones WHERE id_especialidad=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Registro</h1>
    <form method="POST">
      <label for="id_especialidad">ID Especialidad:</label>
      <input type="number" id="id_especialidad" name="id_especialidad"
        value="<?php echo htmlspecialchars($row['id_especialidad']); ?>" required readonly>

      <label for="sala">Sala:</label>
      <input type="number" id="sala" name="sala" value="<?php echo htmlspecialchars($row['sala']); ?>" required>

      <label for="clase">Clase:</label>
      <input type="number" id="clase" name="clase" value="<?php echo htmlspecialchars($row['clase']); ?>" required>

      <label for="evento">Evento:</label>
      <input type="text" id="evento" name="evento" value="<?php echo htmlspecialchars($row['evento']); ?>" required>


      <input type="submit" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="button">Regresar</button>
  </a>

</body>

</html>