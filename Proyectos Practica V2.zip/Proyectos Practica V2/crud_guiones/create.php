<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_especialidad = $_POST['id_especialidad'];
  $sala = $_POST['sala'];
  $clase = $_POST['clase'];
  $tiempo = $_POST['tiempo'];
  $evento = $_POST['evento'];

  $stmt = $conn->prepare("INSERT INTO tbl_guiones (id_especialidad, sala, clase, tiempo, evento) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssss", $id_especialidad, $sala, $clase, $tiempo, $evento);


  if ($stmt->execute()) {
    echo "Encuesta guardada correctamente";
  } else {
    echo "Error al guardar la encuesta: " . $stmt->error;
  }
  $stmt->close();
}