<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_codigo_matricula = isset($_GET['search_codigo_matricula']) ? $_GET['search_codigo_matricula'] : '';
$search_id_curso = isset($_GET['search_id_curso']) ? $_GET['search_id_curso'] : '';
$search_fecha = isset($_GET['search_fecha']) ? $_GET['search_fecha'] : '';
$search_estado = isset($_GET['search_estado']) ? $_GET['search_estado'] : '';

$query = "SELECT nombre, d.*
          FROM tbl_cursos
          JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio
          JOIN tbl_diplomas AS d ON tbl_cursos.id_curso = d.id_curso
          GROUP BY id_centroingreso";

$types = '';
$params = [];

if (!empty($search_codigo_matricula)) {
  $query .= " AND d.codigo_matricula = ?";
  $types .= 's';
  $params[] = $search_codigo_matricula;
}
if (!empty($search_id_curso)) {
  $query .= " AND d.id_curso  = ?";
  $params[] = "$search_id_curso";
  $types .= 's';
}


if (!empty($search_fecha)) {
  $query .= " AND 	d.id_fecha2 = ?";
  $types .= 's';
  $params[] = $search_fecha;
}

if (!empty($search_estado)) {
  $query .= " AND d.estado = ?";
  $types .= 's';
  $params[] = $search_estado;
}



$EstadoDip = [
  1 => 'Solicitud Creada',
  2 => 'Impreso',
  3 => 'Enviado a notaria',
  4 => 'Disponible para retiro',
  5 => 'Entregado'
];

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Codigo de Matrícula</th>
                <th>Nombre de curso</th>
                 <th>Estado</th>
                  <th>Fecha Creación</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    $Estado = [];
    $EstadoDiploma = explode(',', $row['estado']);
    foreach ($EstadoDiploma as $Esta) {
      $Est = (int) $Esta;
      if (isset($EstadoDip[$Est])) {
        $Estado[] = $EstadoDip[$Est];
      }
    }
    $Estado_diploma_texto = implode(', ', $Estado);
    echo "
       <tr>
    <td>" . htmlspecialchars($row['codigo_matricula'] ?? '') . "</td>
    <td>" . htmlspecialchars($row['nombre'] ?? '') . "</td>
   <td>" . htmlspecialchars($Estado_diploma_texto ?? '') . "</td>
    <td>" . htmlspecialchars($row['fecha2'] ?? '') . "</td>
    <td>
      <a href='update.php?id_diploma=" . urlencode($row['id_diploma'] ?? '') . "' class='btn btn-sm btn-warning'>Editar</a>
    </td>
    <td>
      <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_diploma'] ?? '')) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
    </td>
  </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_atrasos: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>