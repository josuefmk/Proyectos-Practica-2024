<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$cursosOptions = '';


$id_centroingreso = isset($_GET['id_centroingreso']) ? $_GET['id_centroingreso'] : "";
$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : "";

$sql = "
    SELECT
      id_curso,
        fecha_inicio,
        hora_desde,
        hora_hasta,
        id_centroingreso,
        nombre
       FROM
        tbl_cursos
    JOIN
        tbl_centrosdeingreso
    WHERE
        id_centronegocio = id_centroingreso
";
$result = $conn->query($sql);
$centros = [];
if ($result) {
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $centros[] = $row;
    }
  }
}


$EstadoDip = [
  1 => 'Solicitud Creada',
  2 => 'Impreso',
  3 => 'Enviado a notaria',
  4 => 'Disponible para retiro',
  5 => 'Entregado'
];
$estadoOptions = '';
$result_estado = $conn->query("SELECT DISTINCT estado FROM tbl_diplomas");
while ($row = $result_estado->fetch_assoc()) {
  $estado_num = (int) $row['estado'];
  $estado_texto = isset($EstadoDip[$estado_num]) ? $EstadoDip[$estado_num] : 'No existe';
  $estadoOptions .= "<option value='{$estado_num}'>{$estado_texto}</option>";
}
?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Diplomas</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Diploma</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar un Nuevo Diploma</h2>


      <label for="codigo_matricula">Codigo Matrícula:</label>
      <input type="text" id="codigo_matricula" name="codigo_matricula" required>

      <label for="id_curso">Curso:</label>
      <select id="id_curso" name="id_curso" required>
        <option value="">Seleccione un Curso</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_centroingreso'] == $id_centroingreso) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_centroingreso']) . "' $selected>" . htmlspecialchars($centro['nombre']) . " " . $centro['fecha_inicio'] . " " . $centro['hora_desde'] . "-" . $centro['hora_hasta'] . "</option>";
        }
        ?>
      </select>
      <label for="estado">Estado:</label>
      <select id="estado" name="estado" class="form-control" required>
        <option value="">Seleccionar estado</option>
        <option value="1">Solicitud Creada</option>
        <option value="2">Impreso</option>
        <option value="3">Enviado a Notaria</option>
        <option value="4">Disponibilidad de retiro</option>
        <option value="5">Entregado</option>
      </select>

      <label for="fecha2">Fecha Creación:</label>
      <input type="date" id="fecha2" name="fecha2" required>




      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Diploma</h3>

    <label for="search_codigo_matricula">Codigo Matrícula:</label>
    <input type="text" id="search_codigo_matricula" name="search_codigo_matricula">


    <label for="search_id_curso">Curso:</label>
    <input type="text" id="search_id_curso" name="search_id_curso">


    <label for="search_fecha">Fecha:</label>
    <input type="date" id="search_fecha" name="search_fecha">

    <label for="search_estado">Estado:</label>
    <select id="search_estado" name="search_estado">
      <option value="">Seleccione una Categoria </option>
      <?php echo $estadoOptions; ?>
    </select>



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>