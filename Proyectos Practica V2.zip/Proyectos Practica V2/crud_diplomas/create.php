<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $codigo_matricula = $_POST['codigo_matricula'];
  $id_curso = $_POST['id_curso'];
  $fecha = date("Y-m-d H:i:s");
  $estado = $_POST['estado'];
  $fecha2 = $_POST['fecha2'];

  $stmt = $conn->prepare("INSERT INTO tbl_diplomas( codigo_matricula, id_curso, fecha,estado,fecha2) VALUES ( ?, ?, ?,?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("sisis", $codigo_matricula, $id_curso, $fecha, $estado, $fecha2);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el Matricula: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>