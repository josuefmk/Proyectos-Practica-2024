<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Diplomas</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  if (isset($_GET['id_diploma'])) {
    $id = $_GET['id_diploma'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo_matricula = $conn->real_escape_string($_POST['codigo_matricula']);
    $id_curso = $conn->real_escape_string($_POST['id_curso']);
    $estado = $conn->real_escape_string($_POST['estado']);
    $fecha2 = $conn->real_escape_string($_POST['fecha2']);

    $sql = "UPDATE tbl_diplomas
            SET codigo_matricula='$codigo_matricula', id_curso='$id_curso', estado='$estado', fecha2='$fecha2'
            WHERE id_diploma='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {
    $result = $conn->query("SELECT * FROM tbl_diplomas WHERE id_diploma=$id");

    if ($result && $result->num_rows > 0) {
      $row = $result->fetch_assoc();
    } else {
      echo "<p class='error'>Error: Diploma no encontrado.</p>";
      exit();
    }

   $EstadoString = [
  0 => 'Off',
  1 => 'On'
];

$AccesoString = [
  0 => 'Local',
  1 => 'Remoto'
];

$SexoString = [
  0 => 'Hombre',
  1 => 'Mujer'
];


$estadoOptions = '';
foreach ($EstadoString as $estado_num => $estado_texto) {
  $selected = ($row['estado'] == $estado_num) ? 'selected' : '';
  $estadoOptions .= "<option value='{$estado_num}' {$selected}>{$estado_texto}</option>";
}

$accesoOptions = '';
foreach ($AccesoString as $acceso_num => $acceso_texto) {
  $selected = ($row['acceso'] == $acceso_num) ? 'selected' : '';
  $accesoOptions .= "<option value='{$acceso_num}' {$selected}>{$acceso_texto}</option>";
}


$sexoOptions = '';
foreach ($SexoString as $sexo_num => $sexo_texto) {
  $selected = ($row['sexo'] == $sexo_num) ? 'selected' : '';
  $sexoOptions .= "<option value='{$sexo_num}' {$selected}>{$sexo_texto}</option>";
}

  ?>

  <div class="form-container">
    <h1>Actualizar Diploma</h1>
    <form method="POST">
      <label for="codigo_matricula">Código Matrícula:</label>
      <input type="text" id="codigo_matricula" name="codigo_matricula"
        value="<?php echo htmlspecialchars($row['codigo_matricula'] ?? ''); ?>" required>

      <label for="id_curso">ID Curso:</label>
      <input type="text" id="id_curso" name="id_curso" value="<?php echo htmlspecialchars($row['id_curso'] ?? ''); ?>"
        required>

      <label for="estado">Estado:</label>
      <select id="estado" name="estado">
        <option value="">Seleccione un Estado</option>
        <?php echo $estadoOptions; ?>
      </select>

      <label for="fecha2">Fecha:</label>
      <input type="date" id="fecha2" name="fecha2" value="<?php echo htmlspecialchars($row['fecha2'] ?? ''); ?>"
        required>

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>