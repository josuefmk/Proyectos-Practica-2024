<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Horas Recuperadas</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_recuperacion_horas'])) {
    $id = $_GET['id_recuperacion_horas'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_curso = $conn->real_escape_string($_POST['id_curso']);
    $fecha_recuperacion = $conn->real_escape_string($_POST['fecha_recuperacion']);
    $horas_recuperadas = $conn->real_escape_string($_POST['horas_recuperadas']);
    $rut_relator = $conn->real_escape_string($_POST['rut_relator']);

    $sql = "UPDATE tbl_horas_recuperadas
        SET id_curso='$id_curso', fecha_recuperacion='$fecha_recuperacion', fecha_recuperacion='$fecha_recuperacion', rut_relator='$rut_relator'
        WHERE id_recuperacion_horas='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_horas_recuperadas WHERE id_recuperacion_horas=$id");
    $row = $result->fetch_assoc();


    $cursoOptions = '';

    $result_curso = $conn->query("SELECT DISTINCT nombre, id_curso FROM tbl_cursos JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio GROUP BY id_centroingreso");
    while ($row_curso = $result_curso->fetch_assoc()) {
      $selected = ($row['id_curso'] == $row_curso['id_curso']) ? 'selected' : '';
      $cursoOptions .= "<option value='{$row_curso['id_curso']}' {$selected}>{$row_curso['nombre']}</option>";
    }



    $relatorOptions = "";

    $result_relator = $conn->query("SELECT DISTINCT rut, nombres, paterno, materno FROM tbl_empleados");
    while ($row_relator = $result_relator->fetch_assoc()) {
      $selected = ($row['rut_relator'] == $row_relator['rut']) ? 'selected' : '';
      $relatorOptions .= "<option value='{$row_relator['rut']}' {$selected}>{$row_relator['rut']} - {$row_relator['nombres']} {$row_relator['paterno']} {$row_relator['materno']}</option>";
    }

  }


  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Horas Recuperadas</h1>
    <form method="POST">
      <label for="id_curso">Curso:</label>
      <select id="id_curso" name="id_curso">
        <option value="">Seleccione un Curso</option>
        <?php echo $cursoOptions; ?>
      </select>


      <label for="fecha_recuperacion">Fecha de Recuperación:</label>
      <input type="date" id="fecha_recuperacion" name="fecha_recuperacion"
        value="<?php echo htmlspecialchars($row['fecha_recuperacion'] ?? ''); ?>" required>

      <label for="horas_recuperadas">Horas Recuperadas:</label>
      <input type="time" id="horas_recuperadas" name="horas_recuperadas"
        value="<?php echo htmlspecialchars($row['horas_recuperadas'] ?? ''); ?>" required>

      <label for="horas_recuperadas">Horas Recuperadas:</label>
      <input type="text" id="horas_recuperadas" name="horas_recuperadas"
        value="<?php echo htmlspecialchars($row['horas_recuperadas'] ?? ''); ?>" required>

      <label for="rut_relator">RUT Relator:</label>
      <select id="rut_relator" name="rut_relator">
        <option value="">Seleccione un Profesor</option>
        <?php echo $relatorOptions; ?>
      </select>


      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>