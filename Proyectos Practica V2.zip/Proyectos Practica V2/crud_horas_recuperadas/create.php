<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_curso = $_POST['id_curso'];
  $fecha_recuperacion = $_POST['fecha_recuperacion'];
  $horas_recuperadas = $_POST['horas_recuperadas'];
  $rut_relator = $_POST['rut_relator'];


  $stmt = $conn->prepare("INSERT INTO tbl_horas_recuperadas( id_curso, fecha_recuperacion, horas_recuperadas,rut_relator) VALUES ( ?, ?, ?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("isss", $id_curso, $fecha_recuperacion, $horas_recuperadas, $rut_relator);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>