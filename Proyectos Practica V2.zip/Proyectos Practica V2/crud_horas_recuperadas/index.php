<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);
$cursoOptions = '';

$result_curso = $conn->query("SELECT DISTINCT nombre,id_curso FROM tbl_cursos JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio  GROUP BY id_centroingreso");
while ($row = $result_curso->fetch_assoc()) {
  $cursoOptions .= "<option value='{$row['id_curso']}'>{$row['nombre']}</option>";
}

$relatorOptions = "";
$result_relator = $conn->query("SELECT DISTINCT rut, nombres, paterno, materno FROM tbl_empleados");
while ($row = $result_relator->fetch_assoc()) {
  $relatorOptions .= "<option value='{$row['rut']}'>{$row['rut']}  - {$row['nombres']}{$row['paterno']} {$row['materno']}</option>";
}

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Horas Recuperadas</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nueva Hora Recuperada</h2>


      <label for="id_curso">Curso:</label>
      <select id="id_curso" name="id_curso">
        <option value="">Seleccione un Curso</option>
        <?php echo $cursoOptions; ?>
      </select>


      <label for="fecha_recuperacion">Fecha de Recuperación:</label>
      <input type="date" id="fecha_recuperacion" name="fecha_recuperacion" required>

      <label for="horas_recuperadas">Horas Recuperadas:</label>
      <input type="text" id="horas_recuperadas" name="horas_recuperadas" required>

      <label for="rut_relator">RUT Relator:</label>
      <select id="rut_relator" name="rut_relator">
        <option value="">Seleccione un Profesor</option>
        <?php echo $relatorOptions; ?>
      </select>
      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_curso">Curso :</label>
    <select id="search_curso" name="search_curso">
      <option value="">Seleccione un Curso </option>
      <?php echo $cursoOptions; ?>
    </select>

    <label for="search_fecha_recuperacion">Fecha de Recuperación:</label>
    <input type="date" id="search_fecha_recuperacion" name="search_fecha_recuperacion">

    <label for="search_relator">Relator:</label>
    <select id="search_relator" name="search_relator">
      <option value="">Seleccione un Nombre </option>
      <?php echo $relatorOptions; ?>
    </select>



    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>