<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_rut = isset($_GET['search_rut']) ? $_GET['search_rut'] : '';
$search_curso = isset($_GET['search_curso']) ? $_GET['search_curso'] : '';
$search_fecha_recuperacion = isset($_GET['search_fecha_recuperacion']) ? $_GET['search_fecha_recuperacion'] : '';

$query = "SELECT ci.nombre, h.*, e.rut
          FROM tbl_cursos c
          JOIN tbl_centrosdeingreso ci ON ci.id_centroingreso = c.id_centronegocio
          JOIN tbl_horas_recuperadas h ON c.id_curso = h.id_curso
          JOIN tbl_empleados e ON e.rut = h.rut_relator
          GROUP BY ci.id_centroingreso";


$types = '';
$params = [];

if (!empty($search_rut)) {
  $query .= " AND rut_relator = ?";
  $types .= 's';
  $params[] = $search_rut;
}
if (!empty($search_curso)) {
  $query .= " AND 	h.id_curso = ?";
  $types .= 'i';
  $params[] = $search_curso;
}

if (!empty($search_fecha_recuperacion)) {
  $query .= " AND 	fecha_recuperacion = ?";
  $types .= 's';
  $params[] = $search_fecha_recuperacion;
}


$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>Curso</th>
                <th>Fecha de Recuperación</th>
                <th>Horas Recuperadas</th>
                <th>RUT Profesor</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
           <td>" . htmlspecialchars($row['nombre']) . "</td>
           <td>" . htmlspecialchars($row['fecha_recuperacion']) . "</td>
           <td>" . htmlspecialchars($row['horas_recuperadas']) . "</td>
            <td>" . htmlspecialchars($row['rut']) . "</td>
            <td>
              <a href='update.php?id_recuperacion_horas=" . urlencode($row['id_recuperacion_horas']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_recuperacion_horas'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_recuperacion_horas: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>