<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['id_recuperacion_horas'])) {
    $id = $_POST['id_recuperacion_horas'];

    $stmt = $conn->prepare("DELETE FROM tbl_horas_recuperadas WHERE id_recuperacion_horas = ?");
    if ($stmt === false) {
      echo "Error en la preparación de la consulta: " . $conn->error;
      exit;
    }
    $stmt->bind_param("i", $id);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
      echo "success";
    } else {
      echo "Error al eliminar: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
  } else {
    echo "ID del producto no está.";
  }
} else {
  echo "Método de solicitud no válido.";
}
?>