<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);

?>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Curriculum</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php " enctype="multipart/form-data">
      <h2>Agregar Nuevo Dato</h2>


      <label for="pdf_ruta">PDF:</label>
      <input type="file" id="pdf_ruta" name="pdf_ruta" accept=".pdf" required>
      <p id="error-message" style="color: red; display: none;">El archivo no debe exceder los 10 MB.</p>

      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>

      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" required>

      <label for="celular">Telefono:</label>
      <input type="tel" id="celular" name="celular" required>

      <label for="interes">Interes:</label>
      <input type="text" id="interes" name="interes" required>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Dato</h3>

    <label for="search_nombre">Nombre:</label>
    <input type="text" id="search_nombre" name="search_nombre">

    <label for="search_celular">Celular:</label>
    <input type="text" id="search_celular" name="search_celular">

    <label for="search_interes">Interes:</label>
    <input type="text" id="search_interes" name="search_interes">

    <input type="submit" class="btn">
    <button type="button" id="clearFilterBtn" class="btn">Quitar Filtro</button>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });

  document.getElementById('pdf_ruta').addEventListener('change', function() {
    const file = this.files[0];
    const maxSize = 10 * 1024 * 1024;

    if (file && file.size > maxSize) {
      document.getElementById('error-message').style.display = 'block';
      this.value = '';
    } else {
      document.getElementById('error-message').style.display = 'none';
    }
  });
  </script>
</body>