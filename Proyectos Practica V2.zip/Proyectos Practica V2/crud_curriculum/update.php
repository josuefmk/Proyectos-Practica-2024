<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Curriculum</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id'])) {
    $id = $_GET['id'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $pdf_ruta = $conn->real_escape_string($_POST['pdf_ruta']);
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $interes = $conn->real_escape_string($_POST['interes']);


    $sql = "UPDATE tbl_curriculum
        SET pdf_ruta='$pdf_ruta', nombre='$nombre', correo='$correo', celular='$celular',interes='$interes'
        WHERE id='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_curriculum WHERE id=$id");
    $row = $result->fetch_assoc();
  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Atraso</h1>
    <form method="POST">
      <label for="pdf_ruta">PDF:</label>
      <input type="file" id="pdf_ruta" name="pdf_ruta" accept=".pdf">
      <p id="error-message" style="color: red; display: none;">El archivo no debe exceder los 10 MB.</p>

      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($row['nombre'] ?? ''); ?>">

      <label for="correo">Correo:</label>
      <input type="text" id="correo" name="correo" value="<?php echo htmlspecialchars($row['correo'] ?? ''); ?>">

      <label for="celular">Celular:</label>
      <input type="number" id="celular" name="celular" value="<?php echo htmlspecialchars($row['celular'] ?? ''); ?>">

      <label for="interes">Interes:</label>
      <input type="text" id="interes" name="interes" value="<?php echo htmlspecialchars($row['interes'] ?? ''); ?>">

      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>
<script>
document.getElementById('pdf_ruta').addEventListener('change', function() {
  const file = this.files[0];
  const maxSize = 10 * 1024 * 1024;

  if (file && file.size > maxSize) {
    document.getElementById('error-message').style.display = 'block';
    this.value = '';
  } else {
    document.getElementById('error-message').style.display = 'none';
  }
});
</script>

</html>