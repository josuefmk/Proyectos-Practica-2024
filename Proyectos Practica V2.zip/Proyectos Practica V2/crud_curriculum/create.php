<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_FILES['pdf_ruta'])) {
    $file = $_FILES['pdf_ruta'];
    $maxSize = 10 * 1024 * 1024;


    if ($file['size'] > $maxSize) {
      die("El archivo excede el tamaño permitido de 10 MB.");
    }


    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0777, true);
    }
    $uploadFile = $uploadDir . basename($file['name']);


    if (move_uploaded_file($file['tmp_name'], $uploadFile)) {

      $pdf_ruta = $uploadFile;
      $nombre = $_POST['nombre'];
      $correo = $_POST['correo'];
      $celular = $_POST['celular'];
      $interes = $_POST['interes'];


      $stmt = $conn->prepare("INSERT INTO tbl_curriculum(pdf_ruta, nombre, correo, celular, interes) VALUES (?, ?, ?, ?, ?)");

      if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conn->error);
      }

      $stmt->bind_param("sssss", $pdf_ruta, $nombre, $correo, $celular, $interes);


      if ($stmt->execute()) {
        echo "Datos y archivo subidos correctamente.";
      } else {
        echo "Error al guardar los datos: " . $stmt->error;
      }

      $stmt->close();
    } else {
      die("Error al subir el archivo.");
    }
  } else {
    die("No se recibió ningún archivo.");
  }

  $conn->close();
}
?>