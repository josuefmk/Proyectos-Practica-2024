<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_nombre = isset($_GET['search_nombre']) ? $_GET['search_nombre'] : '';
$search_celular = isset($_GET['search_celular']) ? $_GET['search_celular'] : '';
$search_interes = isset($_GET['search_interes']) ? $_GET['search_interes'] : '';


$query = "SELECT * FROM tbl_curriculum WHERE 1=1";

$types = '';
$params = [];



if (!empty($search_nombre)) {
  $query .= " AND nombre LIKE ?";
  $params[] = "%" . $search_nombre . "%";
  $types .= 's';
}
if (!empty($search_celular)) {
  $query .= " AND celular LIKE ?";
  $params[] = "%" . $search_celular . "%";
  $types .= 's';
}

if (!empty($search_interes)) {
  $query .= " AND interes LIKE ?";
  $params[] = "%" . $search_interes . "%";
  $types .= 's';
}

$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>
                <th>PDF</th>
                <th>Nombre</th>
                <th>Correo</th>
                 <th>Celular</th>
                    <th>Interes</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {

    echo "
              <td><a href='" . htmlspecialchars($row['pdf_ruta']) . "' target='_blank'>Ver Curriculum PDF</a></td>
           <td>" . htmlspecialchars($row['nombre']) . "</td>
           <td>" . htmlspecialchars($row['correo']) . "</td>
           <td>" . htmlspecialchars($row['celular']) . "</td>
           <td>" . htmlspecialchars($row['interes']) . "</td>
            <td>
              <a href='update.php?id=" . urlencode($row['id']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay registros.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>