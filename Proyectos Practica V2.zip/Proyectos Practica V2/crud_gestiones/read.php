<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inicializar variables de búsqueda
$search_fecha_gestion = isset($_GET['search_fecha_gestion']) ? $_GET['search_fecha_gestion'] : '';
$search_nombre_interesado = isset($_GET['search_nombre_interesado']) ? $_GET['search_nombre_interesado'] : '';
$search_nivel_interes = isset($_GET['search_nivel_interes']) ? $_GET['search_nivel_interes'] : '';
$search_nombre_encargado = isset($_GET['search_nombre_encargado']) ? $_GET['search_nombre_encargado'] : '';
$search_nombre_curso = isset($_GET['search_nombre_curso']) ? $_GET['search_nombre_curso'] : '';
$search_origen = isset($_GET['search_origen']) ? $_GET['search_origen'] : '';

$query = "SELECT
    ci.nombre,
    g.*,
    e.nombres,
    e.paterno,
    e.materno,
    ca.causa
FROM
    tbl_gestiones g
JOIN
    tbl_centrosdeingreso ci ON ci.id_centroingreso = g.especialidad
JOIN
    tbl_empleados e ON g.encargado = e.id_empleado

JOIN
    tbl_causasnomatricula ca ON ca.id_causa = g.causa_no_matricula

";

$types = '';
$params = [];


if (!empty($search_fecha_gestion)) {
  $query .= " AND 	g.fecha_gestion = ?";
  $types .= 's';
  $params[] = $search_fecha_gestion;
}

if (!empty($search_nombre_interesado)) {
  $query .= " AND g.nombre_interesado LIKE ?";
  $params[] = "%" . $search_nombre_interesado . "%";
  $types .= 's';
}


if (!empty($search_nivel_interes)) {
  $query .= " AND 	g.nivel_interes = ?";
  $types .= 'i';
  $params[] = $search_nivel_interes;
}

if (!empty($search_nombre_encargado)) {
  $query .= " AND 	g.encargado = ?";
  $types .= 'i';
  $params[] = $search_nombre_encargado;
}

if (!empty($search_nombre_curso)) {
  $query .= " AND 	g.especialidad = ?";
  $types .= 'i';
  $params[] = $search_nombre_curso;
}

if (!empty($search_origen)) {
  $query .= " AND 	g.origen = ?";
  $types .= 's';
  $params[] = $search_origen;
}



$NivelInteres = [
  0 => 'No Interesado',
  1 => 'Interesado',
  2 => 'Muy Interesado'
];

$OrigenInteres = [
  0 => 'WhatsApp',
  1 => 'Instagram',
  2 => 'Telefono',
  3 => 'Correo',
  4 => 'Formulario'
];


$stmt = $conn->prepare($query);

if ($stmt === false) {
  die("Error en la preparación de la consulta: " . $conn->error);
}

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$contador = 0;

if ($result->num_rows > 0) {
  echo "<table border='1'>
            <tr>        
                <th>#</th>
                <th>Fecha de Gestión</th>
                <th>Nombre de Interesado</th>
                <th>Telefeno de Interesado</th>
                <th>Email de Interesado</th>
                <th>Nivel de Interes</th>
                <th>Nombre de Empleado</th>
                <th>Nombre de Curso</th>
                <th>Causa</th>
                <th>Observación</th>
                <th>Origen</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>";

  // Mostrar los registros de la tabla
  while ($row = $result->fetch_assoc()) {
    $NInteres = [];
    $NivInteres = explode(',', $row['nivel_interes']);
    foreach ($NivInteres as $Esta) {
      $Est = (int) $Esta;
      if (isset($NivelInteres[$Est])) {
        $NInteres[] = $NivelInteres[$Est];
      }
    }
    $NivelInteres_texto = implode(', ', $NInteres);

    $OInteres = [];
    $NivelOrigen = explode(',', $row['origen']);
    foreach ($NivelOrigen as $Ori) {
      $Or = (int) $Ori;
      if (isset($OrigenInteres[$Or])) {
        $OInteres[] = $OrigenInteres[$Or];
      }
    }
    $Origen_texto = implode(', ', $OInteres);



    $contador++;
    echo "<td>$contador</td>
           <td>" . htmlspecialchars($row['fecha_gestion']) . "</td>
<td>" . htmlspecialchars($row['nombre_interesado']) . "</td>
<td>" . htmlspecialchars($row['telefono_interesado']) . "</td>
<td>" . htmlspecialchars($row['mail_interesado']) . "</td>
       <td>" . htmlspecialchars($NivelInteres_texto ?? '') . "</td>
<td>" . htmlspecialchars(string: $row['nombres'] . ' ' . $row['paterno'] . ' ' . $row['materno']) . "</td>
<td>" . htmlspecialchars($row['nombre']) . "</td>
<td>" . htmlspecialchars($row['causa']) . "</td>
<td>" . htmlspecialchars($row['observacion']) . "</td>
      <td>" . htmlspecialchars($Origen_texto ?? '') . "</td>

            <td>
              <a href='update.php?id_gestion=" . urlencode($row['id_gestion']) . "' class='btn btn-sm btn-warning'>Editar</a>

            </td>
            <td>
            <a href='javascript:void(0);' onclick='confirmDelete(" . htmlspecialchars(json_encode($row['id_gestion'])) . ");' class='btn btn-sm btn-danger'>Eliminar</a>
            </td>
          </tr>";
  }
  echo "</table>";
} else {
  echo "No hay Datos.";
}

$stmt->close();
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function confirmDelete(id) {
  if (confirm("¿Estás seguro que deseas eliminar este registro?")) {
    $.ajax({
      url: 'delete.php',
      type: 'POST',
      data: {
        id_causa: id
      },
      success: function(response) {
        if (response.trim() === 'success') {
          $('#row-' + id).fadeOut(500, function() {
            $(this).remove();
          });
          alert('Se ha eliminado exitosamente.');
        } else {
          alert('Error al eliminar Dato: ' + response);
        }
      },
      error: function() {
        alert('Hubo un error en la solicitud.');
      }
    });
  }
}

$(document).ready(function() {
  $('.delete-btn').on('click', function() {
    var id = $(this).data('id');
    confirmDelete(id);
  });

  $('.edit-btn').on('click', function() {
    var id = $(this).data('id');
    window.location.href = 'update.php?id=' + id;
  });
});
</script>