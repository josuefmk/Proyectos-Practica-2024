<?php include 'conexion.php';
// Las opciones para las listas desplegables
error_reporting(E_ALL);
ini_set('display_errors', 1);


$encargadoOptions = "";
$result_relator = $conn->query("SELECT DISTINCT id_empleado,nombres, paterno, materno FROM tbl_empleados");
while ($row = $result_relator->fetch_assoc()) {
  $encargadoOptions .= "<option value='{$row['id_empleado']}'> {$row['nombres']}{$row['paterno']} {$row['materno']}</option>";
}




$id_centroingreso = isset($_GET['id_centroingreso']) ? $_GET['id_centroingreso'] : "";
$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : "";

$sql = "
SELECT
id_curso,
fecha_inicio,
hora_desde,
hora_hasta,
id_centroingreso,
nombre
FROM
tbl_cursos
JOIN
tbl_centrosdeingreso
WHERE
id_centronegocio = id_centroingreso
";
$result = $conn->query($sql);
$centros = [];
if ($result) {
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $centros[] = $row;
    }
  }
}

$NivelInteres = [
  0 => 'No Interesado',
  1 => 'Interesado',
  2 => 'Muy Interesado'
];
$nivelInteresOptions = '';
$result_nivel = $conn->query("SELECT DISTINCT nivel_interes FROM tbl_gestiones");
while ($rowNI = $result_nivel->fetch_assoc()) {
  $nivelint_num = (int) $rowNI['nivel_interes'];
  $nivel_interes_texto = isset($NivelInteres[$nivelint_num]) ? $NivelInteres[$nivelint_num] : 'No existe';
  $nivelInteresOptions .= "<option value='{$nivelint_num}'>{$nivel_interes_texto}</option>";
}

$OrigenInteres = [
  0 => 'WhatsApp',
  1 => 'Instagram',
  2 => 'Telefono',
  3 => 'Correo',
  4 => 'Formulario'
];
$OrigenOptions = '';
$result_origen = $conn->query("SELECT DISTINCT origen FROM tbl_gestiones");
while ($rowOR = $result_origen->fetch_assoc()) {
  $origen_num = (int) $rowOR['origen'];
  $origen_texto = isset($OrigenInteres[$origen_num]) ? $OrigenInteres[$origen_num] : 'No existe';
  $OrigenOptions .= "<option value='{$origen_num}'>{$origen_texto}</option>";
}

?>



<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD Gestiones</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <button id="toggleAddFormBtn" class="btn">Agregar Dato</button>

  <div class="form-container" id="addFormContainer" style="display: none;">
    <form id="addForm" method="post" action="create.php">
      <h2>Agregar Nuevo Dato</h2>

      <label for="fecha_gestion">Fecha de Gestión:</label>
      <input type="date" id="fecha_gestion" name="fecha_gestion" required>

      <label for="nombre_interesado">Nombre de Interesado:</label>
      <input type="text" id="nombre_interesado" name="nombre_interesado" required>

      <label for="telefono_interesado">Telefono de Interesado:</label>
      <input type="tel" id="telefono_interesado" name="telefono_interesado" max="10" required>

      <label for="mail_interesado">Email de Interesado:</label>
      <input type="email" id="mail_interesado" name="mail_interesado" required>

      <label for="nivel_interes">Nivel de Interes:</label>
      <select id="nivel_interes" name="nivel_interes" class="form-control" required>
        <option value=""> Seleccione Nivel</option>
        <option value="0">No Interesado</option>
        <option value="1">Interesado</option>
        <option value="2">Muy Interesado</option>
      </select>

      <label for="encargado">Encargado:</label>
      <select id="encargado" name="encargado">
        <option value="">Seleccione un Encargado</option>
        <?php echo $encargadoOptions; ?>
      </select>

      <label for="especialidad">Curso:</label>
      <select id="especialidad" name="especialidad" required>
        <option value="">Seleccione un Curso</option>
        <?php
        foreach ($centros as $centro) {
          $selected = ($centro['id_centroingreso'] == $id_centroingreso) ? 'selected' : '';
          echo "<option value='" . htmlspecialchars($centro['id_centroingreso']) . "' $selected>" . htmlspecialchars($centro['nombre']) . " " . $centro['fecha_inicio'] . " " . $centro['hora_desde'] . "-" . $centro['hora_hasta'] . "</option>";
        }
        ?>
      </select>

      <label for="causa_no_matricula">Causa de No Matrícula:</label>
      <input type="text" id="causa_no_matricula" name="causa_no_matricula" required>

      <label for="observacion">Observación:</label>
      <input type="text" id="observacion" name="observacion" required>

      <label for="origen">Origen:</label>
      <select id="origen" name="origen" class="form-control" required>
        <option value=""> Seleccione Origen</option>
        <option value="0">WhatsApp</option>
        <option value="1">Instagram</option>
        <option value="2">Telefono</option>
        <option value="3">Correo</option>
        <option value="4">Formulario</option>

      </select>

      <input type="submit" value="Agregar Operación" class="btn">
    </form>
  </div>

  <form id="searchForm" method="GET">
    <h3>Buscar Datos</h3>
    <label for="search_fecha_gestion">Fecha de Gestión:</label>
    <input type="date" id="search_fecha_gestion" name="search_fecha_gestion">

    <label for="search_nombre_interesado">Nombre de Interesado:</label>
    <input type="text" id="search_nombre_interesado" name="search_nombre_interesado">

    <label for="search_nombre_encargado">Nombre de Empleado:</label>
    <select id="search_nombre_encargado" name="search_nombre_encargado">
      <option value="">Seleccione un Empleado</option>
      <?php echo $encargadoOptions; ?>
    </select>

    <label for="search_nivel_interes">Nivel de Interes:</label>
    <select id="search_nivel_interes" name="search_nivel_interes">
      <option value="">Seleccione un Nivel</option>
      <?php echo $nivelInteresOptions; ?>
    </select>

    <label for="search_nombre_curso">Curso:</label>
    <select id="search_nombre_curso" name="search_nombre_curso">
      <option value="">Seleccione un Curso</option>
      <?php
      foreach ($centros as $centro) {
        $selected = ($centro['id_centroingreso'] == $id_centroingreso) ? 'selected' : '';
        echo "<option value='" . htmlspecialchars($centro['id_centroingreso']) . "' $selected>" . htmlspecialchars($centro['nombre']) . " " . $centro['fecha_inicio'] . " " . $centro['hora_desde'] . "-" . $centro['hora_hasta'] . "</option>";
      }
      ?>
    </select>
    <label for="search_origen">Origen:</label>
    <select id="search_origen" name="search_origen">
      <option value="">Seleccione un Origen</option>
      <?php echo $OrigenOptions; ?>
    </select>


    <input type="submit" class="btn">
    <a class="btn" href='index.php'>Quitar Filtro</a>
  </form>

  <div id="searchResult"></div>

  <h2>Lista de Datos</h2>
  <div id="result"></div>

  <script src="Ajax.js"></script>
  <?php include 'read.php'; ?>

  <script>
  $(document).ready(function() {
    $('#toggleAddFormBtn').click(function() {
      $('#addFormContainer').toggle();
      $('#editFormContainer').hide();
    });
  });
  </script>
</body>