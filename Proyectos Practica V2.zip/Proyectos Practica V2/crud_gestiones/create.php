<?php
include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $fecha_gestion = $_POST['fecha_gestion'];
  $nombre_interesado = $_POST['nombre_interesado'];
  $telefono_interesado = $_POST['telefono_interesado'];
  $mail_interesado = $_POST['mail_interesado'];
  $nivel_interes = $_POST['nivel_interes'];
  $encargado = $_POST['encargado'];
  $especialidad = $_POST['especialidad'];
  $causa_no_matricula = $_POST['causa_no_matricula'];
  $observacion = $_POST['observacion'];
  $origen = $_POST['origen'];

  $stmt = $conn->prepare("INSERT INTO tbl_gestiones( fecha_gestion,nombre_interesado,telefono_interesado,mail_interesado,nivel_interes,encargado,especialidad,causa_no_matricula,observacion,origen) VALUES ( ?,?,?,?,?,?,?,?,?,?)");

  if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
  }

  $stmt->bind_param("ssssiiiiss", $fecha_gestion, $nombre_interesado, $telefono_interesado, $mail_interesado, $nivel_interes, $encargado, $especialidad, $causa_no_matricula, $observacion, $origen);

  if ($stmt->execute()) {
    echo "Datos agregados correctamente.";
  } else {
    echo "Error al guardar el producto: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>