<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Actualizar Gestión</title>
</head>

<body>

  <?php
  include 'conexion.php';
  error_reporting(E_ALL);
  ini_set('display_errors', 1);


  if (isset($_GET['id_gestion'])) {
    $id = $_GET['id_gestion'];
  } else {
    echo "<p class='error'>Error: No se proporcionó un ID válido.</p>";
    exit();
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $fecha_gestion = $conn->real_escape_string($_POST['fecha_gestion']);
    $nombre_interesado = $conn->real_escape_string($_POST['nombre_interesado']);
    $telefono_interesado = $conn->real_escape_string($_POST['telefono_interesado']);
    $mail_interesado = $conn->real_escape_string($_POST['mail_interesado']);
    $nivel_interes = $conn->real_escape_string($_POST['nivel_interes']);
    $encargado = $conn->real_escape_string($_POST['encargado']);
    $especialidad = $conn->real_escape_string($_POST['especialidad']);
    $causa_no_matricula = $conn->real_escape_string($_POST['causa_no_matricula']);
    $observacion = $conn->real_escape_string($_POST['observacion']);
    $origen = $conn->real_escape_string($_POST['origen']);

    $sql = "UPDATE tbl_gestiones
        SET fecha_gestion='$fecha_gestion', nombre_interesado='$nombre_interesado', telefono_interesado='$telefono_interesado',mail_interesado='$mail_interesado',nivel_interes='$nivel_interes',encargado='$encargado',especialidad='$especialidad',causa_no_matricula='$causa_no_matricula',observacion='$observacion',origen='$origen'
        WHERE id_gestion='$id'";

    if ($conn->query($sql)) {
      header('Location: index.php');
      exit();
    } else {
      echo "<p class='error'>Error al actualizar: " . $sql . "<br>" . $conn->error . "</p>";
    }
  } else {

    $result = $conn->query("SELECT * FROM tbl_gestiones    WHERE id_gestion=$id");
    $row = $result->fetch_assoc();


    #Nivel de interes
    $NivelInteres = [
      0 => 'No Interesado',
      1 => 'Interesado',
      2 => 'Muy Interesado'
    ];

    $NivelOptions = '';
    $result_nivel = $conn->query("SELECT DISTINCT nivel_interes FROM tbl_gestiones");

    while ($rownivel = $result_nivel->fetch_assoc()) {
      $nivel_num = (int) $rownivel['nivel_interes'];
      $nivelint_texto = isset($NivelInteres[$nivel_num]) ? $NivelInteres[$nivel_num] : 'No existe';
      $selected = ($row['nivel_interes'] == $nivel_num) ? 'selected' : '';
      $NivelOptions .= "<option value='{$nivel_num}' {$selected}>{$nivelint_texto}</option>";
    }


    #Origen de interes
    $OrigenInteres = [
      0 => 'WhatsApp',
      1 => 'Instagram',
      2 => 'Telefono',
      3 => 'Correo',
      4 => 'Formulario'
    ];

    $ORigenOptions = '';
    $result_origen = $conn->query("SELECT DISTINCT origen FROM tbl_gestiones");

    while ($roworigen = $result_origen->fetch_assoc()) {
      $origen_num = (int) $roworigen['origen'];
      $origen_texto = isset($OrigenInteres[$origen_num]) ? $OrigenInteres[$origen_num] : 'No existe';
      $selected = ($row['origen'] == $origen_num) ? 'selected' : '';
      $ORigenOptions .= "<option value='{$origen_num}' {$selected}>{$origen_texto}</option>";
    }


    #Nombre de empleado
    $nombreEncOptions = "";

    $result_relator = $conn->query("SELECT DISTINCT id_empleado, nombres, paterno, materno FROM tbl_empleados");
    while ($row_relator = $result_relator->fetch_assoc()) {
      $selected = ($row['encargado'] == $row_relator['id_empleado']) ? 'selected' : '';
      $nombreEncOptions .= "<option value='{$row_relator['id_empleado']}' {$selected}>{$row_relator['nombres']} {$row_relator['paterno']} {$row_relator['materno']}</option>";
    }

    #Causa

    $causaOptions = "";

    $result_causa = $conn->query("SELECT DISTINCT  id_causa, causa FROM tbl_causasnomatricula");
    while ($row_causa = $result_causa->fetch_assoc()) {
      $selected = ($row['causa_no_matricula'] == $row_causa['id_causa']) ? 'selected' : '';
      $causaOptions .= "<option value='{$row_causa['id_causa']}' {$selected}>{$row_causa['causa']} </option>";
    }





    #Nombre de curso
    $cursoOptions = "";
    $result_curso = $conn->query("SELECT DISTINCT nombre, id_curso,fecha_inicio,hora_desde,hora_hasta FROM tbl_cursos JOIN tbl_centrosdeingreso ON id_centroingreso = id_centronegocio GROUP BY id_centroingreso");
    while ($row_curso = $result_curso->fetch_assoc()) {
      $selected = ($row['especialidad'] == $row_curso['id_curso']) ? 'selected' : '';
      $cursoOptions .= "<option value='{$row_curso['id_curso']}' {$selected}>{$row_curso['nombre']}{$selected}  {$row_curso['fecha_inicio']}{$selected}  {$row_curso['hora_desde']}{$selected} -{$row_curso['hora_hasta']}</option>";
    }


  }

  $conn->close();
  ?>

  <div class="form-container">
    <h1>Actualizar Gestión</h1>
    <form method="POST">
      <label for="fecha_gestion">Fecha de Gestión:</label>
      <input type="date" id="fecha_gestion" name="fecha_gestion"
        value="<?php echo htmlspecialchars($row['fecha_gestion'] ?? ''); ?>">

      <label for="nombre_interesado">Nombre de Interesado:</label>
      <input type="text" id="nombre_interesado" name="nombre_interesado"
        value="<?php echo htmlspecialchars($row['nombre_interesado'] ?? ''); ?>">

      <label for="telefono_interesado">Telefono de Intresado:</label>
      <input type="number" id="telefono_interesado" name="telefono_interesado"
        value="<?php echo htmlspecialchars($row['telefono_interesado'] ?? ''); ?>">

      <label for="mail_interesado">Email de Intresado:</label>
      <input type="email" id="mail_interesado" name="mail_interesado"
        value="<?php echo htmlspecialchars($row['mail_interesado'] ?? ''); ?>">

      <label for="nivel_interes">Nivel de Interesado:</label>
      <select id="nivel_interes" name="nivel_interes">
        <option value="">Seleccione un Nivel</option>
        <?php echo $NivelOptions; ?>
      </select>

      <label for="encargado">Encargado:</label>
      <select id="encargado" name="encargado">
        <option value="">Seleccione un Encargado</option>
        <?php echo $nombreEncOptions; ?>
      </select>

      <label for="especialidad">Curso:</label>
      <select id="especialidad" name="especialidad">
        <?php echo $cursoOptions; ?>
      </select>


      <label for="causa_no_matricula">Causa No matrícula:</label>
      <select id="causa_no_matricula" name="causa_no_matricula">
        <option value="">Seleccione la causa</option>
        <?php echo $causaOptions; ?>
      </select>


      <label for="observacion">Observación:</label>
      <input type="text" id="observacion" name="observacion"
        value="<?php echo htmlspecialchars($row['observacion'] ?? ''); ?>">

      <label for="origen">Origen:</label>
      <select id="origen" name="origen">
        <option value="">Seleccione un Origen</option>
        <?php echo $ORigenOptions; ?>
      </select>



      <input type="submit" class="btn btn-success" value="Actualizar">
    </form>
  </div>

  <a href="index.php">
    <button type="button" class="btn btn-danger">Regresar</button>
  </a>

</body>

</html>